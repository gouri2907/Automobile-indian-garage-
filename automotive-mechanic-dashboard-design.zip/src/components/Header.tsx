import { Search, Bell, Menu, Sun, Moon } from 'lucide-react';
import { useState } from 'react';

interface HeaderProps {
  onMenuClick: () => void;
  sidebarCollapsed: boolean;
}

export default function Header({ onMenuClick, sidebarCollapsed }: HeaderProps) {
  const [searchFocused, setSearchFocused] = useState(false);
  const [darkMode, setDarkMode] = useState(false);

  return (
    <header
      className={`fixed top-0 right-0 h-16 bg-white border-b border-dark-200 z-30 flex items-center px-4 md:px-6 transition-all duration-300
        ${sidebarCollapsed ? 'lg:left-[72px]' : 'lg:left-64'} left-0
      `}
    >
      {/* Mobile menu button */}
      <button
        onClick={onMenuClick}
        className="lg:hidden p-2 hover:bg-dark-100 rounded-lg mr-2"
      >
        <Menu className="w-5 h-5 text-dark-600" />
      </button>

      {/* Search bar */}
      <div className={`relative flex-1 max-w-md transition-all ${searchFocused ? 'max-w-lg' : ''}`}>
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-400" />
        <input
          type="text"
          placeholder="Search vehicles, customers, jobs..."
          className="w-full pl-10 pr-4 py-2 bg-dark-50 border border-dark-200 rounded-lg text-sm text-dark-800 placeholder:text-dark-400 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
          onFocus={() => setSearchFocused(true)}
          onBlur={() => setSearchFocused(false)}
        />
      </div>

      {/* Right section */}
      <div className="flex items-center gap-2 ml-4">
        {/* Dark mode toggle */}
        <button
          onClick={() => setDarkMode(!darkMode)}
          className="hidden sm:flex p-2 hover:bg-dark-100 rounded-lg text-dark-500 transition-colors"
        >
          {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
        </button>

        {/* Notifications */}
        <button className="relative p-2 hover:bg-dark-100 rounded-lg text-dark-500 transition-colors">
          <Bell className="w-5 h-5" />
          <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-accent-500 rounded-full border-2 border-white animate-pulse-dot" />
        </button>

        {/* Profile */}
        <div className="hidden sm:flex items-center gap-3 ml-2 pl-4 border-l border-dark-200">
          <div className="text-right">
            <p className="text-sm font-semibold text-dark-800">Suresh Kumar</p>
            <p className="text-xs text-dark-400">Senior Mechanic</p>
          </div>
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-accent-400 to-accent-600 flex items-center justify-center text-white font-bold text-sm cursor-pointer ring-2 ring-white shadow-md">
            SK
          </div>
        </div>
      </div>
    </header>
  );
}
