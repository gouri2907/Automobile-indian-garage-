import { useState } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Dashboard from './screens/Dashboard';
import Notifications from './screens/Notifications';
import Vehicles from './screens/Vehicles';
import VehicleDetails from './screens/VehicleDetails';
import ServiceHistory from './screens/ServiceHistory';
import PendingJobs from './screens/PendingJobs';
import NegotiationsScreen from './screens/Negotiations';
import LocationTracking from './screens/LocationTracking';
import Customers from './screens/Customers';
import Reports from './screens/Reports';
import Settings from './screens/Settings';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [selectedVehicleId, setSelectedVehicleId] = useState<string | undefined>();

  const handleSelectVehicle = (id: string) => {
    setSelectedVehicleId(id);
    setActiveTab('vehicle-details');
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'notifications':
        return <Notifications />;
      case 'vehicles':
        return <Vehicles onSelectVehicle={handleSelectVehicle} />;
      case 'vehicle-details':
        return (
          <VehicleDetails
            vehicleId={selectedVehicleId}
            onBack={() => {
              setSelectedVehicleId(undefined);
              setActiveTab('vehicles');
            }}
          />
        );
      case 'service-history':
        return <ServiceHistory />;
      case 'pending-jobs':
        return <PendingJobs />;
      case 'negotiations':
        return <NegotiationsScreen />;
      case 'location':
        return <LocationTracking />;
      case 'customers':
        return <Customers />;
      case 'reports':
        return <Reports />;
      case 'settings':
        return <Settings />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-dark-100">
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        collapsed={sidebarCollapsed}
        setCollapsed={setSidebarCollapsed}
        mobileOpen={mobileOpen}
        setMobileOpen={setMobileOpen}
      />
      <Header
        onMenuClick={() => setMobileOpen(true)}
        sidebarCollapsed={sidebarCollapsed}
      />
      <main
        className={`pt-16 min-h-screen transition-all duration-300 ${
          sidebarCollapsed ? 'lg:pl-[72px]' : 'lg:pl-64'
        }`}
      >
        <div className="p-4 md:p-6 lg:p-8 max-w-[1600px] mx-auto">
          {renderContent()}
        </div>
      </main>
    </div>
  );
}

export default App;
