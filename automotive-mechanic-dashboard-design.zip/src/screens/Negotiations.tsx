import { Send, Check, X, Edit3, IndianRupee, User, Wrench } from 'lucide-react';
import { negotiations } from '../data/mockData';
import { useState } from 'react';

export default function NegotiationsScreen() {
  const [selectedNeg, setSelectedNeg] = useState(negotiations[0]);
  const [newMessage, setNewMessage] = useState('');

  return (
    <div className="animate-fade-in space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-dark-800">Negotiations</h2>
        <p className="text-sm text-dark-400 mt-1">Quotation and negotiation system</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Negotiation List */}
        <div className="bg-white rounded-xl border border-dark-100 overflow-hidden shadow-sm">
          <div className="p-4 border-b border-dark-100">
            <h3 className="text-sm font-semibold text-dark-700">Active Negotiations</h3>
          </div>
          <div className="divide-y divide-dark-100">
            {negotiations.map((neg) => (
              <button
                key={neg.id}
                onClick={() => setSelectedNeg(neg)}
                className={`w-full text-left p-4 hover:bg-dark-50 transition-colors ${
                  selectedNeg.id === neg.id ? 'bg-primary-50 border-l-4 border-primary-500' : ''
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-semibold text-dark-800">{neg.owner}</span>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${
                    neg.status === 'In Progress' ? 'bg-blue-100 text-blue-700' : 'bg-yellow-100 text-yellow-700'
                  }`}>
                    {neg.status}
                  </span>
                </div>
                <p className="text-xs text-dark-500 truncate">{neg.vehicle}</p>
                <p className="text-xs text-dark-400 mt-1">
                  Last: ₹{neg.messages[neg.messages.length - 1].amount.toLocaleString('en-IN')}
                </p>
              </button>
            ))}
          </div>
        </div>

        {/* Chat Area */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-dark-100 shadow-sm flex flex-col" style={{ minHeight: '500px' }}>
          {/* Chat Header */}
          <div className="p-4 border-b border-dark-100">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-dark-800">{selectedNeg.owner}</h3>
                <p className="text-xs text-dark-400">{selectedNeg.vehicle}</p>
              </div>
              <div className={`text-xs px-3 py-1 rounded-full font-medium ${
                selectedNeg.status === 'In Progress' ? 'bg-blue-100 text-blue-700' : 'bg-yellow-100 text-yellow-700'
              }`}>
                {selectedNeg.status}
              </div>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-dark-50/50">
            {selectedNeg.messages.map((msg, index) => {
              const isMechanic = msg.sender === 'mechanic';
              return (
                <div key={index} className={`flex ${isMechanic ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[80%] ${isMechanic ? 'order-2' : ''}`}>
                    <div className={`rounded-2xl p-4 shadow-sm ${
                      isMechanic
                        ? 'bg-primary-600 text-white rounded-br-md'
                        : 'bg-white text-dark-800 border border-dark-100 rounded-bl-md'
                    }`}>
                      <div className="flex items-center gap-2 mb-2">
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                          isMechanic ? 'bg-white/20 text-white' : 'bg-primary-100 text-primary-600'
                        }`}>
                          {isMechanic ? <Wrench className="w-3 h-3" /> : <User className="w-3 h-3" />}
                        </div>
                        <span className={`text-xs font-medium ${isMechanic ? 'text-primary-100' : 'text-dark-400'}`}>
                          {msg.name}
                        </span>
                        <span className={`text-[10px] ml-auto ${isMechanic ? 'text-primary-200' : 'text-dark-300'}`}>
                          {msg.time}
                        </span>
                      </div>
                      <p className="text-sm leading-relaxed">{msg.message}</p>

                      {/* Amount badge */}
                      <div className={`mt-3 p-2 rounded-lg flex items-center gap-2 ${
                        isMechanic ? 'bg-white/10' : 'bg-dark-50'
                      }`}>
                        <IndianRupee className="w-4 h-4" />
                        <span className="font-bold text-lg">₹{msg.amount.toLocaleString('en-IN')}</span>
                      </div>

                      {/* Cost Breakdown */}
                      {'breakdown' in msg && msg.breakdown && (
                        <div className={`mt-3 p-3 rounded-lg text-xs space-y-1.5 ${
                          isMechanic ? 'bg-white/10' : 'bg-dark-50'
                        }`}>
                          <p className="font-semibold text-xs mb-2">Cost Breakdown:</p>
                          {Object.entries(msg.breakdown).map(([item, cost]) => (
                            <div key={item} className="flex justify-between">
                              <span className={isMechanic ? 'text-primary-100' : 'text-dark-500'}>{item}</span>
                              <span className="font-medium">₹{(cost as number).toLocaleString('en-IN')}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Action Buttons */}
          <div className="border-t border-dark-100 p-4">
            <div className="flex flex-wrap gap-2 mb-3">
              <button className="flex items-center gap-1.5 px-4 py-2 bg-green-500 hover:bg-green-600 text-white text-sm font-medium rounded-lg transition-colors">
                <Check className="w-4 h-4" /> Accept
              </button>
              <button className="flex items-center gap-1.5 px-4 py-2 bg-red-500 hover:bg-red-600 text-white text-sm font-medium rounded-lg transition-colors">
                <X className="w-4 h-4" /> Reject
              </button>
              <button className="flex items-center gap-1.5 px-4 py-2 bg-accent-500 hover:bg-accent-600 text-white text-sm font-medium rounded-lg transition-colors">
                <Edit3 className="w-4 h-4" /> Modify Quote
              </button>
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder="Type a message or counter offer..."
                className="flex-1 px-4 py-2.5 bg-dark-50 border border-dark-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
              />
              <button className="px-4 py-2.5 bg-primary-600 hover:bg-primary-700 text-white rounded-xl transition-colors">
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
