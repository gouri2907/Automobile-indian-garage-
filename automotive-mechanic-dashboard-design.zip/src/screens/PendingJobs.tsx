import { Plus, Clock, Wrench, Package, CheckCircle, Eye } from 'lucide-react';
import { pendingJobs } from '../data/mockData';

const columnConfig: Record<string, { color: string; bgColor: string; icon: any }> = {
  'New Request': { color: 'text-gray-700', bgColor: 'bg-gray-100 border-gray-300', icon: Plus },
  'Inspection': { color: 'text-purple-700', bgColor: 'bg-purple-100 border-purple-300', icon: Eye },
  'In Progress': { color: 'text-blue-700', bgColor: 'bg-blue-100 border-blue-300', icon: Wrench },
  'Waiting for Parts': { color: 'text-orange-700', bgColor: 'bg-orange-100 border-orange-300', icon: Package },
  'Approval Pending': { color: 'text-yellow-700', bgColor: 'bg-yellow-100 border-yellow-300', icon: Clock },
  'Completed': { color: 'text-green-700', bgColor: 'bg-green-100 border-green-300', icon: CheckCircle },
};

const priorityDots: Record<string, string> = {
  'High': 'bg-red-500',
  'Medium': 'bg-yellow-500',
  'Low': 'bg-green-500',
};

export default function PendingJobs() {
  const columns = Object.entries(pendingJobs);

  return (
    <div className="animate-fade-in space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-dark-800">Pending Jobs</h2>
          <p className="text-sm text-dark-400 mt-1">Track and manage all repair jobs</p>
        </div>
        <div className="flex items-center gap-3 text-sm">
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-red-500" /> High
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-yellow-500" /> Medium
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-green-500" /> Low
          </div>
        </div>
      </div>

      {/* Kanban Board */}
      <div className="overflow-x-auto -mx-4 px-4 md:mx-0 md:px-0">
        <div className="flex gap-4 min-w-[1100px] pb-4">
          {columns.map(([column, jobs]) => {
            const config = columnConfig[column];
            const ColIcon = config.icon;
            return (
              <div key={column} className="flex-1 min-w-[180px]">
                {/* Column Header */}
                <div className={`rounded-xl p-3 mb-3 border-l-4 ${config.bgColor}`}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <ColIcon className={`w-4 h-4 ${config.color}`} />
                      <h3 className={`text-sm font-semibold ${config.color}`}>{column}</h3>
                    </div>
                    <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${config.bgColor} ${config.color}`}>
                      {jobs.length}
                    </span>
                  </div>
                </div>

                {/* Cards */}
                <div className="space-y-3 kanban-col">
                  {jobs.map((job) => (
                    <div
                      key={job.id}
                      className="bg-white rounded-xl p-4 border border-dark-100 hover:shadow-md transition-all cursor-pointer group hover:border-primary-200"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[10px] font-mono text-dark-400">{job.id}</span>
                        <div className="flex items-center gap-1.5">
                          <div className={`w-2 h-2 rounded-full ${priorityDots[job.priority]}`} />
                          <span className="text-[10px] text-dark-400">{job.priority}</span>
                        </div>
                      </div>
                      <h4 className="font-semibold text-dark-800 text-sm">{job.vehicle}</h4>
                      <p className="text-xs text-dark-400 font-mono mt-0.5">{job.regNumber}</p>
                      <p className="text-xs text-dark-500 mt-2 line-clamp-2">{job.issue}</p>
                      <div className="flex items-center justify-between mt-3 pt-3 border-t border-dark-100">
                        <span className="text-xs text-dark-400">{job.owner}</span>
                        <span className="text-xs text-dark-400">{job.date}</span>
                      </div>
                    </div>
                  ))}

                  {/* Add Job placeholder */}
                  <button className="w-full p-3 border-2 border-dashed border-dark-200 rounded-xl text-dark-400 text-sm hover:border-primary-300 hover:text-primary-500 transition-colors flex items-center justify-center gap-2">
                    <Plus className="w-4 h-4" />
                    Add Job
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
