import { User, Bell, Shield, Palette, Globe, Database, HelpCircle, LogOut, ChevronRight, Camera, Save } from 'lucide-react';
import { useState } from 'react';

const settingSections = [
  { id: 'profile', label: 'Profile Settings', icon: User, desc: 'Manage your personal information' },
  { id: 'notifications', label: 'Notification Preferences', icon: Bell, desc: 'Control what notifications you receive' },
  { id: 'security', label: 'Security', icon: Shield, desc: 'Password and authentication settings' },
  { id: 'appearance', label: 'Appearance', icon: Palette, desc: 'Customize dashboard look and feel' },
  { id: 'language', label: 'Language & Region', icon: Globe, desc: 'Language, timezone, and currency' },
  { id: 'data', label: 'Data Management', icon: Database, desc: 'Export, backup, and manage data' },
  { id: 'help', label: 'Help & Support', icon: HelpCircle, desc: 'FAQ, documentation, and contact support' },
];

export default function Settings() {
  const [activeSection, setActiveSection] = useState('profile');

  return (
    <div className="animate-fade-in space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-dark-800">Settings</h2>
        <p className="text-sm text-dark-400 mt-1">Manage your account and preferences</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Settings Navigation */}
        <div className="bg-white rounded-xl border border-dark-100 overflow-hidden shadow-sm">
          <div className="divide-y divide-dark-100">
            {settingSections.map((section) => {
              const Icon = section.icon;
              const isActive = activeSection === section.id;
              return (
                <button
                  key={section.id}
                  onClick={() => setActiveSection(section.id)}
                  className={`w-full flex items-center gap-3 p-4 text-left transition-all ${
                    isActive ? 'bg-primary-50 border-l-4 border-primary-500' : 'hover:bg-dark-50'
                  }`}
                >
                  <Icon className={`w-5 h-5 ${isActive ? 'text-primary-600' : 'text-dark-400'}`} />
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm font-medium ${isActive ? 'text-primary-700' : 'text-dark-700'}`}>{section.label}</p>
                    <p className="text-xs text-dark-400 truncate">{section.desc}</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-dark-300" />
                </button>
              );
            })}
          </div>
          <div className="p-4 border-t border-dark-100">
            <button className="w-full flex items-center gap-3 p-3 text-red-600 hover:bg-red-50 rounded-lg transition-colors text-sm font-medium">
              <LogOut className="w-5 h-5" />
              Sign Out
            </button>
          </div>
        </div>

        {/* Settings Content */}
        <div className="lg:col-span-2 space-y-6">
          {activeSection === 'profile' && (
            <>
              {/* Profile Card */}
              <div className="bg-white rounded-xl border border-dark-100 p-6 shadow-sm">
                <h3 className="text-lg font-semibold text-dark-800 mb-6">Profile Information</h3>
                <div className="flex items-center gap-6 mb-6">
                  <div className="relative">
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-accent-400 to-accent-600 flex items-center justify-center text-white font-bold text-2xl">
                      SK
                    </div>
                    <button className="absolute bottom-0 right-0 w-7 h-7 bg-primary-600 text-white rounded-full flex items-center justify-center border-2 border-white">
                      <Camera className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-dark-800">Suresh Kumar</h4>
                    <p className="text-sm text-dark-400">Senior Mechanic • Employee ID: EMP-2019-042</p>
                    <p className="text-xs text-primary-600 mt-1">AutoGarage Pro Workshop, Mumbai</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-medium text-dark-500 mb-1.5 block">Full Name</label>
                    <input type="text" defaultValue="Suresh Kumar" className="w-full px-4 py-2.5 bg-dark-50 border border-dark-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary-500" />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-dark-500 mb-1.5 block">Phone Number</label>
                    <input type="text" defaultValue="+91 98765 12345" className="w-full px-4 py-2.5 bg-dark-50 border border-dark-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary-500" />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-dark-500 mb-1.5 block">Email</label>
                    <input type="email" defaultValue="suresh.kumar@autogaragepro.in" className="w-full px-4 py-2.5 bg-dark-50 border border-dark-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary-500" />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-dark-500 mb-1.5 block">Specialization</label>
                    <input type="text" defaultValue="Engine & Transmission Repair" className="w-full px-4 py-2.5 bg-dark-50 border border-dark-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary-500" />
                  </div>
                  <div className="md:col-span-2">
                    <label className="text-xs font-medium text-dark-500 mb-1.5 block">Workshop Address</label>
                    <input type="text" defaultValue="Plot 45, MIDC Industrial Area, Andheri East, Mumbai - 400093" className="w-full px-4 py-2.5 bg-dark-50 border border-dark-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary-500" />
                  </div>
                </div>

                <div className="flex justify-end mt-6">
                  <button className="flex items-center gap-2 px-6 py-2.5 bg-primary-600 hover:bg-primary-700 text-white rounded-lg text-sm font-medium transition-colors">
                    <Save className="w-4 h-4" /> Save Changes
                  </button>
                </div>
              </div>

              {/* Skills */}
              <div className="bg-white rounded-xl border border-dark-100 p-6 shadow-sm">
                <h3 className="text-lg font-semibold text-dark-800 mb-4">Skills & Expertise</h3>
                <div className="flex flex-wrap gap-2">
                  {['Engine Repair', 'Transmission', 'AC Service', 'Electrical Systems', 'Brake Systems', 'Body Work', 'Diagnostics', 'Oil Change', 'Tyre Service'].map((skill) => (
                    <span key={skill} className="bg-primary-50 text-primary-700 text-sm px-3 py-1.5 rounded-lg border border-primary-100">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </>
          )}

          {activeSection === 'notifications' && (
            <div className="bg-white rounded-xl border border-dark-100 p-6 shadow-sm">
              <h3 className="text-lg font-semibold text-dark-800 mb-6">Notification Preferences</h3>
              <div className="space-y-4">
                {[
                  { label: 'New Service Requests', desc: 'Get notified when a new service request is assigned', default: true },
                  { label: 'Customer Messages', desc: 'Notifications for new customer messages', default: true },
                  { label: 'Payment Updates', desc: 'Get notified about payment status changes', default: true },
                  { label: 'Parts Delivery', desc: 'Alerts when ordered parts arrive', default: true },
                  { label: 'Daily Summary', desc: 'Daily summary of all activities', default: false },
                  { label: 'Weekly Reports', desc: 'Weekly performance report notifications', default: true },
                  { label: 'SMS Notifications', desc: 'Receive notifications via SMS', default: false },
                  { label: 'Email Notifications', desc: 'Receive notifications via email', default: true },
                ].map((item) => (
                  <div key={item.label} className="flex items-center justify-between p-3 rounded-xl hover:bg-dark-50">
                    <div>
                      <p className="text-sm font-medium text-dark-700">{item.label}</p>
                      <p className="text-xs text-dark-400 mt-0.5">{item.desc}</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" defaultChecked={item.default} className="sr-only peer" />
                      <div className="w-11 h-6 bg-dark-200 peer-focus:ring-2 peer-focus:ring-primary-300 rounded-full peer peer-checked:bg-primary-600 after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:after:translate-x-full"></div>
                    </label>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeSection !== 'profile' && activeSection !== 'notifications' && (
            <div className="bg-white rounded-xl border border-dark-100 p-8 shadow-sm text-center">
              <div className="w-16 h-16 bg-primary-50 rounded-full flex items-center justify-center mx-auto mb-4">
                {(() => {
                  const section = settingSections.find(s => s.id === activeSection);
                  if (section) {
                    const Icon = section.icon;
                    return <Icon className="w-8 h-8 text-primary-500" />;
                  }
                  return null;
                })()}
              </div>
              <h3 className="text-lg font-semibold text-dark-800">
                {settingSections.find(s => s.id === activeSection)?.label}
              </h3>
              <p className="text-sm text-dark-400 mt-2">
                {settingSections.find(s => s.id === activeSection)?.desc}
              </p>
              <p className="text-xs text-dark-300 mt-4">Configuration panel coming soon</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
