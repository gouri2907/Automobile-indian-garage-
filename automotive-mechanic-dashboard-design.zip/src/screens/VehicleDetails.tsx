import { ArrowLeft, Car, Fuel, Shield, User, Phone, Mail, AlertCircle, CheckCircle, Clock, Wrench, IndianRupee } from 'lucide-react';
import { vehicles } from '../data/mockData';
import { useState } from 'react';

const progressSteps = [
  { label: 'Received', icon: Car },
  { label: 'Inspection', icon: AlertCircle },
  { label: 'Repair Started', icon: Wrench },
  { label: 'Testing', icon: Clock },
  { label: 'Completed', icon: CheckCircle },
];

export default function VehicleDetails({ vehicleId, onBack }: { vehicleId?: string; onBack?: () => void }) {
  const [selectedId, setSelectedId] = useState(vehicleId || 'V001');
  const vehicle = vehicles.find(v => v.id === selectedId) || vehicles[0];

  const getStepIndex = () => {
    if (vehicle.progress >= 100) return 4;
    if (vehicle.progress >= 75) return 3;
    if (vehicle.progress >= 40) return 2;
    if (vehicle.progress >= 10) return 1;
    return 0;
  };

  const stepIndex = getStepIndex();

  return (
    <div className="animate-fade-in space-y-6">
      <div className="flex items-center gap-4">
        {onBack && (
          <button onClick={onBack} className="p-2 hover:bg-dark-100 rounded-lg">
            <ArrowLeft className="w-5 h-5 text-dark-600" />
          </button>
        )}
        <div className="flex-1">
          <h2 className="text-2xl font-bold text-dark-800">Vehicle Details</h2>
          <p className="text-sm text-dark-400 mt-1">Complete information about the vehicle</p>
        </div>
        {!vehicleId && (
          <select
            value={selectedId}
            onChange={(e) => setSelectedId(e.target.value)}
            className="px-4 py-2 bg-white border border-dark-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
          >
            {vehicles.map(v => (
              <option key={v.id} value={v.id}>{v.regNumber} - {v.brand} {v.model}</option>
            ))}
          </select>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Vehicle Image Card */}
        <div className="bg-white rounded-xl border border-dark-100 overflow-hidden shadow-sm">
          <div className="relative h-52">
            <img src={vehicle.image} alt={vehicle.model} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            <div className="absolute bottom-4 left-4 text-white">
              <p className="font-mono text-lg font-bold">{vehicle.regNumber}</p>
              <p className="text-sm text-white/80">{vehicle.brand} {vehicle.model} • {vehicle.year}</p>
            </div>
          </div>
          <div className="p-5 space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center gap-2">
                <Car className="w-4 h-4 text-primary-500" />
                <div>
                  <p className="text-xs text-dark-400">Type</p>
                  <p className="text-sm font-medium text-dark-700">{vehicle.type}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Fuel className="w-4 h-4 text-accent-500" />
                <div>
                  <p className="text-xs text-dark-400">Fuel</p>
                  <p className="text-sm font-medium text-dark-700">{vehicle.fuelType}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded-full border-2 border-dark-300" style={{ backgroundColor: vehicle.color.includes('White') ? '#f5f5f5' : vehicle.color.includes('Grey') ? '#6b7280' : vehicle.color.includes('Gold') ? '#d4a855' : vehicle.color.includes('Red') ? '#ef4444' : vehicle.color.includes('Black') ? '#1f2937' : '#3b82f6' }} />
                <div>
                  <p className="text-xs text-dark-400">Color</p>
                  <p className="text-sm font-medium text-dark-700">{vehicle.color}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Shield className={`w-4 h-4 ${vehicle.insuranceStatus === 'Active' ? 'text-green-500' : 'text-red-500'}`} />
                <div>
                  <p className="text-xs text-dark-400">Insurance</p>
                  <p className={`text-sm font-medium ${vehicle.insuranceStatus === 'Active' ? 'text-green-600' : 'text-red-600'}`}>
                    {vehicle.insuranceStatus}
                  </p>
                </div>
              </div>
            </div>
            <div className="pt-3 border-t border-dark-100 text-xs text-dark-400">
              Insurance Expiry: {vehicle.insuranceExpiry}
            </div>
          </div>
        </div>

        {/* Owner & Issue Info */}
        <div className="space-y-6">
          {/* Owner Card */}
          <div className="bg-white rounded-xl border border-dark-100 p-5 shadow-sm">
            <h3 className="text-sm font-semibold text-dark-800 mb-4 flex items-center gap-2">
              <User className="w-4 h-4 text-primary-500" /> Owner Information
            </h3>
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary-400 to-primary-600 flex items-center justify-center text-white font-bold text-lg">
                  {vehicle.owner.split(' ').map(n => n[0]).join('')}
                </div>
                <div>
                  <p className="font-semibold text-dark-800">{vehicle.owner}</p>
                  <p className="text-xs text-dark-400">Vehicle Owner</p>
                </div>
              </div>
              <div className="flex items-center gap-2 text-sm text-dark-600">
                <Phone className="w-4 h-4 text-dark-400" />
                {vehicle.ownerPhone}
              </div>
              <div className="flex items-center gap-2 text-sm text-dark-600">
                <Mail className="w-4 h-4 text-dark-400" />
                {vehicle.ownerEmail}
              </div>
            </div>
          </div>

          {/* Issue Card */}
          <div className="bg-white rounded-xl border border-dark-100 p-5 shadow-sm">
            <h3 className="text-sm font-semibold text-dark-800 mb-3 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-accent-500" /> Issue Description
            </h3>
            <div className="bg-accent-50 border border-accent-200 rounded-lg p-4">
              <p className="text-sm text-dark-700 leading-relaxed">{vehicle.issue}</p>
            </div>
            <div className="grid grid-cols-2 gap-4 mt-4">
              <div>
                <p className="text-xs text-dark-400">Assigned Date</p>
                <p className="text-sm font-medium text-dark-700">{vehicle.assignedDate}</p>
              </div>
              <div>
                <p className="text-xs text-dark-400">Current Status</p>
                <p className="text-sm font-medium text-primary-600">{vehicle.status}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Progress & Cost */}
        <div className="space-y-6">
          {/* Repair Progress */}
          <div className="bg-white rounded-xl border border-dark-100 p-5 shadow-sm">
            <h3 className="text-sm font-semibold text-dark-800 mb-4 flex items-center gap-2">
              <Wrench className="w-4 h-4 text-primary-500" /> Repair Progress
            </h3>
            <div className="space-y-4">
              {progressSteps.map((step, index) => {
                const StepIcon = step.icon;
                const isCompleted = index <= stepIndex;
                const isCurrent = index === stepIndex;
                return (
                  <div key={step.label} className="flex items-center gap-3">
                    <div className="flex flex-col items-center">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 transition-all ${
                        isCompleted
                          ? isCurrent ? 'border-primary-500 bg-primary-500 text-white ring-4 ring-primary-100' : 'border-green-500 bg-green-500 text-white'
                          : 'border-dark-200 bg-white text-dark-400'
                      }`}>
                        <StepIcon className="w-4 h-4" />
                      </div>
                      {index < progressSteps.length - 1 && (
                        <div className={`w-0.5 h-6 mt-1 ${index < stepIndex ? 'bg-green-400' : 'bg-dark-200'}`} />
                      )}
                    </div>
                    <div>
                      <p className={`text-sm font-medium ${isCompleted ? 'text-dark-800' : 'text-dark-400'}`}>
                        {step.label}
                      </p>
                      {isCurrent && <p className="text-xs text-primary-500">Current Stage</p>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Estimated Cost */}
          <div className="bg-gradient-to-br from-primary-600 to-primary-800 rounded-xl p-5 text-white shadow-lg">
            <div className="flex items-center gap-2 mb-3">
              <IndianRupee className="w-5 h-5 text-primary-200" />
              <h3 className="text-sm font-semibold">Estimated Cost</h3>
            </div>
            <p className="text-3xl font-bold">₹{vehicle.estimatedCost.toLocaleString('en-IN')}</p>
            <p className="text-sm text-primary-200 mt-1">Including parts & labour</p>
            <div className="flex gap-2 mt-4">
              <button className="flex-1 bg-white/20 hover:bg-white/30 backdrop-blur-sm text-white text-sm font-medium py-2 rounded-lg transition-colors">
                Modify
              </button>
              <button className="flex-1 bg-accent-500 hover:bg-accent-600 text-white text-sm font-medium py-2 rounded-lg transition-colors">
                Send Quote
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
