import { Download, TrendingUp, IndianRupee, Users, Car, Star, FileText } from 'lucide-react';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, PieChart, Pie, Cell, Legend, LineChart, Line
} from 'recharts';
import { revenueData, serviceTypeData, performanceData } from '../data/mockData';

const customerGrowth = [
  { month: 'Aug', customers: 42 },
  { month: 'Sep', customers: 48 },
  { month: 'Oct', customers: 52 },
  { month: 'Nov', customers: 58 },
  { month: 'Dec', customers: 65 },
  { month: 'Jan', customers: 71 },
];

const reportCards = [
  { title: 'Total Revenue', value: '₹12,70,000', change: '+18%', icon: IndianRupee, color: 'from-green-500 to-emerald-600' },
  { title: 'Total Customers', value: '71', change: '+12%', icon: Users, color: 'from-primary-500 to-primary-700' },
  { title: 'Vehicles Serviced', value: '223', change: '+8%', icon: Car, color: 'from-accent-500 to-accent-700' },
  { title: 'Avg Satisfaction', value: '4.4/5', change: '+0.3', icon: Star, color: 'from-yellow-500 to-yellow-600' },
];

export default function Reports() {
  return (
    <div className="animate-fade-in space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-dark-800">Reports & Analytics</h2>
          <p className="text-sm text-dark-400 mt-1">Business insights and performance metrics</p>
        </div>
        <div className="flex items-center gap-3">
          <select className="px-4 py-2 bg-white border border-dark-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500">
            <option>Last 6 months</option>
            <option>Last 12 months</option>
            <option>This year</option>
          </select>
          <button className="flex items-center gap-2 px-4 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-xl text-sm font-medium transition-colors">
            <Download className="w-4 h-4" /> Export
          </button>
        </div>
      </div>

      {/* Report Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {reportCards.map((card) => {
          const Icon = card.icon;
          return (
            <div key={card.title} className="bg-white rounded-xl p-5 border border-dark-100 hover:shadow-md transition-shadow">
              <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${card.color} flex items-center justify-center mb-3`}>
                <Icon className="w-5 h-5 text-white" />
              </div>
              <p className="text-2xl font-bold text-dark-800">{card.value}</p>
              <div className="flex items-center justify-between mt-1">
                <p className="text-xs text-dark-400">{card.title}</p>
                <span className="text-xs font-medium text-green-600 flex items-center gap-0.5">
                  <TrendingUp className="w-3 h-3" /> {card.change}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue Trend */}
        <div className="bg-white rounded-xl p-5 border border-dark-100">
          <h3 className="text-lg font-semibold text-dark-800 mb-1">Revenue Trend</h3>
          <p className="text-sm text-dark-400 mb-4">Monthly revenue over time</p>
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={revenueData}>
              <defs>
                <linearGradient id="revGrad2" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#22c55e" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="month" stroke="#94a3b8" fontSize={12} />
              <YAxis stroke="#94a3b8" fontSize={12} tickFormatter={(v) => `₹${v / 1000}k`} />
              <Tooltip contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0' }} />
              <Area type="monotone" dataKey="revenue" stroke="#22c55e" strokeWidth={2.5} fill="url(#revGrad2)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Customer Growth */}
        <div className="bg-white rounded-xl p-5 border border-dark-100">
          <h3 className="text-lg font-semibold text-dark-800 mb-1">Customer Growth</h3>
          <p className="text-sm text-dark-400 mb-4">New customers over time</p>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={customerGrowth}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="month" stroke="#94a3b8" fontSize={12} />
              <YAxis stroke="#94a3b8" fontSize={12} />
              <Tooltip contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0' }} />
              <Line type="monotone" dataKey="customers" stroke="#3b82f6" strokeWidth={2.5} dot={{ r: 4, fill: '#3b82f6' }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Job Performance */}
        <div className="lg:col-span-2 bg-white rounded-xl p-5 border border-dark-100">
          <h3 className="text-lg font-semibold text-dark-800 mb-1">Weekly Job Performance</h3>
          <p className="text-sm text-dark-400 mb-4">Completed vs new jobs</p>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={performanceData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} />
              <YAxis stroke="#94a3b8" fontSize={12} />
              <Tooltip contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0' }} />
              <Legend iconType="circle" iconSize={8} />
              <Bar dataKey="completed" fill="#22c55e" radius={[4, 4, 0, 0]} name="Completed" />
              <Bar dataKey="newJobs" fill="#3b82f6" radius={[4, 4, 0, 0]} name="New Jobs" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Service Distribution */}
        <div className="bg-white rounded-xl p-5 border border-dark-100">
          <h3 className="text-lg font-semibold text-dark-800 mb-1">Service Distribution</h3>
          <p className="text-sm text-dark-400 mb-4">By service type</p>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={serviceTypeData} cx="50%" cy="50%" outerRadius={75} dataKey="value" label={({ value }) => `${value}%`}>
                {serviceTypeData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-1.5 mt-2">
            {serviceTypeData.map((item) => (
              <div key={item.name} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-dark-500">{item.name}</span>
                </div>
                <span className="font-medium text-dark-700">{item.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick Reports */}
      <div className="bg-white rounded-xl p-5 border border-dark-100">
        <h3 className="text-lg font-semibold text-dark-800 mb-4">Quick Reports</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {[
            { title: 'Monthly Revenue Report', icon: IndianRupee, desc: 'Detailed revenue breakdown' },
            { title: 'Service Performance', icon: TrendingUp, desc: 'Job completion metrics' },
            { title: 'Customer Analytics', icon: Users, desc: 'Customer insights & trends' },
            { title: 'Inventory Report', icon: FileText, desc: 'Parts & stock status' },
          ].map((report) => {
            const Icon = report.icon;
            return (
              <button key={report.title} className="flex items-center gap-3 p-4 rounded-xl border border-dark-200 hover:border-primary-300 hover:bg-primary-50 transition-all text-left group">
                <div className="w-10 h-10 rounded-lg bg-primary-50 group-hover:bg-primary-100 flex items-center justify-center transition-colors">
                  <Icon className="w-5 h-5 text-primary-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-dark-800">{report.title}</p>
                  <p className="text-xs text-dark-400">{report.desc}</p>
                </div>
                <Download className="w-4 h-4 text-dark-300 group-hover:text-primary-500 transition-colors" />
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
