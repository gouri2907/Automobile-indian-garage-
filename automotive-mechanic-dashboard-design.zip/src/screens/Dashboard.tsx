import {
  Car, Wrench, CheckCircle2, Calendar, IndianRupee, Star, TrendingUp, TrendingDown,
  ArrowUpRight, Clock, AlertCircle
} from 'lucide-react';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, PieChart, Pie, Cell, Legend
} from 'recharts';
import { revenueData, performanceData, serviceTypeData, vehicles } from '../data/mockData';

const stats = [
  { label: 'Total Assigned', value: '12', icon: Car, color: 'from-primary-500 to-primary-700', change: '+2', trend: 'up', bgLight: 'bg-primary-50' },
  { label: 'Pending Repairs', value: '5', icon: Wrench, color: 'from-accent-500 to-accent-700', change: '-1', trend: 'down', bgLight: 'bg-accent-50' },
  { label: 'Completed Today', value: '3', icon: CheckCircle2, color: 'from-green-500 to-green-700', change: '+3', trend: 'up', bgLight: 'bg-green-50' },
  { label: "Today's Jobs", value: '7', icon: Calendar, color: 'from-violet-500 to-violet-700', change: '+1', trend: 'up', bgLight: 'bg-violet-50' },
  { label: 'Revenue (Jan)', value: '₹1.65L', icon: IndianRupee, color: 'from-emerald-500 to-emerald-700', change: '-12%', trend: 'down', bgLight: 'bg-emerald-50' },
  { label: 'Avg Rating', value: '4.6', icon: Star, color: 'from-yellow-500 to-yellow-600', change: '+0.2', trend: 'up', bgLight: 'bg-yellow-50' },
];

export default function Dashboard() {
  return (
    <div className="animate-fade-in space-y-6">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-primary-700 via-primary-600 to-primary-800 rounded-2xl p-6 md:p-8 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/4" />
        <div className="absolute bottom-0 left-1/3 w-40 h-40 bg-white/5 rounded-full translate-y-1/2" />
        <div className="relative">
          <h2 className="text-2xl md:text-3xl font-bold">Good Morning, Suresh! 🔧</h2>
          <p className="text-primary-100 mt-2 text-sm md:text-base">You have <span className="text-accent-300 font-semibold">5 pending jobs</span> and <span className="text-accent-300 font-semibold">2 new service requests</span> today.</p>
          <div className="flex flex-wrap gap-4 mt-5">
            <div className="bg-white/15 backdrop-blur-sm rounded-xl px-4 py-2 flex items-center gap-2">
              <Clock className="w-4 h-4 text-accent-300" />
              <span className="text-sm">Next Job: 11:30 AM — Hyundai Creta</span>
            </div>
            <div className="bg-white/15 backdrop-blur-sm rounded-xl px-4 py-2 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-yellow-300" />
              <span className="text-sm">1 urgent inspection pending</span>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="bg-white rounded-xl p-4 shadow-sm border border-dark-100 hover:shadow-md transition-shadow group">
              <div className="flex items-center justify-between mb-3">
                <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${stat.color} flex items-center justify-center shadow-md`}>
                  <Icon className="w-5 h-5 text-white" />
                </div>
                <span className={`flex items-center gap-0.5 text-xs font-medium ${stat.trend === 'up' ? 'text-green-600' : 'text-red-500'}`}>
                  {stat.trend === 'up' ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                  {stat.change}
                </span>
              </div>
              <p className="text-2xl font-bold text-dark-800">{stat.value}</p>
              <p className="text-xs text-dark-400 mt-1">{stat.label}</p>
            </div>
          );
        })}
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Revenue Chart */}
        <div className="lg:col-span-2 bg-white rounded-xl p-5 shadow-sm border border-dark-100">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-semibold text-dark-800">Revenue Overview</h3>
              <p className="text-sm text-dark-400">Monthly revenue & job count</p>
            </div>
            <select className="text-sm border border-dark-200 rounded-lg px-3 py-1.5 text-dark-600 focus:outline-none focus:ring-2 focus:ring-primary-500">
              <option>Last 6 months</option>
              <option>Last 12 months</option>
              <option>This year</option>
            </select>
          </div>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={revenueData}>
              <defs>
                <linearGradient id="revenueGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="month" stroke="#94a3b8" fontSize={12} />
              <YAxis stroke="#94a3b8" fontSize={12} tickFormatter={(v) => `₹${v / 1000}k`} />
              <Tooltip
                contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)' }}
                formatter={(value: any) => [`₹${Number(value).toLocaleString('en-IN')}`, 'Revenue']}
              />
              <Area type="monotone" dataKey="revenue" stroke="#3b82f6" strokeWidth={2.5} fill="url(#revenueGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Service Type Distribution */}
        <div className="bg-white rounded-xl p-5 shadow-sm border border-dark-100">
          <h3 className="text-lg font-semibold text-dark-800 mb-1">Service Types</h3>
          <p className="text-sm text-dark-400 mb-4">Distribution of services</p>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie
                data={serviceTypeData}
                cx="50%"
                cy="50%"
                innerRadius={55}
                outerRadius={85}
                paddingAngle={4}
                dataKey="value"
              >
                {serviceTypeData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip formatter={(value: any) => [`${value}%`, 'Share']} />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-2 mt-2">
            {serviceTypeData.map((item) => (
              <div key={item.name} className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-dark-600">{item.name}</span>
                </div>
                <span className="font-medium text-dark-800">{item.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Performance & Recent Vehicles */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weekly Performance */}
        <div className="bg-white rounded-xl p-5 shadow-sm border border-dark-100">
          <h3 className="text-lg font-semibold text-dark-800 mb-1">Weekly Performance</h3>
          <p className="text-sm text-dark-400 mb-4">Completed vs Pending jobs this week</p>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={performanceData} barGap={2}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} />
              <YAxis stroke="#94a3b8" fontSize={12} />
              <Tooltip contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0' }} />
              <Legend iconType="circle" iconSize={8} />
              <Bar dataKey="completed" fill="#22c55e" radius={[4, 4, 0, 0]} name="Completed" />
              <Bar dataKey="pending" fill="#f97316" radius={[4, 4, 0, 0]} name="Pending" />
              <Bar dataKey="newJobs" fill="#3b82f6" radius={[4, 4, 0, 0]} name="New Jobs" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Recent Vehicles */}
        <div className="bg-white rounded-xl p-5 shadow-sm border border-dark-100">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-semibold text-dark-800">Recent Vehicles</h3>
              <p className="text-sm text-dark-400">Latest assigned vehicles</p>
            </div>
            <button className="text-sm text-primary-600 hover:text-primary-700 font-medium flex items-center gap-1">
              View All <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="space-y-3">
            {vehicles.slice(0, 4).map((v) => (
              <div key={v.id} className="flex items-center gap-4 p-3 rounded-xl hover:bg-dark-50 transition-colors border border-transparent hover:border-dark-100">
                <img src={v.image} alt={v.model} className="w-14 h-14 rounded-lg object-cover" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-semibold text-dark-800 text-sm">{v.brand} {v.model}</p>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${
                      v.status === 'Completed' ? 'bg-green-100 text-green-700' :
                      v.status === 'In Progress' ? 'bg-blue-100 text-blue-700' :
                      v.status === 'Pending' ? 'bg-yellow-100 text-yellow-700' :
                      v.status === 'Waiting for Parts' ? 'bg-orange-100 text-orange-700' :
                      'bg-gray-100 text-gray-700'
                    }`}>
                      {v.status}
                    </span>
                  </div>
                  <p className="text-xs text-dark-400 mt-0.5">{v.regNumber} • {v.owner}</p>
                </div>
                <div className="text-right hidden sm:block">
                  <p className="text-sm font-semibold text-dark-700">₹{v.estimatedCost.toLocaleString('en-IN')}</p>
                  <div className="w-16 h-1.5 bg-dark-100 rounded-full mt-1 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-primary-500 to-accent-500"
                      style={{ width: `${v.progress}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
