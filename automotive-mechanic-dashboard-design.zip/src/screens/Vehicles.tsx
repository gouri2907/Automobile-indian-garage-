import { Search, Car, Fuel, User, Calendar } from 'lucide-react';
import { vehicles } from '../data/mockData';
import { useState } from 'react';

const statusColors: Record<string, string> = {
  'In Progress': 'bg-blue-100 text-blue-700',
  'Pending': 'bg-yellow-100 text-yellow-700',
  'Completed': 'bg-green-100 text-green-700',
  'Waiting for Parts': 'bg-orange-100 text-orange-700',
  'Inspection': 'bg-purple-100 text-purple-700',
  'New Request': 'bg-gray-100 text-gray-700',
};

export default function Vehicles({ onSelectVehicle }: { onSelectVehicle?: (id: string) => void }) {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');

  const filtered = vehicles.filter(v => {
    const matchesSearch = `${v.brand} ${v.model} ${v.regNumber} ${v.owner}`.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = statusFilter === 'All' || v.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="animate-fade-in space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-dark-800">Assigned Vehicles</h2>
          <p className="text-sm text-dark-400 mt-1">{vehicles.length} vehicles assigned to you</p>
        </div>
      </div>

      {/* Search & Filter */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-400" />
          <input
            type="text"
            placeholder="Search by brand, model, reg number, owner..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-white border border-dark-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
          />
        </div>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-4 py-2.5 bg-white border border-dark-200 rounded-xl text-sm text-dark-600 focus:outline-none focus:ring-2 focus:ring-primary-500"
        >
          <option>All</option>
          <option>In Progress</option>
          <option>Pending</option>
          <option>Completed</option>
          <option>Waiting for Parts</option>
          <option>Inspection</option>
          <option>New Request</option>
        </select>
      </div>

      {/* Vehicle Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
        {filtered.map((v) => (
          <div
            key={v.id}
            onClick={() => onSelectVehicle?.(v.id)}
            className="bg-white rounded-xl border border-dark-100 overflow-hidden hover:shadow-lg transition-all cursor-pointer group"
          >
            {/* Vehicle Image */}
            <div className="relative h-40 overflow-hidden">
              <img src={v.image} alt={v.model} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              <div className="absolute top-3 left-3">
                <span className={`text-xs px-3 py-1 rounded-full font-semibold ${statusColors[v.status]}`}>
                  {v.status}
                </span>
              </div>
              <div className="absolute top-3 right-3 bg-dark-900/70 text-white text-xs px-3 py-1 rounded-full font-mono font-semibold backdrop-blur-sm">
                {v.regNumber}
              </div>
            </div>

            {/* Details */}
            <div className="p-4">
              <h3 className="text-lg font-bold text-dark-800">{v.brand} {v.model}</h3>
              <p className="text-sm text-dark-400 mt-0.5">{v.year} • {v.color}</p>

              <div className="grid grid-cols-2 gap-3 mt-4">
                <div className="flex items-center gap-2 text-sm text-dark-500">
                  <Car className="w-4 h-4 text-dark-400" />
                  <span>{v.type}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-dark-500">
                  <Fuel className="w-4 h-4 text-dark-400" />
                  <span>{v.fuelType}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-dark-500">
                  <User className="w-4 h-4 text-dark-400" />
                  <span className="truncate">{v.owner}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-dark-500">
                  <Calendar className="w-4 h-4 text-dark-400" />
                  <span>{v.assignedDate}</span>
                </div>
              </div>

              {/* Progress */}
              <div className="mt-4">
                <div className="flex items-center justify-between text-sm mb-1.5">
                  <span className="text-dark-500">Repair Progress</span>
                  <span className="font-semibold text-dark-700">{v.progress}%</span>
                </div>
                <div className="w-full h-2 bg-dark-100 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      v.progress === 100 ? 'bg-green-500' :
                      v.progress > 50 ? 'bg-primary-500' :
                      'bg-accent-500'
                    }`}
                    style={{ width: `${v.progress}%` }}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between mt-4 pt-3 border-t border-dark-100">
                <span className="text-sm text-dark-400">Est. Cost</span>
                <span className="text-lg font-bold text-dark-800">₹{v.estimatedCost.toLocaleString('en-IN')}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
