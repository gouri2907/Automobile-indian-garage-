import { Calendar, Star, Download, Wrench, Package, IndianRupee, User, ChevronDown, ChevronUp } from 'lucide-react';
import { serviceHistory } from '../data/mockData';
import { useState } from 'react';

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((star) => (
        <Star
          key={star}
          className={`w-4 h-4 ${star <= rating ? 'text-yellow-400 fill-yellow-400' : star - 0.5 <= rating ? 'text-yellow-400 fill-yellow-400/50' : 'text-dark-200'}`}
        />
      ))}
      <span className="text-sm font-medium text-dark-600 ml-1">{rating}</span>
    </div>
  );
}

export default function ServiceHistory() {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  return (
    <div className="animate-fade-in space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-dark-800">Service History</h2>
        <p className="text-sm text-dark-400 mt-1">Complete service timeline for all vehicles</p>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-4 border border-dark-100">
          <p className="text-2xl font-bold text-dark-800">{serviceHistory.length}</p>
          <p className="text-xs text-dark-400 mt-1">Total Services</p>
        </div>
        <div className="bg-white rounded-xl p-4 border border-dark-100">
          <p className="text-2xl font-bold text-dark-800">₹{(serviceHistory.reduce((a, s) => a + s.cost, 0) / 1000).toFixed(0)}k</p>
          <p className="text-xs text-dark-400 mt-1">Total Revenue</p>
        </div>
        <div className="bg-white rounded-xl p-4 border border-dark-100">
          <p className="text-2xl font-bold text-dark-800">{(serviceHistory.reduce((a, s) => a + s.rating, 0) / serviceHistory.length).toFixed(1)}</p>
          <p className="text-xs text-dark-400 mt-1">Avg Rating</p>
        </div>
        <div className="bg-white rounded-xl p-4 border border-dark-100">
          <p className="text-2xl font-bold text-dark-800">{new Set(serviceHistory.map(s => s.partsReplaced).flat()).size}</p>
          <p className="text-xs text-dark-400 mt-1">Parts Replaced</p>
        </div>
      </div>

      {/* Timeline */}
      <div className="relative">
        {/* Timeline line */}
        <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-dark-200 hidden md:block" />

        <div className="space-y-4">
          {serviceHistory.map((service, index) => {
            const isExpanded = expandedId === service.id;
            return (
              <div key={service.id} className="relative flex gap-4 md:gap-6">
                {/* Timeline dot */}
                <div className="hidden md:flex flex-col items-center">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center z-10 border-4 border-dark-100 ${
                    index === 0 ? 'bg-primary-500 text-white' : 'bg-white text-dark-500'
                  }`}>
                    <Wrench className="w-5 h-5" />
                  </div>
                </div>

                {/* Card */}
                <div className="flex-1 bg-white rounded-xl border border-dark-100 hover:shadow-md transition-shadow overflow-hidden">
                  <div
                    className="p-4 md:p-5 cursor-pointer"
                    onClick={() => setExpandedId(isExpanded ? null : service.id)}
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="bg-primary-50 text-primary-700 text-xs px-2.5 py-1 rounded-md font-mono font-medium">
                            {service.regNumber}
                          </span>
                          <span className="text-xs text-dark-400 flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {new Date(service.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                          </span>
                        </div>
                        <p className="text-sm font-medium text-dark-800 mt-2">{service.workCompleted}</p>
                        <div className="flex items-center gap-4 mt-2 flex-wrap">
                          <StarRating rating={service.rating} />
                          <span className="text-sm font-semibold text-dark-700 flex items-center gap-1">
                            <IndianRupee className="w-3.5 h-3.5" />
                            {service.cost.toLocaleString('en-IN')}
                          </span>
                          <span className="text-xs text-dark-400 flex items-center gap-1">
                            <User className="w-3 h-3" />
                            {service.mechanic}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button className="p-2 hover:bg-primary-50 rounded-lg text-primary-600 transition-colors" title="Download Invoice">
                          <Download className="w-4 h-4" />
                        </button>
                        {isExpanded ? <ChevronUp className="w-4 h-4 text-dark-400" /> : <ChevronDown className="w-4 h-4 text-dark-400" />}
                      </div>
                    </div>
                  </div>

                  {/* Expanded details */}
                  {isExpanded && (
                    <div className="border-t border-dark-100 p-4 md:p-5 bg-dark-50 animate-fade-in">
                      <h4 className="text-sm font-semibold text-dark-700 mb-3 flex items-center gap-2">
                        <Package className="w-4 h-4 text-accent-500" />
                        Parts Replaced
                      </h4>
                      <div className="flex flex-wrap gap-2 mb-4">
                        {service.partsReplaced.map((part, i) => (
                          <span key={i} className="bg-white text-dark-600 text-xs px-3 py-1.5 rounded-lg border border-dark-200">
                            {part}
                          </span>
                        ))}
                      </div>
                      <div className="flex items-center justify-between pt-3 border-t border-dark-200">
                        <span className="text-xs text-dark-400">Invoice: {service.invoiceId}</span>
                        <button className="flex items-center gap-1.5 text-sm text-primary-600 hover:text-primary-700 font-medium">
                          <Download className="w-4 h-4" />
                          Download Invoice
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
