import { MapPin, Navigation, Phone, Car, Wrench, ExternalLink, Locate } from 'lucide-react';
import { locationMarkers } from '../data/mockData';
import { useState } from 'react';

const typeConfig: Record<string, { color: string; bg: string; icon: any }> = {
  customer: { color: 'text-primary-600', bg: 'bg-primary-100', icon: Car },
  service_request: { color: 'text-accent-600', bg: 'bg-accent-100', icon: Wrench },
  garage: { color: 'text-green-600', bg: 'bg-green-100', icon: MapPin },
};

export default function LocationTracking() {
  const [selectedMarker, setSelectedMarker] = useState(locationMarkers[0]);

  return (
    <div className="animate-fade-in space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-dark-800">Location Tracking</h2>
        <p className="text-sm text-dark-400 mt-1">Track vehicles and service requests on the map</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Map Area */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-dark-100 overflow-hidden shadow-sm">
          {/* Interactive Map Mockup */}
          <div className="relative h-[500px] bg-gradient-to-br from-primary-50 via-blue-50 to-green-50 overflow-hidden">
            {/* India Map Silhouette (SVG) */}
            <svg viewBox="0 0 600 700" className="absolute inset-0 w-full h-full opacity-10">
              <path d="M290 80 L320 60 L360 70 L380 100 L400 90 L420 110 L440 120 L450 160 L470 180 L480 220 L500 250 L510 290 L520 330 L510 370 L500 400 L490 430 L480 460 L460 490 L440 510 L420 530 L400 550 L380 560 L360 570 L340 590 L320 600 L300 610 L280 600 L260 580 L240 560 L220 540 L200 510 L190 480 L180 450 L170 420 L160 390 L150 360 L140 330 L130 300 L140 270 L150 240 L160 210 L180 180 L200 160 L220 140 L240 120 L260 100 Z" fill="#3b82f6" />
            </svg>

            {/* Map grid */}
            <div className="absolute inset-0" style={{
              backgroundImage: 'linear-gradient(rgba(59,130,246,0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(59,130,246,0.06) 1px, transparent 1px)',
              backgroundSize: '40px 40px'
            }} />

            {/* Location Markers */}
            {locationMarkers.map((marker, index) => {
              const config = typeConfig[marker.type];
              const MarkerIcon = config.icon;
              const isSelected = selectedMarker.id === marker.id;
              // Position markers across the map area
              const positions = [
                { x: '40%', y: '45%' },
                { x: '55%', y: '25%' },
                { x: '50%', y: '55%' },
                { x: '35%', y: '35%' },
                { x: '60%', y: '20%' },
              ];
              const pos = positions[index] || { x: '50%', y: '50%' };

              return (
                <button
                  key={marker.id}
                  onClick={() => setSelectedMarker(marker)}
                  className={`absolute transform -translate-x-1/2 -translate-y-1/2 transition-all z-10 ${
                    isSelected ? 'scale-125 z-20' : 'hover:scale-110'
                  }`}
                  style={{ left: pos.x, top: pos.y }}
                >
                  <div className="relative">
                    <div className={`w-10 h-10 rounded-full ${config.bg} flex items-center justify-center shadow-lg border-2 ${
                      isSelected ? 'border-primary-500 ring-4 ring-primary-100' : 'border-white'
                    }`}>
                      <MarkerIcon className={`w-5 h-5 ${config.color}`} />
                    </div>
                    {/* Pulse animation for active markers */}
                    {marker.type !== 'garage' && (
                      <div className={`absolute inset-0 rounded-full ${config.bg} animate-ping opacity-30`} />
                    )}
                    {/* Label */}
                    <div className={`absolute top-full left-1/2 -translate-x-1/2 mt-1 bg-dark-800 text-white text-[10px] px-2 py-1 rounded-md whitespace-nowrap shadow-lg ${
                      isSelected ? 'visible' : 'invisible group-hover:visible'
                    }`}>
                      {marker.name}
                    </div>
                  </div>
                </button>
              );
            })}

            {/* Map Controls */}
            <div className="absolute top-4 right-4 flex flex-col gap-2">
              <button className="w-9 h-9 bg-white rounded-lg shadow-md flex items-center justify-center text-dark-600 hover:bg-dark-50 text-lg font-bold">+</button>
              <button className="w-9 h-9 bg-white rounded-lg shadow-md flex items-center justify-center text-dark-600 hover:bg-dark-50 text-lg font-bold">−</button>
              <button className="w-9 h-9 bg-white rounded-lg shadow-md flex items-center justify-center text-dark-600 hover:bg-dark-50">
                <Locate className="w-4 h-4" />
              </button>
            </div>

            {/* Map Legend */}
            <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm rounded-xl p-3 shadow-lg">
              <p className="text-[10px] font-semibold text-dark-500 uppercase mb-2">Legend</p>
              <div className="space-y-1.5">
                <div className="flex items-center gap-2 text-xs text-dark-600">
                  <div className="w-3 h-3 rounded-full bg-primary-100 border border-primary-400" /> Customer Vehicle
                </div>
                <div className="flex items-center gap-2 text-xs text-dark-600">
                  <div className="w-3 h-3 rounded-full bg-accent-100 border border-accent-400" /> Service Request
                </div>
                <div className="flex items-center gap-2 text-xs text-dark-600">
                  <div className="w-3 h-3 rounded-full bg-green-100 border border-green-400" /> Workshop
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Location Details & List */}
        <div className="space-y-4">
          {/* Selected Location */}
          <div className="bg-white rounded-xl border border-dark-100 p-5 shadow-sm">
            <h3 className="text-sm font-semibold text-dark-700 mb-3">Selected Location</h3>
            <div className={`p-4 rounded-xl ${typeConfig[selectedMarker.type].bg}`}>
              <div className="flex items-center gap-3 mb-3">
                <div className={`w-10 h-10 rounded-full bg-white flex items-center justify-center`}>
                  {(() => {
                    const Ic = typeConfig[selectedMarker.type].icon;
                    return <Ic className={`w-5 h-5 ${typeConfig[selectedMarker.type].color}`} />;
                  })()}
                </div>
                <div>
                  <p className="font-semibold text-dark-800">{selectedMarker.name}</p>
                  <p className="text-xs text-dark-500">{selectedMarker.vehicle || 'Main Workshop'}</p>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm text-dark-600">
                  <MapPin className="w-4 h-4 text-dark-400" />
                  <span>{selectedMarker.lat.toFixed(4)}°N, {selectedMarker.lng.toFixed(4)}°E</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-dark-600">
                  <Navigation className="w-4 h-4 text-dark-400" />
                  <span>{selectedMarker.status}</span>
                </div>
              </div>
              <div className="flex gap-2 mt-4">
                <button className="flex-1 bg-primary-600 hover:bg-primary-700 text-white text-sm py-2 rounded-lg flex items-center justify-center gap-1.5 transition-colors">
                  <Navigation className="w-3.5 h-3.5" /> Navigate
                </button>
                <button className="flex-1 bg-white hover:bg-dark-50 text-dark-700 text-sm py-2 rounded-lg flex items-center justify-center gap-1.5 border border-dark-200 transition-colors">
                  <Phone className="w-3.5 h-3.5" /> Call
                </button>
              </div>
            </div>
          </div>

          {/* Nearby Requests */}
          <div className="bg-white rounded-xl border border-dark-100 p-5 shadow-sm">
            <h3 className="text-sm font-semibold text-dark-700 mb-3">All Locations</h3>
            <div className="space-y-2">
              {locationMarkers.map((m) => {
                const config = typeConfig[m.type];
                const Ic = config.icon;
                return (
                  <button
                    key={m.id}
                    onClick={() => setSelectedMarker(m)}
                    className={`w-full flex items-center gap-3 p-3 rounded-xl text-left transition-all ${
                      selectedMarker.id === m.id ? 'bg-primary-50 border border-primary-200' : 'hover:bg-dark-50 border border-transparent'
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-lg ${config.bg} flex items-center justify-center flex-shrink-0`}>
                      <Ic className={`w-4 h-4 ${config.color}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-dark-800 truncate">{m.name}</p>
                      <p className="text-[10px] text-dark-400">{m.status}</p>
                    </div>
                    <ExternalLink className="w-3.5 h-3.5 text-dark-300" />
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
