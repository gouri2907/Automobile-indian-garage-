import { Search, Phone, Mail, MapPin, Car, Star, IndianRupee, Calendar } from 'lucide-react';
import { customers } from '../data/mockData';
import { useState } from 'react';

export default function Customers() {
  const [search, setSearch] = useState('');
  const [view, setView] = useState<'grid' | 'table'>('grid');

  const filtered = customers.filter(c =>
    `${c.name} ${c.email} ${c.location}`.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="animate-fade-in space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-dark-800">Customers</h2>
          <p className="text-sm text-dark-400 mt-1">{customers.length} registered customers</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setView('grid')}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium ${view === 'grid' ? 'bg-primary-600 text-white' : 'bg-white text-dark-500 border border-dark-200'}`}
          >Grid</button>
          <button
            onClick={() => setView('table')}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium ${view === 'table' ? 'bg-primary-600 text-white' : 'bg-white text-dark-500 border border-dark-200'}`}
          >Table</button>
        </div>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-400" />
        <input
          type="text"
          placeholder="Search customers..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-10 pr-4 py-2.5 bg-white border border-dark-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
        />
      </div>

      {/* Grid View */}
      {view === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map((customer) => (
            <div key={customer.id} className="bg-white rounded-xl border border-dark-100 p-5 hover:shadow-md transition-all">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary-400 to-primary-600 flex items-center justify-center text-white font-bold text-lg">
                  {customer.name.split(' ').map(n => n[0]).join('')}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-dark-800">{customer.name}</h3>
                  <p className="text-xs text-dark-400 flex items-center gap-1 mt-0.5">
                    <MapPin className="w-3 h-3" /> {customer.location}
                  </p>
                </div>
                <div className="flex items-center gap-1 bg-yellow-50 text-yellow-600 px-2 py-1 rounded-lg">
                  <Star className="w-3.5 h-3.5 fill-yellow-400" />
                  <span className="text-sm font-semibold">{customer.rating}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="flex items-center gap-2 text-dark-500">
                  <Phone className="w-4 h-4 text-dark-400" />
                  <span className="truncate text-xs">{customer.phone}</span>
                </div>
                <div className="flex items-center gap-2 text-dark-500">
                  <Mail className="w-4 h-4 text-dark-400" />
                  <span className="truncate text-xs">{customer.email.split('@')[0]}</span>
                </div>
                <div className="flex items-center gap-2 text-dark-500">
                  <Car className="w-4 h-4 text-dark-400" />
                  <span className="text-xs">{customer.vehicles} vehicle{customer.vehicles > 1 ? 's' : ''}</span>
                </div>
                <div className="flex items-center gap-2 text-dark-500">
                  <Calendar className="w-4 h-4 text-dark-400" />
                  <span className="text-xs">{customer.lastVisit}</span>
                </div>
              </div>

              <div className="flex items-center justify-between mt-4 pt-3 border-t border-dark-100">
                <span className="text-xs text-dark-400">Total Spent</span>
                <span className="text-sm font-bold text-dark-800 flex items-center gap-0.5">
                  <IndianRupee className="w-3.5 h-3.5" />
                  {customer.totalSpent.toLocaleString('en-IN')}
                </span>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* Table View */
        <div className="bg-white rounded-xl border border-dark-100 overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-dark-50 border-b border-dark-100">
                  <th className="text-left py-3 px-4 font-semibold text-dark-600">Customer</th>
                  <th className="text-left py-3 px-4 font-semibold text-dark-600">Phone</th>
                  <th className="text-left py-3 px-4 font-semibold text-dark-600 hidden md:table-cell">Location</th>
                  <th className="text-center py-3 px-4 font-semibold text-dark-600">Vehicles</th>
                  <th className="text-right py-3 px-4 font-semibold text-dark-600">Total Spent</th>
                  <th className="text-center py-3 px-4 font-semibold text-dark-600">Rating</th>
                  <th className="text-left py-3 px-4 font-semibold text-dark-600 hidden lg:table-cell">Last Visit</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-dark-100">
                {filtered.map((c) => (
                  <tr key={c.id} className="hover:bg-dark-50 transition-colors">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary-400 to-primary-600 flex items-center justify-center text-white font-bold text-xs">
                          {c.name.split(' ').map(n => n[0]).join('')}
                        </div>
                        <div>
                          <p className="font-medium text-dark-800">{c.name}</p>
                          <p className="text-xs text-dark-400">{c.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-dark-600 text-xs">{c.phone}</td>
                    <td className="py-3 px-4 text-dark-600 text-xs hidden md:table-cell">{c.location}</td>
                    <td className="py-3 px-4 text-center text-dark-600">{c.vehicles}</td>
                    <td className="py-3 px-4 text-right font-semibold text-dark-800">₹{c.totalSpent.toLocaleString('en-IN')}</td>
                    <td className="py-3 px-4 text-center">
                      <span className="inline-flex items-center gap-1 text-yellow-600">
                        <Star className="w-3 h-3 fill-yellow-400" /> {c.rating}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-dark-500 text-xs hidden lg:table-cell">{c.lastVisit}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
