import { Bell, MessageSquare, IndianRupee, AlertTriangle, Wrench, MailOpen } from 'lucide-react';
import { notifications } from '../data/mockData';
import { useState } from 'react';

const typeIcons: Record<string, any> = {
  service_request: Wrench,
  payment: IndianRupee,
  message: MessageSquare,
  alert: AlertTriangle,
};

const typeColors: Record<string, string> = {
  service_request: 'bg-primary-100 text-primary-600',
  payment: 'bg-green-100 text-green-600',
  message: 'bg-violet-100 text-violet-600',
  alert: 'bg-yellow-100 text-yellow-600',
};

const priorityColors: Record<string, string> = {
  high: 'bg-red-100 text-red-700 border-red-200',
  medium: 'bg-yellow-100 text-yellow-700 border-yellow-200',
  low: 'bg-green-100 text-green-700 border-green-200',
};

export default function Notifications() {
  const [filter, setFilter] = useState('all');
  const [notifs, setNotifs] = useState(notifications);

  const filtered = filter === 'all' ? notifs : filter === 'unread' ? notifs.filter(n => !n.read) : notifs.filter(n => n.type === filter);

  const markAllRead = () => {
    setNotifs(notifs.map(n => ({ ...n, read: true })));
  };

  return (
    <div className="animate-fade-in space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-dark-800">Notifications</h2>
          <p className="text-sm text-dark-400 mt-1">{notifs.filter(n => !n.read).length} unread notifications</p>
        </div>
        <button
          onClick={markAllRead}
          className="flex items-center gap-2 px-4 py-2 bg-primary-50 text-primary-600 rounded-lg text-sm font-medium hover:bg-primary-100 transition-colors"
        >
          <MailOpen className="w-4 h-4" />
          Mark all as read
        </button>
      </div>

      {/* Filter tabs */}
      <div className="flex flex-wrap gap-2">
        {['all', 'unread', 'service_request', 'payment', 'message', 'alert'].map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              filter === f
                ? 'bg-primary-600 text-white shadow-md shadow-primary-200'
                : 'bg-white text-dark-500 border border-dark-200 hover:bg-dark-50'
            }`}
          >
            {f === 'all' ? 'All' : f === 'unread' ? 'Unread' : f === 'service_request' ? 'Service' : f.charAt(0).toUpperCase() + f.slice(1)}
          </button>
        ))}
      </div>

      {/* Notification List */}
      <div className="space-y-3">
        {filtered.map((notif) => {
          const Icon = typeIcons[notif.type] || Bell;
          return (
            <div
              key={notif.id}
              className={`bg-white rounded-xl p-4 md:p-5 border transition-all hover:shadow-md cursor-pointer ${
                !notif.read ? 'border-primary-200 shadow-sm' : 'border-dark-100'
              }`}
            >
              <div className="flex items-start gap-4">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${typeColors[notif.type]}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h4 className="font-semibold text-dark-800 text-sm">{notif.title}</h4>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium border ${priorityColors[notif.priority]}`}>
                      {notif.priority.toUpperCase()}
                    </span>
                    {!notif.read && <span className="w-2 h-2 bg-primary-500 rounded-full animate-pulse-dot" />}
                  </div>
                  <p className="text-sm text-dark-500 mt-1 leading-relaxed">{notif.message}</p>
                  <p className="text-xs text-dark-400 mt-2">{notif.time}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
