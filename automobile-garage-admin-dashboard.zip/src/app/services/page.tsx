import { db } from "@/db";
import { serviceRequests, customers, mechanics, vehicles } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import ServicesClient from "./ServicesClient";

export const dynamic = "force-dynamic";

export default async function ServicesPage() {
  let serviceList: Array<{
    id: number;
    serviceType: string;
    description: string | null;
    priority: "low" | "medium" | "high" | "emergency";
    status: "unassigned" | "assigned" | "in_progress" | "completed" | "cancelled";
    estimatedCost: string | null;
    finalCost: string | null;
    createdAt: Date;
    customerName: string | null;
    mechanicName: string | null;
    vehicleReg: string | null;
    vehicleMake: string | null;
    vehicleModel: string | null;
  }> = [];

  try {
    serviceList = await db
      .select({
        id: serviceRequests.id,
        serviceType: serviceRequests.serviceType,
        description: serviceRequests.description,
        priority: serviceRequests.priority,
        status: serviceRequests.status,
        estimatedCost: serviceRequests.estimatedCost,
        finalCost: serviceRequests.finalCost,
        createdAt: serviceRequests.createdAt,
        customerName: customers.name,
        mechanicName: mechanics.name,
        vehicleReg: vehicles.registrationNumber,
        vehicleMake: vehicles.make,
        vehicleModel: vehicles.model,
      })
      .from(serviceRequests)
      .leftJoin(customers, eq(serviceRequests.customerId, customers.id))
      .leftJoin(mechanics, eq(serviceRequests.mechanicId, mechanics.id))
      .leftJoin(vehicles, eq(serviceRequests.vehicleId, vehicles.id))
      .orderBy(desc(serviceRequests.createdAt));
  } catch {
    // tables may not exist yet
  }

  return <ServicesClient initialServices={serviceList} />;
}
