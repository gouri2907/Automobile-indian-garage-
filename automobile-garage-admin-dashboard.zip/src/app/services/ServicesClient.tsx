"use client";

import { useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";

interface Service {
  id: number;
  serviceType: string;
  description: string | null;
  priority: "low" | "medium" | "high" | "emergency";
  status: "unassigned" | "assigned" | "in_progress" | "completed" | "cancelled";
  estimatedCost: string | null;
  finalCost: string | null;
  createdAt: Date;
  customerName: string | null;
  mechanicName: string | null;
  vehicleReg: string | null;
  vehicleMake: string | null;
  vehicleModel: string | null;
}

const statusColors: Record<string, string> = {
  unassigned: "bg-gray-100 text-gray-700",
  assigned: "bg-blue-100 text-blue-700",
  in_progress: "bg-yellow-100 text-yellow-700",
  completed: "bg-green-100 text-green-700",
  cancelled: "bg-red-100 text-red-700",
};

const priorityColors: Record<string, string> = {
  low: "bg-gray-100 text-gray-600",
  medium: "bg-blue-100 text-blue-600",
  high: "bg-orange-100 text-orange-600",
  emergency: "bg-red-100 text-red-600",
};

const statusLabels: Record<string, string> = {
  unassigned: "Unassigned",
  assigned: "Assigned",
  in_progress: "In Progress",
  completed: "Completed",
  cancelled: "Cancelled",
};

export default function ServicesClient({ initialServices }: { initialServices: Service[] }) {
  const [filterStatus, setFilterStatus] = useState("");
  const [filterPriority, setFilterPriority] = useState("");

  const filtered = initialServices.filter((s) => {
    const matchStatus = !filterStatus || s.status === filterStatus;
    const matchPriority = !filterPriority || s.priority === filterPriority;
    return matchStatus && matchPriority;
  });

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Service Requests</h1>
        <p className="text-sm text-gray-500 mt-1">View and manage all service requests</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-5 gap-4 mb-6">
        {["unassigned", "assigned", "in_progress", "completed", "cancelled"].map((st) => (
          <div key={st} className="kpi-card">
            <div>
              <p className="text-xs text-gray-500 capitalize">{statusLabels[st]}</p>
              <p className="text-xl font-bold">{initialServices.filter(s => s.status === st).length}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="card mb-6">
        <div className="flex flex-wrap gap-4">
          <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="input-field max-w-[200px]">
            <option value="">All Status</option>
            <option value="unassigned">Unassigned</option>
            <option value="assigned">Assigned</option>
            <option value="in_progress">In Progress</option>
            <option value="completed">Completed</option>
            <option value="cancelled">Cancelled</option>
          </select>
          <select value={filterPriority} onChange={(e) => setFilterPriority(e.target.value)} className="input-field max-w-[200px]">
            <option value="">All Priority</option>
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
            <option value="emergency">Emergency</option>
          </select>
        </div>
      </div>

      {/* Service Requests Table */}
      <div className="card overflow-hidden p-0">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="table-header">ID</th>
                <th className="table-header">Service</th>
                <th className="table-header">Customer</th>
                <th className="table-header">Vehicle</th>
                <th className="table-header">Mechanic</th>
                <th className="table-header">Priority</th>
                <th className="table-header">Status</th>
                <th className="table-header">Cost</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filtered.map((s) => (
                <tr key={s.id} className="hover:bg-gray-50 transition-colors">
                  <td className="table-cell font-mono text-xs">SR-{String(s.id).padStart(3, "0")}</td>
                  <td className="table-cell">
                    <div>
                      <p className="font-medium text-gray-800">{s.serviceType}</p>
                      <p className="text-xs text-gray-400 line-clamp-1">{s.description}</p>
                    </div>
                  </td>
                  <td className="table-cell">{s.customerName || "-"}</td>
                  <td className="table-cell">
                    {s.vehicleMake ? (
                      <div>
                        <p className="text-sm">{s.vehicleMake} {s.vehicleModel}</p>
                        <p className="text-xs text-gray-400 font-mono">{s.vehicleReg}</p>
                      </div>
                    ) : "-"}
                  </td>
                  <td className="table-cell">{s.mechanicName || <span className="text-gray-400 italic">Unassigned</span>}</td>
                  <td className="table-cell">
                    <span className={`badge ${priorityColors[s.priority]}`}>{s.priority}</span>
                  </td>
                  <td className="table-cell">
                    <span className={`badge ${statusColors[s.status]}`}>{statusLabels[s.status]}</span>
                  </td>
                  <td className="table-cell font-medium">
                    ₹{Number(s.finalCost || s.estimatedCost || 0).toLocaleString("en-IN")}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </DashboardLayout>
  );
}
