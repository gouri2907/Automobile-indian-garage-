"use client";

import DashboardLayout from "@/components/DashboardLayout";

interface Payment {
  id: number;
  amount: string;
  paymentMethod: string | null;
  paymentStatus: "pending" | "completed" | "refunded" | "failed";
  transactionId: string | null;
  createdAt: Date;
  customerName: string | null;
  mechanicName: string | null;
  serviceType: string | null;
}

interface Stats {
  totalRevenue: number;
  pendingCount: number;
  pendingTotal: number;
  completedCount: number;
}

const paymentStatusColors: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-700",
  completed: "bg-green-100 text-green-700",
  refunded: "bg-blue-100 text-blue-700",
  failed: "bg-red-100 text-red-700",
};

const methodIcons: Record<string, string> = {
  UPI: "📱",
  Card: "💳",
  Cash: "💵",
  "Net Banking": "🏦",
};

export default function PaymentsClient({
  initialPayments,
  stats,
}: {
  initialPayments: Payment[];
  stats: Stats;
}) {
  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Payments</h1>
        <p className="text-sm text-gray-500 mt-1">Track payments, earnings, and financial analytics</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-6">
        <div className="kpi-card border-l-4 border-l-green-500">
          <span className="text-2xl">💰</span>
          <div>
            <p className="text-xs text-gray-500">Total Revenue</p>
            <p className="text-xl font-bold text-green-700">₹{stats.totalRevenue.toLocaleString("en-IN")}</p>
          </div>
        </div>
        <div className="kpi-card border-l-4 border-l-yellow-500">
          <span className="text-2xl">⏳</span>
          <div>
            <p className="text-xs text-gray-500">Pending Payments</p>
            <p className="text-xl font-bold text-yellow-700">{stats.pendingCount}</p>
          </div>
        </div>
        <div className="kpi-card border-l-4 border-l-orange-500">
          <span className="text-2xl">📊</span>
          <div>
            <p className="text-xs text-gray-500">Pending Amount</p>
            <p className="text-xl font-bold text-orange-700">₹{stats.pendingTotal.toLocaleString("en-IN")}</p>
          </div>
        </div>
        <div className="kpi-card border-l-4 border-l-blue-500">
          <span className="text-2xl">✅</span>
          <div>
            <p className="text-xs text-gray-500">Completed</p>
            <p className="text-xl font-bold text-blue-700">{stats.completedCount}</p>
          </div>
        </div>
      </div>

      {/* Payments Table */}
      <div className="card overflow-hidden p-0">
        <div className="px-6 py-4 border-b border-gray-100">
          <h3 className="font-semibold text-gray-800">Payment History</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="table-header">Transaction</th>
                <th className="table-header">Service</th>
                <th className="table-header">Customer</th>
                <th className="table-header">Mechanic</th>
                <th className="table-header">Amount</th>
                <th className="table-header">Method</th>
                <th className="table-header">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {initialPayments.map((p) => (
                <tr key={p.id} className="hover:bg-gray-50 transition-colors">
                  <td className="table-cell font-mono text-xs">
                    {p.transactionId || `TXN-${String(p.id).padStart(6, "0")}`}
                  </td>
                  <td className="table-cell">{p.serviceType || "-"}</td>
                  <td className="table-cell">{p.customerName || "-"}</td>
                  <td className="table-cell">{p.mechanicName || "-"}</td>
                  <td className="table-cell font-bold text-gray-800">
                    ₹{Number(p.amount).toLocaleString("en-IN")}
                  </td>
                  <td className="table-cell">
                    <span className="flex items-center gap-1">
                      {methodIcons[p.paymentMethod || ""] || "💳"} {p.paymentMethod || "-"}
                    </span>
                  </td>
                  <td className="table-cell">
                    <span className={`badge ${paymentStatusColors[p.paymentStatus]}`}>
                      {p.paymentStatus}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </DashboardLayout>
  );
}
