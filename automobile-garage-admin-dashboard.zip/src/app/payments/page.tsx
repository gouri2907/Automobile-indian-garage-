import { db } from "@/db";
import { payments, customers, mechanics, serviceRequests } from "@/db/schema";
import { desc, eq, sql, count } from "drizzle-orm";
import PaymentsClient from "./PaymentsClient";

export const dynamic = "force-dynamic";

export default async function PaymentsPage() {
  let paymentList: Array<{
    id: number;
    amount: string;
    paymentMethod: string | null;
    paymentStatus: "pending" | "completed" | "refunded" | "failed";
    transactionId: string | null;
    createdAt: Date;
    customerName: string | null;
    mechanicName: string | null;
    serviceType: string | null;
  }> = [];
  let stats = { totalRevenue: 0, pendingCount: 0, pendingTotal: 0, completedCount: 0 };

  try {
    paymentList = await db
      .select({
        id: payments.id,
        amount: payments.amount,
        paymentMethod: payments.paymentMethod,
        paymentStatus: payments.paymentStatus,
        transactionId: payments.transactionId,
        createdAt: payments.createdAt,
        customerName: customers.name,
        mechanicName: mechanics.name,
        serviceType: serviceRequests.serviceType,
      })
      .from(payments)
      .leftJoin(customers, eq(payments.customerId, customers.id))
      .leftJoin(mechanics, eq(payments.mechanicId, mechanics.id))
      .leftJoin(serviceRequests, eq(payments.serviceRequestId, serviceRequests.id))
      .orderBy(desc(payments.createdAt));

    const [totalRev] = await db.select({ total: sql<string>`COALESCE(SUM(${payments.amount}::numeric), 0)` }).from(payments).where(eq(payments.paymentStatus, "completed"));
    const [pending] = await db.select({ count: count(), total: sql<string>`COALESCE(SUM(${payments.amount}::numeric), 0)` }).from(payments).where(eq(payments.paymentStatus, "pending"));
    const [completed] = await db.select({ count: count() }).from(payments).where(eq(payments.paymentStatus, "completed"));

    stats = {
      totalRevenue: parseFloat(totalRev.total || "0"),
      pendingCount: pending.count,
      pendingTotal: parseFloat(pending.total || "0"),
      completedCount: completed.count,
    };
  } catch {
    // tables may not exist yet
  }

  return <PaymentsClient initialPayments={paymentList} stats={stats} />;
}
