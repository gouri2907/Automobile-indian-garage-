"use client";

import { useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";

interface Mechanic {
  id: number;
  name: string;
  email: string;
  phone: string;
  specialization: string | null;
  experience: number | null;
  status: "active" | "inactive" | "blocked" | "suspended";
  isVerified: boolean | null;
  isAvailable: boolean | null;
  jobsCompleted: number | null;
  rating: string | null;
  earnings: string | null;
  certifications: string | null;
  createdAt: Date;
}

const statusColors: Record<string, string> = {
  active: "bg-green-100 text-green-700",
  inactive: "bg-gray-100 text-gray-700",
  blocked: "bg-red-100 text-red-700",
  suspended: "bg-yellow-100 text-yellow-700",
};

export default function MechanicsClient({
  initialMechanics,
}: {
  initialMechanics: Mechanic[];
}) {
  const [mechanicsList, setMechanicsList] = useState(initialMechanics);
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [editingMechanic, setEditingMechanic] = useState<Mechanic | null>(null);
  const [form, setForm] = useState({
    name: "", email: "", phone: "", specialization: "", experience: 0,
    status: "active", certifications: "",
  });
  const [selectedMechanic, setSelectedMechanic] = useState<Mechanic | null>(null);

  const filtered = mechanicsList.filter((m) => {
    const matchSearch =
      m.name.toLowerCase().includes(search.toLowerCase()) ||
      (m.specialization || "").toLowerCase().includes(search.toLowerCase()) ||
      m.phone.includes(search);
    const matchStatus = !filterStatus || m.status === filterStatus;
    return matchSearch && matchStatus;
  });

  const openAdd = () => {
    setEditingMechanic(null);
    setForm({ name: "", email: "", phone: "", specialization: "", experience: 0, status: "active", certifications: "" });
    setShowModal(true);
  };

  const openEdit = (m: Mechanic) => {
    setEditingMechanic(m);
    setForm({
      name: m.name, email: m.email, phone: m.phone,
      specialization: m.specialization || "", experience: m.experience || 0,
      status: m.status, certifications: m.certifications || "",
    });
    setShowModal(true);
  };

  const handleSave = async () => {
    if (editingMechanic) {
      const res = await fetch(`/api/mechanics/${editingMechanic.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const updated = await res.json();
      setMechanicsList((prev) =>
        prev.map((m) => (m.id === editingMechanic.id ? { ...m, ...updated } : m))
      );
    } else {
      const res = await fetch("/api/mechanics", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const created = await res.json();
      setMechanicsList((prev) => [created, ...prev]);
    }
    setShowModal(false);
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Are you sure you want to delete this mechanic?")) return;
    await fetch(`/api/mechanics/${id}`, { method: "DELETE" });
    setMechanicsList((prev) => prev.filter((m) => m.id !== id));
  };

  const toggleVerification = async (m: Mechanic) => {
    const res = await fetch(`/api/mechanics/${m.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...m, isVerified: !m.isVerified }),
    });
    const updated = await res.json();
    setMechanicsList((prev) =>
      prev.map((mech) => (mech.id === m.id ? { ...mech, ...updated } : mech))
    );
  };

  return (
    <DashboardLayout>
      <div className="mb-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Mechanic Management</h1>
            <p className="text-sm text-gray-500 mt-1">Manage mechanics, verify credentials, and track performance</p>
          </div>
          <button onClick={openAdd} className="btn-primary flex items-center gap-2">
            <span>+</span> Add Mechanic
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-6">
        <div className="kpi-card border-l-4 border-l-green-500">
          <div className="w-10 h-10 rounded-lg bg-green-50 text-green-700 flex items-center justify-center text-lg">✅</div>
          <div>
            <p className="text-xs text-gray-500">Available</p>
            <p className="text-xl font-bold text-gray-800">{mechanicsList.filter(m => m.isAvailable).length}</p>
          </div>
        </div>
        <div className="kpi-card border-l-4 border-l-blue-500">
          <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center text-lg">🔒</div>
          <div>
            <p className="text-xs text-gray-500">Verified</p>
            <p className="text-xl font-bold text-gray-800">{mechanicsList.filter(m => m.isVerified).length}</p>
          </div>
        </div>
        <div className="kpi-card border-l-4 border-l-orange-500">
          <div className="w-10 h-10 rounded-lg bg-orange-50 text-orange-700 flex items-center justify-center text-lg">🔧</div>
          <div>
            <p className="text-xs text-gray-500">Total Jobs</p>
            <p className="text-xl font-bold text-gray-800">{mechanicsList.reduce((acc, m) => acc + (m.jobsCompleted || 0), 0)}</p>
          </div>
        </div>
        <div className="kpi-card border-l-4 border-l-purple-500">
          <div className="w-10 h-10 rounded-lg bg-purple-50 text-purple-700 flex items-center justify-center text-lg">⭐</div>
          <div>
            <p className="text-xs text-gray-500">Avg Rating</p>
            <p className="text-xl font-bold text-gray-800">
              {(mechanicsList.reduce((acc, m) => acc + parseFloat(m.rating || "0"), 0) / (mechanicsList.length || 1)).toFixed(1)}
            </p>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="card mb-6">
        <div className="flex flex-wrap gap-4">
          <input
            type="text"
            placeholder="Search by name, specialization, phone..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="input-field max-w-sm"
          />
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="input-field max-w-[200px]"
          >
            <option value="">All Status</option>
            <option value="active">Active</option>
            <option value="suspended">Suspended</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>

      {/* Mechanic Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map((m) => (
          <div key={m.id} className="card hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-accent/10 text-accent flex items-center justify-center font-bold text-lg">
                  {m.name.charAt(0)}
                </div>
                <div>
                  <h3 className="font-semibold text-gray-800 flex items-center gap-2">
                    {m.name}
                    {m.isVerified && <span className="text-blue-500 text-sm">✓</span>}
                  </h3>
                  <p className="text-xs text-gray-500">{m.specialization || "General"}</p>
                </div>
              </div>
              <span className={`badge ${statusColors[m.status]}`}>{m.status}</span>
            </div>

            <div className="grid grid-cols-2 gap-2 mb-3 text-sm">
              <div className="bg-gray-50 rounded p-2">
                <p className="text-xs text-gray-400">Experience</p>
                <p className="font-medium">{m.experience || 0} years</p>
              </div>
              <div className="bg-gray-50 rounded p-2">
                <p className="text-xs text-gray-400">Jobs Done</p>
                <p className="font-medium">{m.jobsCompleted || 0}</p>
              </div>
              <div className="bg-gray-50 rounded p-2">
                <p className="text-xs text-gray-400">Rating</p>
                <p className="font-medium">⭐ {m.rating || "0"}</p>
              </div>
              <div className="bg-gray-50 rounded p-2">
                <p className="text-xs text-gray-400">Earnings</p>
                <p className="font-medium">₹{Number(m.earnings || 0).toLocaleString("en-IN")}</p>
              </div>
            </div>

            <div className="flex items-center gap-1 mb-3">
              <span className={`w-2 h-2 rounded-full ${m.isAvailable ? "bg-green-500" : "bg-red-500"}`}></span>
              <span className="text-xs text-gray-500">{m.isAvailable ? "Available" : "Busy"}</span>
            </div>

            <div className="flex gap-2">
              <button onClick={() => setSelectedMechanic(m)} className="text-xs px-3 py-1.5 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 flex-1">
                View
              </button>
              <button onClick={() => openEdit(m)} className="text-xs px-3 py-1.5 bg-gray-50 text-gray-600 rounded-lg hover:bg-gray-100 flex-1">
                Edit
              </button>
              <button onClick={() => toggleVerification(m)} className="text-xs px-3 py-1.5 bg-indigo-50 text-indigo-600 rounded-lg hover:bg-indigo-100 flex-1">
                {m.isVerified ? "Unverify" : "Verify"}
              </button>
              <button onClick={() => handleDelete(m.id)} className="text-xs px-3 py-1.5 bg-red-50 text-red-600 rounded-lg hover:bg-red-100">
                🗑
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 w-full max-w-md mx-4 shadow-xl">
            <h2 className="text-lg font-bold text-gray-800 mb-4">
              {editingMechanic ? "Edit Mechanic" : "Add New Mechanic"}
            </h2>
            <div className="space-y-3">
              <input type="text" placeholder="Full Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="input-field" />
              <input type="email" placeholder="Email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="input-field" />
              <input type="tel" placeholder="Phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="input-field" />
              <input type="text" placeholder="Specialization" value={form.specialization} onChange={(e) => setForm({ ...form, specialization: e.target.value })} className="input-field" />
              <input type="number" placeholder="Experience (years)" value={form.experience} onChange={(e) => setForm({ ...form, experience: parseInt(e.target.value) || 0 })} className="input-field" />
              <input type="text" placeholder="Certifications" value={form.certifications} onChange={(e) => setForm({ ...form, certifications: e.target.value })} className="input-field" />
              <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })} className="input-field">
                <option value="active">Active</option>
                <option value="suspended">Suspended</option>
                <option value="inactive">Inactive</option>
              </select>
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={handleSave} className="btn-primary flex-1">{editingMechanic ? "Update" : "Create"}</button>
              <button onClick={() => setShowModal(false)} className="btn-outline flex-1">Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* Profile Modal */}
      {selectedMechanic && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 w-full max-w-lg mx-4 shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-gray-800">Mechanic Profile</h2>
              <button onClick={() => setSelectedMechanic(null)} className="text-gray-400 hover:text-gray-600 text-xl">×</button>
            </div>
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 rounded-full bg-accent/10 text-accent flex items-center justify-center font-bold text-2xl">
                {selectedMechanic.name.charAt(0)}
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-800 flex items-center gap-2">
                  {selectedMechanic.name}
                  {selectedMechanic.isVerified && <span className="text-blue-500">✓ Verified</span>}
                </h3>
                <p className="text-sm text-gray-500">{selectedMechanic.specialization || "General Mechanic"}</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className={`badge ${statusColors[selectedMechanic.status]}`}>{selectedMechanic.status}</span>
                  <span className={`badge ${selectedMechanic.isAvailable ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}>
                    {selectedMechanic.isAvailable ? "Available" : "Busy"}
                  </span>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-gray-50 rounded-lg p-3">
                <p className="text-xs text-gray-500">Phone</p>
                <p className="font-medium text-gray-800">{selectedMechanic.phone}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-3">
                <p className="text-xs text-gray-500">Experience</p>
                <p className="font-medium text-gray-800">{selectedMechanic.experience || 0} years</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-3">
                <p className="text-xs text-gray-500">Jobs Completed</p>
                <p className="font-medium text-gray-800">{selectedMechanic.jobsCompleted || 0}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-3">
                <p className="text-xs text-gray-500">Rating</p>
                <p className="font-medium text-gray-800">⭐ {selectedMechanic.rating || "0"}/5.0</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-3">
                <p className="text-xs text-gray-500">Total Earnings</p>
                <p className="font-medium text-gray-800">₹{Number(selectedMechanic.earnings || 0).toLocaleString("en-IN")}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-3">
                <p className="text-xs text-gray-500">Email</p>
                <p className="font-medium text-gray-800 text-xs">{selectedMechanic.email}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-3 col-span-2">
                <p className="text-xs text-gray-500">Certifications</p>
                <p className="font-medium text-gray-800">{selectedMechanic.certifications || "None listed"}</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}
