import { db } from "@/db";
import { mechanics } from "@/db/schema";
import { desc } from "drizzle-orm";
import MechanicsClient from "./MechanicsClient";

export const dynamic = "force-dynamic";

export default async function MechanicsPage() {
  let mechanicList: Array<{
    id: number;
    name: string;
    email: string;
    phone: string;
    specialization: string | null;
    experience: number | null;
    status: "active" | "inactive" | "blocked" | "suspended";
    isVerified: boolean | null;
    isAvailable: boolean | null;
    jobsCompleted: number | null;
    rating: string | null;
    earnings: string | null;
    certifications: string | null;
    createdAt: Date;
  }> = [];

  try {
    mechanicList = await db.select().from(mechanics).orderBy(desc(mechanics.createdAt));
  } catch {
    // tables may not exist yet
  }

  return <MechanicsClient initialMechanics={mechanicList} />;
}
