"use client";

import DashboardLayout from "@/components/DashboardLayout";
import RevenueChart from "@/components/charts/RevenueChart";
import ServiceTrendsChart from "@/components/charts/ServiceTrendsChart";
import MechanicPerformanceChart from "@/components/charts/MechanicPerformanceChart";
import VehicleTypesChart from "@/components/charts/VehicleTypesChart";

interface DashboardData {
  totalCustomers: number;
  totalMechanics: number;
  activeRequests: number;
  pendingRequests: number;
  completedServices: number;
  revenue: number;
  satisfactionRate: number;
  todayRegistrations: number;
  unreadNotifications: number;
}

interface KpiCard {
  key: keyof DashboardData;
  label: string;
  icon: string;
  color: string;
  borderColor: string;
  isCurrency?: boolean;
  isRating?: boolean;
}

const kpiCards: KpiCard[] = [
  { key: "totalCustomers", label: "Total Customers", icon: "👥", color: "bg-blue-50 text-blue-700", borderColor: "border-l-4 border-l-blue-500" },
  { key: "totalMechanics", label: "Total Mechanics", icon: "🔧", color: "bg-orange-50 text-orange-700", borderColor: "border-l-4 border-l-orange-500" },
  { key: "activeRequests", label: "Active Requests", icon: "🛠️", color: "bg-green-50 text-green-700", borderColor: "border-l-4 border-l-green-500" },
  { key: "pendingRequests", label: "Pending Requests", icon: "⏳", color: "bg-yellow-50 text-yellow-700", borderColor: "border-l-4 border-l-yellow-500" },
  { key: "completedServices", label: "Completed Services", icon: "✅", color: "bg-emerald-50 text-emerald-700", borderColor: "border-l-4 border-l-emerald-500" },
  { key: "revenue", label: "Revenue Generated", icon: "💰", color: "bg-purple-50 text-purple-700", borderColor: "border-l-4 border-l-purple-500", isCurrency: true },
  { key: "satisfactionRate", label: "Satisfaction Rate", icon: "⭐", color: "bg-pink-50 text-pink-700", borderColor: "border-l-4 border-l-pink-500", isRating: true },
  { key: "todayRegistrations", label: "Today's Registrations", icon: "📝", color: "bg-indigo-50 text-indigo-700", borderColor: "border-l-4 border-l-indigo-500" },
];

export default function DashboardClient({ data }: { data: DashboardData }) {
  const formatValue = (card: KpiCard) => {
    const value = data[card.key];
    if (card.isCurrency) return `₹${Number(value).toLocaleString("en-IN")}`;
    if (card.isRating) return `${value}/5.0`;
    return String(value);
  };

  return (
    <DashboardLayout unreadCount={data.unreadNotifications}>
      {/* Page Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">
          Dashboard Overview
        </h1>
        <p className="text-sm text-gray-500 mt-1">
          Welcome back, Admin. Here&apos;s what&apos;s happening at Automobile Indian Garage today.
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {kpiCards.map((card) => (
          <div
            key={card.key}
            className={`kpi-card ${card.borderColor}`}
          >
            <div className={`w-12 h-12 rounded-lg ${card.color} flex items-center justify-center text-xl`}>
              {card.icon}
            </div>
            <div>
              <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">
                {card.label}
              </p>
              <p className="text-xl font-bold text-gray-800 mt-0.5">
                {formatValue(card)}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <RevenueChart />
        <ServiceTrendsChart />
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <MechanicPerformanceChart />
        <VehicleTypesChart />
      </div>

      {/* Recent Activity */}
      <div className="card">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">
          Recent Activity
        </h3>
        <div className="space-y-3">
          {[
            { icon: "🔔", text: "Emergency breakdown alert from Neha Joshi at Hinjewadi", time: "2 min ago", type: "emergency" },
            { icon: "👤", text: "New customer Kavita Reddy registered", time: "15 min ago", type: "registration" },
            { icon: "💳", text: "Payment of ₹8,500 received from Manoj Tiwari", time: "1 hour ago", type: "payment" },
            { icon: "🔧", text: "Mechanic Ganesh Bhosale marked unavailable", time: "2 hours ago", type: "availability" },
            { icon: "⭐", text: "New 5-star review from Rajesh Kumar for Suresh Yadav", time: "3 hours ago", type: "review" },
            { icon: "🛠️", text: "Service request #SR-007 assigned to Prakash More", time: "4 hours ago", type: "service" },
          ].map((activity, idx) => (
            <div
              key={idx}
              className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <span className="text-lg">{activity.icon}</span>
              <div className="flex-1">
                <p className="text-sm text-gray-700">{activity.text}</p>
              </div>
              <span className="text-xs text-gray-400 whitespace-nowrap">
                {activity.time}
              </span>
            </div>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
