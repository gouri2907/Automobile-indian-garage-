import { db } from "@/db";
import { customers, mechanics, serviceRequests, payments, notifications } from "@/db/schema";
import { eq, sql, count } from "drizzle-orm";
import { seed } from "@/db/seed";
import DashboardClient from "./DashboardClient";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  // Auto-seed on first load
  try {
    await seed();
  } catch {
    // Seed may fail if tables don't exist yet - that's ok
  }

  let dashboardData;
  try {
    const [customerCount] = await db.select({ count: count() }).from(customers);
    const [mechanicCount] = await db.select({ count: count() }).from(mechanics);
    const [activeReqs] = await db.select({ count: count() }).from(serviceRequests).where(eq(serviceRequests.status, "in_progress"));
    const [pendingReqs] = await db.select({ count: count() }).from(serviceRequests).where(eq(serviceRequests.status, "unassigned"));
    const [completedSvc] = await db.select({ count: count() }).from(serviceRequests).where(eq(serviceRequests.status, "completed"));
    const [revenueResult] = await db.select({ total: sql<string>`COALESCE(SUM(${payments.amount}::numeric), 0)` }).from(payments).where(eq(payments.paymentStatus, "completed"));
    const [unreadNotifs] = await db.select({ count: count() }).from(notifications).where(eq(notifications.isRead, false));

    dashboardData = {
      totalCustomers: customerCount.count,
      totalMechanics: mechanicCount.count,
      activeRequests: activeReqs.count,
      pendingRequests: pendingReqs.count,
      completedServices: completedSvc.count,
      revenue: parseFloat(revenueResult.total || "0"),
      satisfactionRate: 4.5,
      todayRegistrations: 3,
      unreadNotifications: unreadNotifs.count,
    };
  } catch {
    dashboardData = {
      totalCustomers: 0,
      totalMechanics: 0,
      activeRequests: 0,
      pendingRequests: 0,
      completedServices: 0,
      revenue: 0,
      satisfactionRate: 0,
      todayRegistrations: 0,
      unreadNotifications: 0,
    };
  }

  return <DashboardClient data={dashboardData} />;
}
