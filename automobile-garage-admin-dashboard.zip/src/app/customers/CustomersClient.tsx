"use client";

import { useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";

interface Customer {
  id: number;
  name: string;
  email: string;
  phone: string;
  address: string | null;
  city: string | null;
  status: "active" | "inactive" | "blocked" | "suspended";
  totalSpent: string | null;
  rating: string | null;
  createdAt: Date;
}

const statusColors: Record<string, string> = {
  active: "bg-green-100 text-green-700",
  inactive: "bg-gray-100 text-gray-700",
  blocked: "bg-red-100 text-red-700",
  suspended: "bg-yellow-100 text-yellow-700",
};

export default function CustomersClient({
  initialCustomers,
}: {
  initialCustomers: Customer[];
}) {
  const [customersList, setCustomersList] = useState(initialCustomers);
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [form, setForm] = useState({ name: "", email: "", phone: "", address: "", city: "", status: "active" });
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);

  const filtered = customersList.filter((c) => {
    const matchSearch =
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.email.toLowerCase().includes(search.toLowerCase()) ||
      c.phone.includes(search);
    const matchStatus = !filterStatus || c.status === filterStatus;
    return matchSearch && matchStatus;
  });

  const openAdd = () => {
    setEditingCustomer(null);
    setForm({ name: "", email: "", phone: "", address: "", city: "", status: "active" });
    setShowModal(true);
  };

  const openEdit = (c: Customer) => {
    setEditingCustomer(c);
    setForm({
      name: c.name,
      email: c.email,
      phone: c.phone,
      address: c.address || "",
      city: c.city || "",
      status: c.status,
    });
    setShowModal(true);
  };

  const handleSave = async () => {
    if (editingCustomer) {
      const res = await fetch(`/api/customers/${editingCustomer.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const updated = await res.json();
      setCustomersList((prev) =>
        prev.map((c) => (c.id === editingCustomer.id ? { ...c, ...updated } : c))
      );
    } else {
      const res = await fetch("/api/customers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const created = await res.json();
      setCustomersList((prev) => [created, ...prev]);
    }
    setShowModal(false);
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Are you sure you want to delete this customer?")) return;
    await fetch(`/api/customers/${id}`, { method: "DELETE" });
    setCustomersList((prev) => prev.filter((c) => c.id !== id));
  };

  const toggleStatus = async (c: Customer) => {
    const newStatus = c.status === "active" ? "blocked" : "active";
    const res = await fetch(`/api/customers/${c.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...c, status: newStatus }),
    });
    const updated = await res.json();
    setCustomersList((prev) =>
      prev.map((cust) => (cust.id === c.id ? { ...cust, ...updated } : cust))
    );
  };

  return (
    <DashboardLayout>
      <div className="mb-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">
              Customer Management
            </h1>
            <p className="text-sm text-gray-500 mt-1">
              Manage all registered customers
            </p>
          </div>
          <button onClick={openAdd} className="btn-primary flex items-center gap-2">
            <span>+</span> Add Customer
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="card mb-6">
        <div className="flex flex-wrap gap-4">
          <input
            type="text"
            placeholder="Search by name, email, phone..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="input-field max-w-sm"
          />
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="input-field max-w-[200px]"
          >
            <option value="">All Status</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="blocked">Blocked</option>
          </select>
          <div className="ml-auto text-sm text-gray-500 flex items-center">
            Total: <span className="font-bold text-gray-700 ml-1">{filtered.length}</span> customers
          </div>
        </div>
      </div>

      {/* Customer Table */}
      <div className="card overflow-hidden p-0">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="table-header">Customer</th>
                <th className="table-header">Contact</th>
                <th className="table-header">City</th>
                <th className="table-header">Status</th>
                <th className="table-header">Total Spent</th>
                <th className="table-header">Rating</th>
                <th className="table-header">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filtered.map((c) => (
                <tr key={c.id} className="hover:bg-gray-50 transition-colors">
                  <td className="table-cell">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-sm">
                        {c.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-medium text-gray-800">{c.name}</p>
                        <p className="text-xs text-gray-400">{c.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="table-cell">{c.phone}</td>
                  <td className="table-cell">{c.city || "-"}</td>
                  <td className="table-cell">
                    <span className={`badge ${statusColors[c.status]}`}>
                      {c.status}
                    </span>
                  </td>
                  <td className="table-cell font-medium">
                    ₹{Number(c.totalSpent || 0).toLocaleString("en-IN")}
                  </td>
                  <td className="table-cell">
                    <span className="flex items-center gap-1">
                      ⭐ {c.rating || "0"}
                    </span>
                  </td>
                  <td className="table-cell">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setSelectedCustomer(c)}
                        className="text-xs px-2 py-1 bg-blue-50 text-blue-600 rounded hover:bg-blue-100"
                      >
                        View
                      </button>
                      <button
                        onClick={() => openEdit(c)}
                        className="text-xs px-2 py-1 bg-gray-50 text-gray-600 rounded hover:bg-gray-100"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => toggleStatus(c)}
                        className={`text-xs px-2 py-1 rounded ${
                          c.status === "active"
                            ? "bg-red-50 text-red-600 hover:bg-red-100"
                            : "bg-green-50 text-green-600 hover:bg-green-100"
                        }`}
                      >
                        {c.status === "active" ? "Block" : "Activate"}
                      </button>
                      <button
                        onClick={() => handleDelete(c.id)}
                        className="text-xs px-2 py-1 bg-red-50 text-red-600 rounded hover:bg-red-100"
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 w-full max-w-md mx-4 shadow-xl">
            <h2 className="text-lg font-bold text-gray-800 mb-4">
              {editingCustomer ? "Edit Customer" : "Add New Customer"}
            </h2>
            <div className="space-y-3">
              <input
                type="text"
                placeholder="Full Name"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="input-field"
              />
              <input
                type="email"
                placeholder="Email Address"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className="input-field"
              />
              <input
                type="tel"
                placeholder="Phone Number"
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                className="input-field"
              />
              <input
                type="text"
                placeholder="Address"
                value={form.address}
                onChange={(e) => setForm({ ...form, address: e.target.value })}
                className="input-field"
              />
              <input
                type="text"
                placeholder="City"
                value={form.city}
                onChange={(e) => setForm({ ...form, city: e.target.value })}
                className="input-field"
              />
              <select
                value={form.status}
                onChange={(e) => setForm({ ...form, status: e.target.value })}
                className="input-field"
              >
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
                <option value="blocked">Blocked</option>
              </select>
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={handleSave} className="btn-primary flex-1">
                {editingCustomer ? "Update" : "Create"}
              </button>
              <button onClick={() => setShowModal(false)} className="btn-outline flex-1">
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Customer Profile Modal */}
      {selectedCustomer && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 w-full max-w-lg mx-4 shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-gray-800">Customer Profile</h2>
              <button onClick={() => setSelectedCustomer(null)} className="text-gray-400 hover:text-gray-600 text-xl">×</button>
            </div>
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-2xl">
                {selectedCustomer.name.charAt(0)}
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-800">{selectedCustomer.name}</h3>
                <p className="text-sm text-gray-500">{selectedCustomer.email}</p>
                <span className={`badge mt-1 ${statusColors[selectedCustomer.status]}`}>
                  {selectedCustomer.status}
                </span>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 rounded-lg p-3">
                <p className="text-xs text-gray-500">Phone</p>
                <p className="font-medium text-gray-800">{selectedCustomer.phone}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-3">
                <p className="text-xs text-gray-500">City</p>
                <p className="font-medium text-gray-800">{selectedCustomer.city || "-"}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-3">
                <p className="text-xs text-gray-500">Total Spent</p>
                <p className="font-medium text-gray-800">₹{Number(selectedCustomer.totalSpent || 0).toLocaleString("en-IN")}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-3">
                <p className="text-xs text-gray-500">Rating</p>
                <p className="font-medium text-gray-800">⭐ {selectedCustomer.rating || "0"}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-3 col-span-2">
                <p className="text-xs text-gray-500">Address</p>
                <p className="font-medium text-gray-800">{selectedCustomer.address || "Not provided"}</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}
