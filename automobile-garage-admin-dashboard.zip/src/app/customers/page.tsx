import { db } from "@/db";
import { customers } from "@/db/schema";
import { desc } from "drizzle-orm";
import CustomersClient from "./CustomersClient";

export const dynamic = "force-dynamic";

export default async function CustomersPage() {
  let customerList: Array<{
    id: number;
    name: string;
    email: string;
    phone: string;
    address: string | null;
    city: string | null;
    status: "active" | "inactive" | "blocked" | "suspended";
    totalSpent: string | null;
    rating: string | null;
    createdAt: Date;
  }> = [];

  try {
    customerList = await db
      .select()
      .from(customers)
      .orderBy(desc(customers.createdAt));
  } catch {
    // tables may not exist yet
  }

  return <CustomersClient initialCustomers={customerList} />;
}
