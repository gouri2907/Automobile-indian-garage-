import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Automobile Indian Garage - Admin Panel",
  description: "Enterprise-level Admin Dashboard for Indian Automobile Garage Management System",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-gray-bg text-gray-800 antialiased">
        {children}
      </body>
    </html>
  );
}
