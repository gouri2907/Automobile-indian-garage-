import { db } from "@/db";
import { vehicles, customers } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import VehiclesClient from "./VehiclesClient";

export const dynamic = "force-dynamic";

export default async function VehiclesPage() {
  let vehicleList: Array<{
    id: number;
    customerId: number | null;
    make: string;
    model: string;
    year: number | null;
    registrationNumber: string;
    color: string | null;
    fuelType: string | null;
    vehicleType: string | null;
    lastServiceDate: Date | null;
    createdAt: Date;
    customerName: string | null;
  }> = [];

  try {
    vehicleList = await db
      .select({
        id: vehicles.id,
        customerId: vehicles.customerId,
        make: vehicles.make,
        model: vehicles.model,
        year: vehicles.year,
        registrationNumber: vehicles.registrationNumber,
        color: vehicles.color,
        fuelType: vehicles.fuelType,
        vehicleType: vehicles.vehicleType,
        lastServiceDate: vehicles.lastServiceDate,
        createdAt: vehicles.createdAt,
        customerName: customers.name,
      })
      .from(vehicles)
      .leftJoin(customers, eq(vehicles.customerId, customers.id))
      .orderBy(desc(vehicles.createdAt));
  } catch {
    // tables may not exist yet
  }

  return <VehiclesClient initialVehicles={vehicleList} />;
}
