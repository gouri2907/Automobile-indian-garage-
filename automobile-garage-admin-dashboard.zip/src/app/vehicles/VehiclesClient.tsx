"use client";

import { useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";

interface Vehicle {
  id: number;
  customerId: number | null;
  make: string;
  model: string;
  year: number | null;
  registrationNumber: string;
  color: string | null;
  fuelType: string | null;
  vehicleType: string | null;
  lastServiceDate: Date | null;
  createdAt: Date;
  customerName: string | null;
}

const vehicleTypeIcons: Record<string, string> = {
  SUV: "🚙", Hatchback: "🚗", Sedan: "🏎️", MPV: "🚐", Others: "🚘",
};

export default function VehiclesClient({ initialVehicles }: { initialVehicles: Vehicle[] }) {
  const [search, setSearch] = useState("");
  const [filterType, setFilterType] = useState("");

  const filtered = initialVehicles.filter((v) => {
    const matchSearch =
      v.registrationNumber.toLowerCase().includes(search.toLowerCase()) ||
      v.make.toLowerCase().includes(search.toLowerCase()) ||
      v.model.toLowerCase().includes(search.toLowerCase()) ||
      (v.customerName || "").toLowerCase().includes(search.toLowerCase());
    const matchType = !filterType || v.vehicleType === filterType;
    return matchSearch && matchType;
  });

  const vehicleTypes = [...new Set(initialVehicles.map((v) => v.vehicleType).filter(Boolean))];

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Vehicle Management</h1>
        <p className="text-sm text-gray-500 mt-1">Track all registered vehicles and their service history</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-6">
        <div className="kpi-card border-l-4 border-l-blue-500">
          <span className="text-2xl">🚗</span>
          <div>
            <p className="text-xs text-gray-500">Total Vehicles</p>
            <p className="text-xl font-bold">{initialVehicles.length}</p>
          </div>
        </div>
        {vehicleTypes.slice(0, 3).map((type) => (
          <div key={type} className="kpi-card border-l-4 border-l-orange-500">
            <span className="text-2xl">{vehicleTypeIcons[type || "Others"] || "🚘"}</span>
            <div>
              <p className="text-xs text-gray-500">{type}</p>
              <p className="text-xl font-bold">{initialVehicles.filter(v => v.vehicleType === type).length}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="card mb-6">
        <div className="flex flex-wrap gap-4">
          <input
            type="text"
            placeholder="Search by registration, make, model, owner..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="input-field max-w-sm"
          />
          <select value={filterType} onChange={(e) => setFilterType(e.target.value)} className="input-field max-w-[200px]">
            <option value="">All Types</option>
            {vehicleTypes.map((t) => (
              <option key={t} value={t || ""}>{t}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Vehicles Table */}
      <div className="card overflow-hidden p-0">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="table-header">Vehicle</th>
                <th className="table-header">Registration</th>
                <th className="table-header">Owner</th>
                <th className="table-header">Type</th>
                <th className="table-header">Fuel</th>
                <th className="table-header">Color</th>
                <th className="table-header">Year</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filtered.map((v) => (
                <tr key={v.id} className="hover:bg-gray-50 transition-colors">
                  <td className="table-cell">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{vehicleTypeIcons[v.vehicleType || "Others"] || "🚘"}</span>
                      <div>
                        <p className="font-medium text-gray-800">{v.make} {v.model}</p>
                      </div>
                    </div>
                  </td>
                  <td className="table-cell">
                    <span className="px-2 py-1 bg-gray-100 rounded font-mono text-sm font-medium">{v.registrationNumber}</span>
                  </td>
                  <td className="table-cell">{v.customerName || "-"}</td>
                  <td className="table-cell">
                    <span className="badge bg-blue-100 text-blue-700">{v.vehicleType || "-"}</span>
                  </td>
                  <td className="table-cell">{v.fuelType || "-"}</td>
                  <td className="table-cell">
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 rounded-full border border-gray-200" style={{
                        backgroundColor: (v.color || "gray").toLowerCase(),
                      }}></div>
                      {v.color || "-"}
                    </div>
                  </td>
                  <td className="table-cell">{v.year || "-"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </DashboardLayout>
  );
}
