"use client";

import DashboardLayout from "@/components/DashboardLayout";

const mechanicLocations = [
  { id: 1, name: "Suresh Yadav", specialization: "Engine Repair", lat: 18.5204, lng: 73.8567, status: "available", currentJob: null },
  { id: 2, name: "Ravi Patil", specialization: "AC & Electrical", lat: 18.5314, lng: 73.8446, status: "on_job", currentJob: "AC Repair for Priya Sharma" },
  { id: 3, name: "Ganesh Bhosale", specialization: "Body & Paint", lat: 18.5074, lng: 73.8077, status: "busy", currentJob: "Dent Repair for Amit Patel" },
  { id: 4, name: "Mohammad Shaikh", specialization: "Transmission", lat: 18.5596, lng: 73.7794, status: "on_job", currentJob: "Clutch Replacement for Vikram Singh" },
  { id: 5, name: "Prakash More", specialization: "General Service", lat: 18.4970, lng: 73.8700, status: "available", currentJob: null },
  { id: 7, name: "Deepak Jadhav", specialization: "Tyre & Wheel", lat: 18.5100, lng: 73.8300, status: "available", currentJob: null },
  { id: 8, name: "Santosh Gaikwad", specialization: "Diagnostics", lat: 18.4800, lng: 73.8600, status: "on_job", currentJob: "Engine Diagnostics for Amit Patel" },
];

const emergencyRequests = [
  { id: 1, customer: "Neha Joshi", issue: "Battery failure", location: "Hinjewadi, Pune", lat: 18.5913, lng: 73.7389, time: "5 min ago" },
];

const statusColors: Record<string, string> = {
  available: "bg-green-500",
  on_job: "bg-yellow-500",
  busy: "bg-red-500",
};

const statusLabels: Record<string, string> = {
  available: "Available",
  on_job: "On Job",
  busy: "Busy",
};

export default function TrackingPage() {
  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Live GPS Tracking</h1>
        <p className="text-sm text-gray-500 mt-1">Monitor mechanics and customers in real-time on the map</p>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Map Area */}
        <div className="xl:col-span-2">
          <div className="card p-0 overflow-hidden">
            <div className="relative w-full h-[600px] bg-gradient-to-br from-blue-50 to-green-50">
              {/* Simulated Map */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="relative w-full h-full">
                  {/* Grid lines for map effect */}
                  <div className="absolute inset-0 opacity-10">
                    {Array.from({ length: 20 }).map((_, i) => (
                      <div key={`h-${i}`} className="absolute w-full border-t border-gray-400" style={{ top: `${i * 5}%` }} />
                    ))}
                    {Array.from({ length: 20 }).map((_, i) => (
                      <div key={`v-${i}`} className="absolute h-full border-l border-gray-400" style={{ left: `${i * 5}%` }} />
                    ))}
                  </div>

                  {/* Map Title */}
                  <div className="absolute top-4 left-4 bg-white/90 backdrop-blur rounded-lg px-4 py-2 shadow-md z-10">
                    <p className="text-sm font-semibold text-gray-700">📍 Pune, Maharashtra</p>
                    <p className="text-xs text-gray-500">Live tracking view</p>
                  </div>

                  {/* Mechanic Markers */}
                  {mechanicLocations.map((m, idx) => (
                    <div
                      key={m.id}
                      className="absolute group"
                      style={{
                        left: `${15 + idx * 10}%`,
                        top: `${20 + (idx % 3) * 20}%`,
                      }}
                    >
                      <div className="relative">
                        <div className={`w-10 h-10 rounded-full border-3 border-white shadow-lg flex items-center justify-center text-lg bg-white cursor-pointer hover:scale-110 transition-transform`}>
                          🔧
                        </div>
                        <div className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full ${statusColors[m.status]} border-2 border-white`}></div>
                      </div>
                      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 bg-white rounded-lg shadow-lg p-3 w-48 opacity-0 group-hover:opacity-100 transition-opacity z-20 pointer-events-none">
                        <p className="font-semibold text-sm text-gray-800">{m.name}</p>
                        <p className="text-xs text-gray-500">{m.specialization}</p>
                        <div className="flex items-center gap-1 mt-1">
                          <span className={`w-2 h-2 rounded-full ${statusColors[m.status]}`}></span>
                          <span className="text-xs text-gray-600">{statusLabels[m.status]}</span>
                        </div>
                        {m.currentJob && (
                          <p className="text-xs text-blue-600 mt-1">🛠️ {m.currentJob}</p>
                        )}
                      </div>
                    </div>
                  ))}

                  {/* Emergency Marker */}
                  {emergencyRequests.map((e, idx) => (
                    <div
                      key={e.id}
                      className="absolute"
                      style={{
                        left: `${75 + idx * 5}%`,
                        top: "35%",
                      }}
                    >
                      <div className="relative animate-bounce">
                        <div className="w-10 h-10 rounded-full bg-red-500 border-3 border-white shadow-lg flex items-center justify-center text-lg cursor-pointer">
                          🚨
                        </div>
                        <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-red-500 animate-ping"></div>
                      </div>
                      <div className="mt-1 bg-red-50 border border-red-200 rounded px-2 py-1">
                        <p className="text-[10px] font-medium text-red-700">{e.customer}</p>
                        <p className="text-[10px] text-red-500">{e.issue}</p>
                      </div>
                    </div>
                  ))}

                  {/* Map Legend */}
                  <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur rounded-lg p-3 shadow-md">
                    <p className="text-xs font-semibold text-gray-700 mb-2">Legend</p>
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="w-3 h-3 rounded-full bg-green-500"></span>
                        <span className="text-xs text-gray-600">Available</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="w-3 h-3 rounded-full bg-yellow-500"></span>
                        <span className="text-xs text-gray-600">On Job</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="w-3 h-3 rounded-full bg-red-500"></span>
                        <span className="text-xs text-gray-600">Busy / Emergency</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar Panel */}
        <div className="space-y-4">
          {/* Emergency Alerts */}
          {emergencyRequests.length > 0 && (
            <div className="card border-l-4 border-l-red-500 bg-red-50">
              <h3 className="font-semibold text-red-700 flex items-center gap-2 mb-3">
                🚨 Emergency Requests
              </h3>
              {emergencyRequests.map((e) => (
                <div key={e.id} className="bg-white rounded-lg p-3 border border-red-200">
                  <p className="font-medium text-sm text-gray-800">{e.customer}</p>
                  <p className="text-xs text-red-600">{e.issue}</p>
                  <p className="text-xs text-gray-500 mt-1">📍 {e.location}</p>
                  <p className="text-xs text-gray-400">{e.time}</p>
                  <button className="btn-accent text-xs mt-2 w-full py-1.5">
                    Assign Nearest Mechanic
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Mechanic List */}
          <div className="card">
            <h3 className="font-semibold text-gray-800 mb-3">Mechanic Status</h3>
            <div className="space-y-2">
              {mechanicLocations.map((m) => (
                <div key={m.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50">
                  <div className="relative">
                    <div className="w-8 h-8 rounded-full bg-accent/10 text-accent flex items-center justify-center text-sm font-bold">
                      {m.name.charAt(0)}
                    </div>
                    <span className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full ${statusColors[m.status]} border border-white`}></span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-800 truncate">{m.name}</p>
                    <p className="text-xs text-gray-500 truncate">{m.currentJob || "No active job"}</p>
                  </div>
                  <span className={`badge text-[10px] ${
                    m.status === "available" ? "bg-green-100 text-green-700" :
                    m.status === "on_job" ? "bg-yellow-100 text-yellow-700" :
                    "bg-red-100 text-red-700"
                  }`}>
                    {statusLabels[m.status]}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Active Routes */}
          <div className="card">
            <h3 className="font-semibold text-gray-800 mb-3">Active Service Routes</h3>
            <div className="space-y-2">
              <div className="flex items-center gap-2 p-2 bg-blue-50 rounded-lg">
                <span>🔧</span>
                <div className="flex-1">
                  <p className="text-xs font-medium">Ravi Patil → Priya Sharma</p>
                  <p className="text-[10px] text-gray-500">ETA: 15 mins</p>
                </div>
              </div>
              <div className="flex items-center gap-2 p-2 bg-blue-50 rounded-lg">
                <span>🔧</span>
                <div className="flex-1">
                  <p className="text-xs font-medium">Mohammad Shaikh → Vikram Singh</p>
                  <p className="text-[10px] text-gray-500">ETA: 25 mins</p>
                </div>
              </div>
              <div className="flex items-center gap-2 p-2 bg-blue-50 rounded-lg">
                <span>🔧</span>
                <div className="flex-1">
                  <p className="text-xs font-medium">Santosh Gaikwad → Amit Patel</p>
                  <p className="text-[10px] text-gray-500">ETA: 10 mins</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
