"use client";

import { useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";

interface Negotiation {
  id: number;
  serviceRequestId: number | null;
  customerOffer: string | null;
  mechanicOffer: string | null;
  finalPrice: string | null;
  status: string | null;
  adminApproved: boolean | null;
  createdAt: Date;
  customerName: string | null;
  mechanicName: string | null;
  serviceType: string | null;
}

const statusColors: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-700",
  accepted: "bg-green-100 text-green-700",
  rejected: "bg-red-100 text-red-700",
};

export default function NegotiationsClient({
  initialNegotiations,
}: {
  initialNegotiations: Negotiation[];
}) {
  const [negotiationsList, setNegotiationsList] = useState(initialNegotiations);

  const handleApprove = async (n: Negotiation) => {
    const res = await fetch(`/api/negotiations/${n.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ adminApproved: true, status: "accepted" }),
    });
    const updated = await res.json();
    setNegotiationsList((prev) =>
      prev.map((neg) => (neg.id === n.id ? { ...neg, ...updated } : neg))
    );
  };

  const handleReject = async (n: Negotiation) => {
    const res = await fetch(`/api/negotiations/${n.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ adminApproved: false, status: "rejected" }),
    });
    const updated = await res.json();
    setNegotiationsList((prev) =>
      prev.map((neg) => (neg.id === n.id ? { ...neg, ...updated } : neg))
    );
  };

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Negotiation Management</h1>
        <p className="text-sm text-gray-500 mt-1">Monitor and resolve customer-mechanic price negotiations</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <div className="kpi-card border-l-4 border-l-yellow-500">
          <span className="text-2xl">⏳</span>
          <div>
            <p className="text-xs text-gray-500">Pending</p>
            <p className="text-xl font-bold">{negotiationsList.filter(n => n.status === "pending").length}</p>
          </div>
        </div>
        <div className="kpi-card border-l-4 border-l-green-500">
          <span className="text-2xl">✅</span>
          <div>
            <p className="text-xs text-gray-500">Accepted</p>
            <p className="text-xl font-bold">{negotiationsList.filter(n => n.status === "accepted").length}</p>
          </div>
        </div>
        <div className="kpi-card border-l-4 border-l-red-500">
          <span className="text-2xl">❌</span>
          <div>
            <p className="text-xs text-gray-500">Rejected</p>
            <p className="text-xl font-bold">{negotiationsList.filter(n => n.status === "rejected").length}</p>
          </div>
        </div>
      </div>

      {/* Negotiations Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {negotiationsList.map((n) => (
          <div key={n.id} className="card hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between mb-3">
              <div>
                <h3 className="font-semibold text-gray-800">{n.serviceType || "Service"}</h3>
                <p className="text-xs text-gray-400">SR-{String(n.serviceRequestId).padStart(3, "0")}</p>
              </div>
              <span className={`badge ${statusColors[n.status || "pending"]}`}>
                {n.status || "pending"}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="bg-blue-50 rounded-lg p-3">
                <p className="text-xs text-blue-600 font-medium mb-1">👤 Customer Offer</p>
                <p className="text-lg font-bold text-blue-800">
                  ₹{Number(n.customerOffer || 0).toLocaleString("en-IN")}
                </p>
                <p className="text-xs text-blue-500">{n.customerName || "Unknown"}</p>
              </div>
              <div className="bg-orange-50 rounded-lg p-3">
                <p className="text-xs text-orange-600 font-medium mb-1">🔧 Mechanic Offer</p>
                <p className="text-lg font-bold text-orange-800">
                  ₹{Number(n.mechanicOffer || 0).toLocaleString("en-IN")}
                </p>
                <p className="text-xs text-orange-500">{n.mechanicName || "Unknown"}</p>
              </div>
            </div>

            {n.finalPrice && (
              <div className="bg-green-50 rounded-lg p-3 mb-4">
                <p className="text-xs text-green-600 font-medium">Final Agreed Price</p>
                <p className="text-lg font-bold text-green-800">
                  ₹{Number(n.finalPrice).toLocaleString("en-IN")}
                </p>
              </div>
            )}

            <div className="flex items-center gap-2">
              <span className="text-xs text-gray-400 flex-1">
                {n.adminApproved ? "✅ Admin Approved" : "⏳ Awaiting Admin Approval"}
              </span>
              {n.status === "pending" && (
                <>
                  <button
                    onClick={() => handleApprove(n)}
                    className="text-xs px-3 py-1.5 bg-green-50 text-green-600 rounded-lg hover:bg-green-100"
                  >
                    Approve
                  </button>
                  <button
                    onClick={() => handleReject(n)}
                    className="text-xs px-3 py-1.5 bg-red-50 text-red-600 rounded-lg hover:bg-red-100"
                  >
                    Reject
                  </button>
                </>
              )}
            </div>
          </div>
        ))}
      </div>
    </DashboardLayout>
  );
}
