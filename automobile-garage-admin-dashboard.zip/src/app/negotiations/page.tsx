import { db } from "@/db";
import { negotiations, customers, mechanics, serviceRequests } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import NegotiationsClient from "./NegotiationsClient";

export const dynamic = "force-dynamic";

export default async function NegotiationsPage() {
  let negotiationList: Array<{
    id: number;
    serviceRequestId: number | null;
    customerOffer: string | null;
    mechanicOffer: string | null;
    finalPrice: string | null;
    status: string | null;
    adminApproved: boolean | null;
    createdAt: Date;
    customerName: string | null;
    mechanicName: string | null;
    serviceType: string | null;
  }> = [];

  try {
    negotiationList = await db
      .select({
        id: negotiations.id,
        serviceRequestId: negotiations.serviceRequestId,
        customerOffer: negotiations.customerOffer,
        mechanicOffer: negotiations.mechanicOffer,
        finalPrice: negotiations.finalPrice,
        status: negotiations.status,
        adminApproved: negotiations.adminApproved,
        createdAt: negotiations.createdAt,
        customerName: customers.name,
        mechanicName: mechanics.name,
        serviceType: serviceRequests.serviceType,
      })
      .from(negotiations)
      .leftJoin(customers, eq(negotiations.customerId, customers.id))
      .leftJoin(mechanics, eq(negotiations.mechanicId, mechanics.id))
      .leftJoin(serviceRequests, eq(negotiations.serviceRequestId, serviceRequests.id))
      .orderBy(desc(negotiations.createdAt));
  } catch {
    // tables may not exist yet
  }

  return <NegotiationsClient initialNegotiations={negotiationList} />;
}
