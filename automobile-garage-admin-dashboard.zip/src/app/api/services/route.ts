import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { serviceRequests, customers, mechanics, vehicles } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status") || "";

    let query = db
      .select({
        id: serviceRequests.id,
        customerId: serviceRequests.customerId,
        vehicleId: serviceRequests.vehicleId,
        mechanicId: serviceRequests.mechanicId,
        serviceType: serviceRequests.serviceType,
        description: serviceRequests.description,
        priority: serviceRequests.priority,
        status: serviceRequests.status,
        estimatedCost: serviceRequests.estimatedCost,
        finalCost: serviceRequests.finalCost,
        scheduledDate: serviceRequests.scheduledDate,
        completedDate: serviceRequests.completedDate,
        createdAt: serviceRequests.createdAt,
        customerName: customers.name,
        mechanicName: mechanics.name,
        vehicleReg: vehicles.registrationNumber,
        vehicleMake: vehicles.make,
        vehicleModel: vehicles.model,
      })
      .from(serviceRequests)
      .leftJoin(customers, eq(serviceRequests.customerId, customers.id))
      .leftJoin(mechanics, eq(serviceRequests.mechanicId, mechanics.id))
      .leftJoin(vehicles, eq(serviceRequests.vehicleId, vehicles.id));

    if (status) {
      query = query.where(
        eq(serviceRequests.status, status as "unassigned" | "assigned" | "in_progress" | "completed" | "cancelled")
      ) as typeof query;
    }

    const result = await query.orderBy(desc(serviceRequests.createdAt));
    return NextResponse.json(result);
  } catch (error) {
    console.error("Service fetch error:", error);
    return NextResponse.json({ error: "Failed to fetch services" }, { status: 500 });
  }
}
