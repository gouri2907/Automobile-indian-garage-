import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { serviceRequests } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const updateData: Record<string, unknown> = { updatedAt: new Date() };

    if (body.status) updateData.status = body.status;
    if (body.mechanicId !== undefined) updateData.mechanicId = body.mechanicId;
    if (body.priority) updateData.priority = body.priority;
    if (body.finalCost) updateData.finalCost = body.finalCost;
    if (body.status === "completed") updateData.completedDate = new Date();

    const result = await db
      .update(serviceRequests)
      .set(updateData)
      .where(eq(serviceRequests.id, parseInt(id)))
      .returning();
    return NextResponse.json(result[0]);
  } catch (error) {
    console.error("Service update error:", error);
    return NextResponse.json({ error: "Failed to update service" }, { status: 500 });
  }
}
