import { NextResponse } from "next/server";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { desc, eq, count } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const allNotifs = await db
      .select()
      .from(notifications)
      .orderBy(desc(notifications.createdAt));

    const [unreadCount] = await db
      .select({ count: count() })
      .from(notifications)
      .where(eq(notifications.isRead, false));

    return NextResponse.json({
      notifications: allNotifs,
      unreadCount: unreadCount.count,
    });
  } catch (error) {
    console.error("Notification fetch error:", error);
    return NextResponse.json({ error: "Failed to fetch notifications" }, { status: 500 });
  }
}
