import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { negotiations } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const updateData: Record<string, unknown> = {};

    if (body.adminApproved !== undefined) updateData.adminApproved = body.adminApproved;
    if (body.status) updateData.status = body.status;
    if (body.finalPrice) updateData.finalPrice = body.finalPrice;

    const result = await db
      .update(negotiations)
      .set(updateData)
      .where(eq(negotiations.id, parseInt(id)))
      .returning();
    return NextResponse.json(result[0]);
  } catch (error) {
    console.error("Negotiation update error:", error);
    return NextResponse.json({ error: "Failed to update negotiation" }, { status: 500 });
  }
}
