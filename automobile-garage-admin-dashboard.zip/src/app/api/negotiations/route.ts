import { NextResponse } from "next/server";
import { db } from "@/db";
import { negotiations, customers, mechanics, serviceRequests } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const result = await db
      .select({
        id: negotiations.id,
        serviceRequestId: negotiations.serviceRequestId,
        customerId: negotiations.customerId,
        mechanicId: negotiations.mechanicId,
        customerOffer: negotiations.customerOffer,
        mechanicOffer: negotiations.mechanicOffer,
        finalPrice: negotiations.finalPrice,
        status: negotiations.status,
        adminApproved: negotiations.adminApproved,
        createdAt: negotiations.createdAt,
        customerName: customers.name,
        mechanicName: mechanics.name,
        serviceType: serviceRequests.serviceType,
      })
      .from(negotiations)
      .leftJoin(customers, eq(negotiations.customerId, customers.id))
      .leftJoin(mechanics, eq(negotiations.mechanicId, mechanics.id))
      .leftJoin(serviceRequests, eq(negotiations.serviceRequestId, serviceRequests.id))
      .orderBy(desc(negotiations.createdAt));

    return NextResponse.json(result);
  } catch (error) {
    console.error("Negotiation fetch error:", error);
    return NextResponse.json({ error: "Failed to fetch negotiations" }, { status: 500 });
  }
}
