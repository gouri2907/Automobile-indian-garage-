import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { mechanics } from "@/db/schema";
import { desc, ilike, or, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search") || "";
    const status = searchParams.get("status") || "";

    let query = db.select().from(mechanics);

    if (search) {
      query = query.where(
        or(
          ilike(mechanics.name, `%${search}%`),
          ilike(mechanics.specialization, `%${search}%`),
          ilike(mechanics.phone, `%${search}%`)
        )
      ) as typeof query;
    }

    if (status) {
      query = query.where(eq(mechanics.status, status as "active" | "inactive" | "blocked" | "suspended")) as typeof query;
    }

    const result = await query.orderBy(desc(mechanics.createdAt));
    return NextResponse.json(result);
  } catch (error) {
    console.error("Mechanic fetch error:", error);
    return NextResponse.json({ error: "Failed to fetch mechanics" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const result = await db.insert(mechanics).values({
      name: body.name,
      email: body.email,
      phone: body.phone,
      specialization: body.specialization || null,
      experience: body.experience || 0,
      status: body.status || "active",
      certifications: body.certifications || null,
    }).returning();
    return NextResponse.json(result[0]);
  } catch (error) {
    console.error("Mechanic create error:", error);
    return NextResponse.json({ error: "Failed to create mechanic" }, { status: 500 });
  }
}
