import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { mechanics } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const result = await db
      .update(mechanics)
      .set({
        name: body.name,
        email: body.email,
        phone: body.phone,
        specialization: body.specialization,
        experience: body.experience,
        status: body.status,
        isVerified: body.isVerified,
        isAvailable: body.isAvailable,
        certifications: body.certifications,
        updatedAt: new Date(),
      })
      .where(eq(mechanics.id, parseInt(id)))
      .returning();
    return NextResponse.json(result[0]);
  } catch (error) {
    console.error("Mechanic update error:", error);
    return NextResponse.json({ error: "Failed to update mechanic" }, { status: 500 });
  }
}

export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    await db.delete(mechanics).where(eq(mechanics.id, parseInt(id)));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Mechanic delete error:", error);
    return NextResponse.json({ error: "Failed to delete mechanic" }, { status: 500 });
  }
}
