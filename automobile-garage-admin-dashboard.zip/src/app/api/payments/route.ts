import { NextResponse } from "next/server";
import { db } from "@/db";
import { payments, customers, mechanics, serviceRequests } from "@/db/schema";
import { desc, eq, sql, count } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const allPayments = await db
      .select({
        id: payments.id,
        serviceRequestId: payments.serviceRequestId,
        customerId: payments.customerId,
        mechanicId: payments.mechanicId,
        amount: payments.amount,
        paymentMethod: payments.paymentMethod,
        paymentStatus: payments.paymentStatus,
        transactionId: payments.transactionId,
        createdAt: payments.createdAt,
        customerName: customers.name,
        mechanicName: mechanics.name,
        serviceType: serviceRequests.serviceType,
      })
      .from(payments)
      .leftJoin(customers, eq(payments.customerId, customers.id))
      .leftJoin(mechanics, eq(payments.mechanicId, mechanics.id))
      .leftJoin(serviceRequests, eq(payments.serviceRequestId, serviceRequests.id))
      .orderBy(desc(payments.createdAt));

    const [totalRevenue] = await db
      .select({ total: sql<string>`COALESCE(SUM(${payments.amount}::numeric), 0)` })
      .from(payments)
      .where(eq(payments.paymentStatus, "completed"));

    const [pendingPayments] = await db
      .select({
        count: count(),
        total: sql<string>`COALESCE(SUM(${payments.amount}::numeric), 0)`,
      })
      .from(payments)
      .where(eq(payments.paymentStatus, "pending"));

    return NextResponse.json({
      payments: allPayments,
      totalRevenue: parseFloat(totalRevenue.total || "0"),
      pendingCount: pendingPayments.count,
      pendingTotal: parseFloat(pendingPayments.total || "0"),
    });
  } catch (error) {
    console.error("Payment fetch error:", error);
    return NextResponse.json({ error: "Failed to fetch payments" }, { status: 500 });
  }
}
