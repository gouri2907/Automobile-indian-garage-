import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { vehicles, customers } from "@/db/schema";
import { desc, ilike, or, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search") || "";

    let query = db
      .select({
        id: vehicles.id,
        customerId: vehicles.customerId,
        make: vehicles.make,
        model: vehicles.model,
        year: vehicles.year,
        registrationNumber: vehicles.registrationNumber,
        color: vehicles.color,
        fuelType: vehicles.fuelType,
        vehicleType: vehicles.vehicleType,
        lastServiceDate: vehicles.lastServiceDate,
        createdAt: vehicles.createdAt,
        customerName: customers.name,
      })
      .from(vehicles)
      .leftJoin(customers, eq(vehicles.customerId, customers.id));

    if (search) {
      query = query.where(
        or(
          ilike(vehicles.registrationNumber, `%${search}%`),
          ilike(vehicles.make, `%${search}%`),
          ilike(vehicles.model, `%${search}%`)
        )
      ) as typeof query;
    }

    const result = await query.orderBy(desc(vehicles.createdAt));
    return NextResponse.json(result);
  } catch (error) {
    console.error("Vehicle fetch error:", error);
    return NextResponse.json({ error: "Failed to fetch vehicles" }, { status: 500 });
  }
}
