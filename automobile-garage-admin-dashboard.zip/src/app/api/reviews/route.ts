import { NextResponse } from "next/server";
import { db } from "@/db";
import { reviews, customers, mechanics } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const allReviews = await db
      .select({
        id: reviews.id,
        serviceRequestId: reviews.serviceRequestId,
        customerId: reviews.customerId,
        mechanicId: reviews.mechanicId,
        rating: reviews.rating,
        comment: reviews.comment,
        isFlagged: reviews.isFlagged,
        createdAt: reviews.createdAt,
        customerName: customers.name,
        mechanicName: mechanics.name,
      })
      .from(reviews)
      .leftJoin(customers, eq(reviews.customerId, customers.id))
      .leftJoin(mechanics, eq(reviews.mechanicId, mechanics.id))
      .orderBy(desc(reviews.createdAt));

    return NextResponse.json(allReviews);
  } catch (error) {
    console.error("Review fetch error:", error);
    return NextResponse.json({ error: "Failed to fetch reviews" }, { status: 500 });
  }
}
