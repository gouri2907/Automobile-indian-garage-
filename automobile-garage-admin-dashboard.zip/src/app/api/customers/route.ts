import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { customers } from "@/db/schema";
import { eq, desc, ilike, or } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search") || "";
    const status = searchParams.get("status") || "";

    let query = db.select().from(customers);

    if (search) {
      query = query.where(
        or(
          ilike(customers.name, `%${search}%`),
          ilike(customers.email, `%${search}%`),
          ilike(customers.phone, `%${search}%`)
        )
      ) as typeof query;
    }

    if (status) {
      query = query.where(eq(customers.status, status as "active" | "inactive" | "blocked" | "suspended")) as typeof query;
    }

    const result = await query.orderBy(desc(customers.createdAt));
    return NextResponse.json(result);
  } catch (error) {
    console.error("Customer fetch error:", error);
    return NextResponse.json({ error: "Failed to fetch customers" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const result = await db.insert(customers).values({
      name: body.name,
      email: body.email,
      phone: body.phone,
      address: body.address || null,
      city: body.city || null,
      status: body.status || "active",
    }).returning();
    return NextResponse.json(result[0]);
  } catch (error) {
    console.error("Customer create error:", error);
    return NextResponse.json({ error: "Failed to create customer" }, { status: 500 });
  }
}
