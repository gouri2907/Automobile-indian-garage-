import { NextResponse } from "next/server";
import { db } from "@/db";
import { customers, mechanics, serviceRequests, payments, notifications } from "@/db/schema";
import { eq, sql, count } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const [customerCount] = await db.select({ count: count() }).from(customers);
    const [mechanicCount] = await db.select({ count: count() }).from(mechanics);

    const [activeRequests] = await db
      .select({ count: count() })
      .from(serviceRequests)
      .where(eq(serviceRequests.status, "in_progress"));

    const [pendingRequests] = await db
      .select({ count: count() })
      .from(serviceRequests)
      .where(eq(serviceRequests.status, "unassigned"));

    const [completedServices] = await db
      .select({ count: count() })
      .from(serviceRequests)
      .where(eq(serviceRequests.status, "completed"));

    const [revenueResult] = await db
      .select({ total: sql<string>`COALESCE(SUM(${payments.amount}::numeric), 0)` })
      .from(payments)
      .where(eq(payments.paymentStatus, "completed"));

    const [unreadNotifs] = await db
      .select({ count: count() })
      .from(notifications)
      .where(eq(notifications.isRead, false));

    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    const [todayRegistrations] = await db
      .select({ count: count() })
      .from(customers)
      .where(sql`${customers.createdAt} >= ${todayStart}`);

    return NextResponse.json({
      totalCustomers: customerCount.count,
      totalMechanics: mechanicCount.count,
      activeRequests: activeRequests.count,
      pendingRequests: pendingRequests.count,
      completedServices: completedServices.count,
      revenue: parseFloat(revenueResult.total || "0"),
      satisfactionRate: 4.5,
      todayRegistrations: todayRegistrations.count,
      unreadNotifications: unreadNotifs.count,
    });
  } catch (error) {
    console.error("Dashboard error:", error);
    return NextResponse.json({ error: "Failed to fetch dashboard data" }, { status: 500 });
  }
}
