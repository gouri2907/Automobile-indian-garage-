import { db } from "@/db";
import { serviceRequests, customers, mechanics, vehicles } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import AssignmentsClient from "./AssignmentsClient";

export const dynamic = "force-dynamic";

export default async function AssignmentsPage() {
  let serviceList: Array<{
    id: number;
    serviceType: string;
    description: string | null;
    priority: "low" | "medium" | "high" | "emergency";
    status: "unassigned" | "assigned" | "in_progress" | "completed" | "cancelled";
    estimatedCost: string | null;
    customerName: string | null;
    mechanicName: string | null;
    vehicleReg: string | null;
  }> = [];

  let mechanicList: Array<{ id: number; name: string; specialization: string | null; isAvailable: boolean | null }> = [];

  try {
    serviceList = await db
      .select({
        id: serviceRequests.id,
        serviceType: serviceRequests.serviceType,
        description: serviceRequests.description,
        priority: serviceRequests.priority,
        status: serviceRequests.status,
        estimatedCost: serviceRequests.estimatedCost,
        customerName: customers.name,
        mechanicName: mechanics.name,
        vehicleReg: vehicles.registrationNumber,
      })
      .from(serviceRequests)
      .leftJoin(customers, eq(serviceRequests.customerId, customers.id))
      .leftJoin(mechanics, eq(serviceRequests.mechanicId, mechanics.id))
      .leftJoin(vehicles, eq(serviceRequests.vehicleId, vehicles.id))
      .orderBy(desc(serviceRequests.createdAt));

    mechanicList = await db
      .select({
        id: mechanics.id,
        name: mechanics.name,
        specialization: mechanics.specialization,
        isAvailable: mechanics.isAvailable,
      })
      .from(mechanics)
      .where(eq(mechanics.status, "active"));
  } catch {
    // tables may not exist yet
  }

  return <AssignmentsClient initialServices={serviceList} mechanics={mechanicList} />;
}
