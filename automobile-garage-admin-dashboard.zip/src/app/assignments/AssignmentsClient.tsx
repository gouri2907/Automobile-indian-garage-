"use client";

import { useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";

interface ServiceItem {
  id: number;
  serviceType: string;
  description: string | null;
  priority: "low" | "medium" | "high" | "emergency";
  status: "unassigned" | "assigned" | "in_progress" | "completed" | "cancelled";
  estimatedCost: string | null;
  customerName: string | null;
  mechanicName: string | null;
  vehicleReg: string | null;
}

interface MechanicItem {
  id: number;
  name: string;
  specialization: string | null;
  isAvailable: boolean | null;
}

const columns = [
  { key: "unassigned", label: "Unassigned", color: "border-t-gray-400", bg: "bg-gray-50" },
  { key: "assigned", label: "Assigned", color: "border-t-blue-500", bg: "bg-blue-50" },
  { key: "in_progress", label: "In Progress", color: "border-t-yellow-500", bg: "bg-yellow-50" },
  { key: "completed", label: "Completed", color: "border-t-green-500", bg: "bg-green-50" },
] as const;

const priorityColors: Record<string, string> = {
  low: "bg-gray-100 text-gray-600",
  medium: "bg-blue-100 text-blue-600",
  high: "bg-orange-100 text-orange-600",
  emergency: "bg-red-100 text-red-600 animate-pulse",
};

export default function AssignmentsClient({
  initialServices,
  mechanics,
}: {
  initialServices: ServiceItem[];
  mechanics: MechanicItem[];
}) {
  const [services, setServices] = useState(initialServices);
  const [assignModal, setAssignModal] = useState<ServiceItem | null>(null);
  const [selectedMechanic, setSelectedMechanic] = useState("");

  const handleStatusChange = async (service: ServiceItem, newStatus: string) => {
    await fetch(`/api/services/${service.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: newStatus }),
    });
    setServices((prev) =>
      prev.map((s) =>
        s.id === service.id ? { ...s, status: newStatus as ServiceItem["status"] } : s
      )
    );
  };

  const handleAssign = async () => {
    if (!assignModal || !selectedMechanic) return;
    await fetch(`/api/services/${assignModal.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mechanicId: parseInt(selectedMechanic), status: "assigned" }),
    });
    const mech = mechanics.find((m) => m.id === parseInt(selectedMechanic));
    setServices((prev) =>
      prev.map((s) =>
        s.id === assignModal.id
          ? { ...s, status: "assigned" as const, mechanicName: mech?.name || null }
          : s
      )
    );
    setAssignModal(null);
    setSelectedMechanic("");
  };

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Work Assignment Board</h1>
        <p className="text-sm text-gray-500 mt-1">
          Drag-and-drop style Kanban board for managing work assignments
        </p>
      </div>

      {/* Kanban Board */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {columns.map((col) => {
          const items = services.filter((s) => s.status === col.key);
          return (
            <div key={col.key} className={`rounded-xl ${col.bg} p-4 border-t-4 ${col.color}`}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-gray-700">{col.label}</h3>
                <span className="w-6 h-6 rounded-full bg-white text-sm font-bold text-gray-600 flex items-center justify-center shadow-sm">
                  {items.length}
                </span>
              </div>
              <div className="space-y-3">
                {items.map((service) => (
                  <div
                    key={service.id}
                    className="bg-white rounded-lg p-3 shadow-sm border border-gray-100 hover:shadow-md transition-shadow cursor-pointer"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <span className="text-xs font-mono text-gray-400">
                        SR-{String(service.id).padStart(3, "0")}
                      </span>
                      <span className={`badge text-[10px] ${priorityColors[service.priority]}`}>
                        {service.priority}
                      </span>
                    </div>
                    <h4 className="text-sm font-medium text-gray-800 mb-1">
                      {service.serviceType}
                    </h4>
                    <p className="text-xs text-gray-500 mb-2">
                      👤 {service.customerName || "Unknown"}
                    </p>
                    {service.vehicleReg && (
                      <p className="text-xs text-gray-400 mb-2 font-mono">
                        🚗 {service.vehicleReg}
                      </p>
                    )}
                    {service.mechanicName && (
                      <p className="text-xs text-blue-600 mb-2">
                        🔧 {service.mechanicName}
                      </p>
                    )}
                    {service.estimatedCost && (
                      <p className="text-xs font-medium text-gray-600">
                        ₹{Number(service.estimatedCost).toLocaleString("en-IN")}
                      </p>
                    )}

                    {/* Actions */}
                    <div className="flex gap-1 mt-3 pt-2 border-t border-gray-100">
                      {col.key === "unassigned" && (
                        <button
                          onClick={() => setAssignModal(service)}
                          className="text-[10px] px-2 py-1 bg-blue-50 text-blue-600 rounded hover:bg-blue-100 flex-1"
                        >
                          Assign
                        </button>
                      )}
                      {col.key === "assigned" && (
                        <button
                          onClick={() => handleStatusChange(service, "in_progress")}
                          className="text-[10px] px-2 py-1 bg-yellow-50 text-yellow-600 rounded hover:bg-yellow-100 flex-1"
                        >
                          Start Work
                        </button>
                      )}
                      {col.key === "in_progress" && (
                        <button
                          onClick={() => handleStatusChange(service, "completed")}
                          className="text-[10px] px-2 py-1 bg-green-50 text-green-600 rounded hover:bg-green-100 flex-1"
                        >
                          Complete
                        </button>
                      )}
                      {col.key !== "completed" && (
                        <button
                          onClick={() => handleStatusChange(service, "cancelled")}
                          className="text-[10px] px-2 py-1 bg-red-50 text-red-600 rounded hover:bg-red-100"
                        >
                          Cancel
                        </button>
                      )}
                    </div>
                  </div>
                ))}
                {items.length === 0 && (
                  <div className="text-center py-8 text-gray-400 text-sm">
                    No items
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Assign Modal */}
      {assignModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 w-full max-w-md mx-4 shadow-xl">
            <h2 className="text-lg font-bold text-gray-800 mb-2">Assign Mechanic</h2>
            <p className="text-sm text-gray-500 mb-4">
              Assign a mechanic to <strong>{assignModal.serviceType}</strong> for {assignModal.customerName}
            </p>
            <div className="mb-4">
              <label className="text-sm font-medium text-gray-700 mb-2 block">Select Mechanic</label>
              <select
                value={selectedMechanic}
                onChange={(e) => setSelectedMechanic(e.target.value)}
                className="input-field"
              >
                <option value="">Choose a mechanic...</option>
                {mechanics
                  .filter((m) => m.isAvailable)
                  .map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name} - {m.specialization || "General"}
                    </option>
                  ))}
              </select>
            </div>
            <div className="bg-blue-50 rounded-lg p-3 mb-4">
              <p className="text-xs font-medium text-blue-700 mb-1">💡 Auto Suggestion</p>
              <p className="text-xs text-blue-600">
                Based on skill match and availability, we recommend assigning an available specialist mechanic.
              </p>
            </div>
            <div className="flex gap-3">
              <button onClick={handleAssign} className="btn-primary flex-1" disabled={!selectedMechanic}>
                Assign
              </button>
              <button onClick={() => { setAssignModal(null); setSelectedMechanic(""); }} className="btn-outline flex-1">
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}
