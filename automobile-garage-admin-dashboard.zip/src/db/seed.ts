import { db } from "./index";
import {
  customers,
  mechanics,
  vehicles,
  serviceRequests,
  payments,
  reviews,
  negotiations,
  notifications,
} from "./schema";

export async function seed() {
  // Check if data already exists
  const existingCustomers = await db.select().from(customers).limit(1);
  if (existingCustomers.length > 0) return;

  // Seed Customers
  const customerData = [
    { name: "Rajesh Kumar", email: "rajesh@gmail.com", phone: "9876543210", address: "MG Road, Pune", city: "Pune", status: "active" as const, totalSpent: "45000.00", rating: "4.50" },
    { name: "Priya Sharma", email: "priya@gmail.com", phone: "9876543211", address: "FC Road, Pune", city: "Pune", status: "active" as const, totalSpent: "32000.00", rating: "4.80" },
    { name: "Amit Patel", email: "amit@gmail.com", phone: "9876543212", address: "Bandra, Mumbai", city: "Mumbai", status: "active" as const, totalSpent: "67000.00", rating: "4.20" },
    { name: "Sunita Deshmukh", email: "sunita@gmail.com", phone: "9876543213", address: "Koregaon Park, Pune", city: "Pune", status: "active" as const, totalSpent: "28000.00", rating: "4.60" },
    { name: "Vikram Singh", email: "vikram@gmail.com", phone: "9876543214", address: "Andheri, Mumbai", city: "Mumbai", status: "blocked" as const, totalSpent: "15000.00", rating: "3.50" },
    { name: "Neha Joshi", email: "neha@gmail.com", phone: "9876543215", address: "Hinjewadi, Pune", city: "Pune", status: "active" as const, totalSpent: "52000.00", rating: "4.70" },
    { name: "Rahul Verma", email: "rahul@gmail.com", phone: "9876543216", address: "Wakad, Pune", city: "Pune", status: "active" as const, totalSpent: "38000.00", rating: "4.30" },
    { name: "Deepika Nair", email: "deepika@gmail.com", phone: "9876543217", address: "Viman Nagar, Pune", city: "Pune", status: "active" as const, totalSpent: "41000.00", rating: "4.40" },
    { name: "Manoj Tiwari", email: "manoj@gmail.com", phone: "9876543218", address: "Dadar, Mumbai", city: "Mumbai", status: "active" as const, totalSpent: "73000.00", rating: "4.90" },
    { name: "Kavita Reddy", email: "kavita@gmail.com", phone: "9876543219", address: "Kothrud, Pune", city: "Pune", status: "inactive" as const, totalSpent: "19000.00", rating: "3.80" },
  ];
  await db.insert(customers).values(customerData);

  // Seed Mechanics
  const mechanicData = [
    { name: "Suresh Yadav", email: "suresh@garage.com", phone: "9988776601", specialization: "Engine Repair", experience: 12, status: "active" as const, isVerified: true, isAvailable: true, jobsCompleted: 342, rating: "4.70", earnings: "285000.00", latitude: "18.5204303", longitude: "73.8567437", certifications: "ASE Certified, Diesel Engine Specialist" },
    { name: "Ravi Patil", email: "ravi@garage.com", phone: "9988776602", specialization: "AC & Electrical", experience: 8, status: "active" as const, isVerified: true, isAvailable: true, jobsCompleted: 218, rating: "4.50", earnings: "195000.00", latitude: "18.5314", longitude: "73.8446", certifications: "Electrical Systems Expert" },
    { name: "Ganesh Bhosale", email: "ganesh@garage.com", phone: "9988776603", specialization: "Body & Paint", experience: 15, status: "active" as const, isVerified: true, isAvailable: false, jobsCompleted: 456, rating: "4.80", earnings: "380000.00", latitude: "18.5074", longitude: "73.8077", certifications: "Master Painter, Dent Specialist" },
    { name: "Mohammad Shaikh", email: "mohammad@garage.com", phone: "9988776604", specialization: "Transmission", experience: 10, status: "active" as const, isVerified: true, isAvailable: true, jobsCompleted: 289, rating: "4.60", earnings: "245000.00", latitude: "18.5596", longitude: "73.7794", certifications: "Transmission Specialist" },
    { name: "Prakash More", email: "prakash@garage.com", phone: "9988776605", specialization: "General Service", experience: 6, status: "active" as const, isVerified: false, isAvailable: true, jobsCompleted: 156, rating: "4.20", earnings: "125000.00", latitude: "18.4970", longitude: "73.8700", certifications: "Basic Auto Mechanic" },
    { name: "Anil Kadam", email: "anil@garage.com", phone: "9988776606", specialization: "Brakes & Suspension", experience: 9, status: "suspended" as const, isVerified: true, isAvailable: false, jobsCompleted: 198, rating: "3.90", earnings: "165000.00", latitude: "18.5400", longitude: "73.8900", certifications: "Brake Systems Expert" },
    { name: "Deepak Jadhav", email: "deepak@garage.com", phone: "9988776607", specialization: "Tyre & Wheel", experience: 5, status: "active" as const, isVerified: true, isAvailable: true, jobsCompleted: 134, rating: "4.30", earnings: "98000.00", latitude: "18.5100", longitude: "73.8300", certifications: "Wheel Alignment Specialist" },
    { name: "Santosh Gaikwad", email: "santosh@garage.com", phone: "9988776608", specialization: "Diagnostics", experience: 11, status: "active" as const, isVerified: true, isAvailable: true, jobsCompleted: 312, rating: "4.90", earnings: "310000.00", latitude: "18.4800", longitude: "73.8600", certifications: "OBD Diagnostics, EFI Expert" },
  ];
  await db.insert(mechanics).values(mechanicData);

  // Seed Vehicles
  const vehicleData = [
    { customerId: 1, make: "Maruti Suzuki", model: "Swift", year: 2021, registrationNumber: "MH12AB1234", color: "Red", fuelType: "Petrol", vehicleType: "Hatchback" },
    { customerId: 1, make: "Hyundai", model: "Creta", year: 2023, registrationNumber: "MH12CD5678", color: "White", fuelType: "Diesel", vehicleType: "SUV" },
    { customerId: 2, make: "Tata", model: "Nexon", year: 2022, registrationNumber: "MH14EF9012", color: "Blue", fuelType: "Petrol", vehicleType: "SUV" },
    { customerId: 3, make: "Honda", model: "City", year: 2020, registrationNumber: "MH01GH3456", color: "Silver", fuelType: "Petrol", vehicleType: "Sedan" },
    { customerId: 4, make: "Toyota", model: "Innova", year: 2019, registrationNumber: "MH12IJ7890", color: "White", fuelType: "Diesel", vehicleType: "MPV" },
    { customerId: 5, make: "Mahindra", model: "Thar", year: 2023, registrationNumber: "MH01KL2345", color: "Black", fuelType: "Diesel", vehicleType: "SUV" },
    { customerId: 6, make: "Kia", model: "Seltos", year: 2022, registrationNumber: "MH12MN6789", color: "Grey", fuelType: "Petrol", vehicleType: "SUV" },
    { customerId: 7, make: "Maruti Suzuki", model: "Baleno", year: 2021, registrationNumber: "MH14OP0123", color: "Blue", fuelType: "Petrol", vehicleType: "Hatchback" },
    { customerId: 8, make: "Hyundai", model: "Venue", year: 2023, registrationNumber: "MH12QR4567", color: "Red", fuelType: "Petrol", vehicleType: "SUV" },
    { customerId: 9, make: "Tata", model: "Harrier", year: 2022, registrationNumber: "MH01ST8901", color: "White", fuelType: "Diesel", vehicleType: "SUV" },
    { customerId: 10, make: "Renault", model: "Kwid", year: 2020, registrationNumber: "MH12UV2345", color: "Orange", fuelType: "Petrol", vehicleType: "Hatchback" },
    { customerId: 3, make: "BMW", model: "3 Series", year: 2021, registrationNumber: "MH01WX6789", color: "Black", fuelType: "Petrol", vehicleType: "Sedan" },
  ];
  await db.insert(vehicles).values(vehicleData);

  // Seed Service Requests
  const serviceData = [
    { customerId: 1, vehicleId: 1, mechanicId: 1, serviceType: "Engine Oil Change", description: "Regular 10000km service", priority: "low" as const, status: "completed" as const, estimatedCost: "2500.00", finalCost: "2300.00", customerLatitude: "18.5204", customerLongitude: "73.8567" },
    { customerId: 2, vehicleId: 3, mechanicId: 2, serviceType: "AC Repair", description: "AC not cooling properly", priority: "medium" as const, status: "in_progress" as const, estimatedCost: "5000.00", customerLatitude: "18.5314", customerLongitude: "73.8446" },
    { customerId: 3, vehicleId: 4, mechanicId: 3, serviceType: "Dent Repair & Paint", description: "Front bumper dent from minor accident", priority: "medium" as const, status: "assigned" as const, estimatedCost: "12000.00", customerLatitude: "19.0760", customerLongitude: "72.8777" },
    { customerId: 4, vehicleId: 5, serviceType: "Full Service", description: "Annual maintenance service", priority: "low" as const, status: "unassigned" as const, estimatedCost: "8000.00", customerLatitude: "18.5350", customerLongitude: "73.8950" },
    { customerId: 5, vehicleId: 6, mechanicId: 4, serviceType: "Clutch Replacement", description: "Clutch plate worn out", priority: "high" as const, status: "in_progress" as const, estimatedCost: "15000.00", customerLatitude: "19.0176", customerLongitude: "72.8562" },
    { customerId: 6, vehicleId: 7, serviceType: "Battery Replacement", description: "Car not starting, battery issue", priority: "emergency" as const, status: "unassigned" as const, estimatedCost: "6000.00", customerLatitude: "18.5913", customerLongitude: "73.7389" },
    { customerId: 7, vehicleId: 8, mechanicId: 5, serviceType: "Brake Pad Replacement", description: "Squeaking brakes", priority: "high" as const, status: "assigned" as const, estimatedCost: "3500.00", customerLatitude: "18.5600", customerLongitude: "73.7800" },
    { customerId: 8, vehicleId: 9, mechanicId: 8, serviceType: "Diagnostics", description: "Check engine light on", priority: "medium" as const, status: "in_progress" as const, estimatedCost: "1500.00", customerLatitude: "18.5650", customerLongitude: "73.9100" },
    { customerId: 9, vehicleId: 10, mechanicId: 1, serviceType: "Suspension Repair", description: "Rough ride quality", priority: "medium" as const, status: "completed" as const, estimatedCost: "9000.00", finalCost: "8500.00", customerLatitude: "19.0180", customerLongitude: "72.8560" },
    { customerId: 1, vehicleId: 2, mechanicId: 7, serviceType: "Wheel Alignment", description: "Car pulling to one side", priority: "low" as const, status: "completed" as const, estimatedCost: "1200.00", finalCost: "1200.00", customerLatitude: "18.5204", customerLongitude: "73.8567" },
    { customerId: 10, vehicleId: 11, serviceType: "Periodic Service", description: "15000km service due", priority: "low" as const, status: "unassigned" as const, estimatedCost: "4000.00", customerLatitude: "18.5080", customerLongitude: "73.8070" },
    { customerId: 3, vehicleId: 12, mechanicId: 8, serviceType: "Engine Diagnostics", description: "Performance drop noticed", priority: "high" as const, status: "assigned" as const, estimatedCost: "3000.00", customerLatitude: "19.0760", customerLongitude: "72.8777" },
  ];
  await db.insert(serviceRequests).values(serviceData);

  // Seed Payments
  const paymentData = [
    { serviceRequestId: 1, customerId: 1, mechanicId: 1, amount: "2300.00", paymentMethod: "UPI", paymentStatus: "completed" as const, transactionId: "TXN001234" },
    { serviceRequestId: 9, customerId: 9, mechanicId: 1, amount: "8500.00", paymentMethod: "Card", paymentStatus: "completed" as const, transactionId: "TXN001235" },
    { serviceRequestId: 10, customerId: 1, mechanicId: 7, amount: "1200.00", paymentMethod: "Cash", paymentStatus: "completed" as const, transactionId: "TXN001236" },
    { serviceRequestId: 2, customerId: 2, mechanicId: 2, amount: "5000.00", paymentMethod: "UPI", paymentStatus: "pending" as const },
    { serviceRequestId: 5, customerId: 5, mechanicId: 4, amount: "15000.00", paymentMethod: "Card", paymentStatus: "pending" as const },
    { serviceRequestId: 3, customerId: 3, mechanicId: 3, amount: "12000.00", paymentMethod: "UPI", paymentStatus: "pending" as const },
  ];
  await db.insert(payments).values(paymentData);

  // Seed Reviews
  const reviewData = [
    { serviceRequestId: 1, customerId: 1, mechanicId: 1, rating: 5, comment: "Excellent service! Engine runs smooth now. Very professional." },
    { serviceRequestId: 9, customerId: 9, mechanicId: 1, rating: 4, comment: "Good work on suspension. Slightly expensive but quality work." },
    { serviceRequestId: 10, customerId: 1, mechanicId: 7, rating: 5, comment: "Quick and efficient wheel alignment. Car drives perfectly straight now." },
    { serviceRequestId: 1, customerId: 1, mechanicId: 1, rating: 3, comment: "Service was okay but took longer than expected.", isFlagged: false },
    { serviceRequestId: 9, customerId: 9, mechanicId: 1, rating: 2, comment: "Not satisfied with the work quality. Had to revisit.", isFlagged: true },
  ];
  await db.insert(reviews).values(reviewData);

  // Seed Negotiations
  const negotiationData = [
    { serviceRequestId: 2, customerId: 2, mechanicId: 2, customerOffer: "4000.00", mechanicOffer: "5500.00", finalPrice: "5000.00", status: "accepted", adminApproved: true },
    { serviceRequestId: 3, customerId: 3, mechanicId: 3, customerOffer: "10000.00", mechanicOffer: "14000.00", status: "pending", adminApproved: false },
    { serviceRequestId: 5, customerId: 5, mechanicId: 4, customerOffer: "12000.00", mechanicOffer: "16000.00", finalPrice: "15000.00", status: "accepted", adminApproved: true },
    { serviceRequestId: 8, customerId: 8, mechanicId: 8, customerOffer: "1000.00", mechanicOffer: "1500.00", status: "pending", adminApproved: false },
  ];
  await db.insert(negotiations).values(negotiationData);

  // Seed Notifications
  const notificationData = [
    { title: "New Customer Registration", message: "Kavita Reddy has registered as a new customer.", type: "registration", isRead: false },
    { title: "Emergency Breakdown", message: "Neha Joshi reports battery failure at Hinjewadi. Needs immediate assistance.", type: "emergency", isRead: false },
    { title: "Payment Received", message: "Payment of ₹8,500 received from Manoj Tiwari for suspension repair.", type: "payment", isRead: true },
    { title: "New Service Request", message: "Rajesh Kumar has requested wheel alignment for Hyundai Creta.", type: "service", isRead: false },
    { title: "Mechanic Unavailable", message: "Ganesh Bhosale marked himself as unavailable for today.", type: "availability", isRead: false },
    { title: "Complaint Filed", message: "Vikram Singh has filed a complaint regarding overcharging.", type: "complaint", isRead: false },
    { title: "New Review", message: "Manoj Tiwari has left a 4-star review for Suresh Yadav.", type: "review", isRead: true },
    { title: "Negotiation Pending", message: "Price negotiation pending approval for dent repair service.", type: "negotiation", isRead: false },
  ];
  await db.insert(notifications).values(notificationData);

  console.log("Database seeded successfully!");
}
