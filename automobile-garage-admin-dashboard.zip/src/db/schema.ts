import {
  pgTable,
  serial,
  varchar,
  text,
  integer,
  boolean,
  timestamp,
  decimal,
  pgEnum,
} from "drizzle-orm/pg-core";

export const statusEnum = pgEnum("status_enum", [
  "active",
  "inactive",
  "blocked",
  "suspended",
]);

export const priorityEnum = pgEnum("priority_enum", [
  "low",
  "medium",
  "high",
  "emergency",
]);

export const serviceStatusEnum = pgEnum("service_status_enum", [
  "unassigned",
  "assigned",
  "in_progress",
  "completed",
  "cancelled",
]);

export const paymentStatusEnum = pgEnum("payment_status_enum", [
  "pending",
  "completed",
  "refunded",
  "failed",
]);

export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 20 }).notNull(),
  address: text("address"),
  city: varchar("city", { length: 100 }),
  profilePicture: text("profile_picture"),
  status: statusEnum("status").default("active").notNull(),
  totalSpent: decimal("total_spent", { precision: 12, scale: 2 }).default("0"),
  rating: decimal("rating", { precision: 3, scale: 2 }).default("0"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const mechanics = pgTable("mechanics", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 20 }).notNull(),
  specialization: varchar("specialization", { length: 255 }),
  experience: integer("experience").default(0),
  profilePicture: text("profile_picture"),
  status: statusEnum("status").default("active").notNull(),
  isVerified: boolean("is_verified").default(false),
  isAvailable: boolean("is_available").default(true),
  jobsCompleted: integer("jobs_completed").default(0),
  rating: decimal("rating", { precision: 3, scale: 2 }).default("0"),
  earnings: decimal("earnings", { precision: 12, scale: 2 }).default("0"),
  latitude: decimal("latitude", { precision: 10, scale: 7 }),
  longitude: decimal("longitude", { precision: 10, scale: 7 }),
  certifications: text("certifications"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const vehicles = pgTable("vehicles", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").references(() => customers.id),
  make: varchar("make", { length: 100 }).notNull(),
  model: varchar("model", { length: 100 }).notNull(),
  year: integer("year"),
  registrationNumber: varchar("registration_number", { length: 20 }).notNull(),
  color: varchar("color", { length: 50 }),
  fuelType: varchar("fuel_type", { length: 50 }),
  vehicleType: varchar("vehicle_type", { length: 50 }),
  lastServiceDate: timestamp("last_service_date"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const serviceRequests = pgTable("service_requests", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").references(() => customers.id),
  vehicleId: integer("vehicle_id").references(() => vehicles.id),
  mechanicId: integer("mechanic_id").references(() => mechanics.id),
  serviceType: varchar("service_type", { length: 255 }).notNull(),
  description: text("description"),
  priority: priorityEnum("priority").default("medium").notNull(),
  status: serviceStatusEnum("status").default("unassigned").notNull(),
  estimatedCost: decimal("estimated_cost", { precision: 10, scale: 2 }),
  finalCost: decimal("final_cost", { precision: 10, scale: 2 }),
  scheduledDate: timestamp("scheduled_date"),
  completedDate: timestamp("completed_date"),
  customerLatitude: decimal("customer_latitude", { precision: 10, scale: 7 }),
  customerLongitude: decimal("customer_longitude", { precision: 10, scale: 7 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  serviceRequestId: integer("service_request_id").references(() => serviceRequests.id),
  customerId: integer("customer_id").references(() => customers.id),
  mechanicId: integer("mechanic_id").references(() => mechanics.id),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  paymentMethod: varchar("payment_method", { length: 50 }),
  paymentStatus: paymentStatusEnum("payment_status").default("pending").notNull(),
  transactionId: varchar("transaction_id", { length: 100 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  serviceRequestId: integer("service_request_id").references(() => serviceRequests.id),
  customerId: integer("customer_id").references(() => customers.id),
  mechanicId: integer("mechanic_id").references(() => mechanics.id),
  rating: integer("rating").notNull(),
  comment: text("comment"),
  isFlagged: boolean("is_flagged").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const negotiations = pgTable("negotiations", {
  id: serial("id").primaryKey(),
  serviceRequestId: integer("service_request_id").references(() => serviceRequests.id),
  customerId: integer("customer_id").references(() => customers.id),
  mechanicId: integer("mechanic_id").references(() => mechanics.id),
  customerOffer: decimal("customer_offer", { precision: 10, scale: 2 }),
  mechanicOffer: decimal("mechanic_offer", { precision: 10, scale: 2 }),
  finalPrice: decimal("final_price", { precision: 10, scale: 2 }),
  status: varchar("status", { length: 50 }).default("pending"),
  adminApproved: boolean("admin_approved").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  type: varchar("type", { length: 50 }).notNull(),
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  action: varchar("action", { length: 255 }).notNull(),
  entity: varchar("entity", { length: 100 }).notNull(),
  entityId: integer("entity_id"),
  details: text("details"),
  performedBy: varchar("performed_by", { length: 100 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
