"use client";

import { useState } from "react";
import Link from "next/link";

export default function TopNav({ unreadCount }: { unreadCount: number }) {
  const [showProfile, setShowProfile] = useState(false);
  const [search, setSearch] = useState("");

  return (
    <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6 sticky top-0 z-40">
      {/* Search */}
      <div className="flex items-center gap-3 flex-1 max-w-xl">
        <div className="relative w-full">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm">
            🔍
          </span>
          <input
            type="text"
            placeholder="Search customers, mechanics, vehicles, services..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
          />
        </div>
      </div>

      {/* Right side */}
      <div className="flex items-center gap-4">
        {/* Notification Bell */}
        <Link
          href="/notifications"
          className="relative p-2 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <span className="text-xl">🔔</span>
          {unreadCount > 0 && (
            <span className="absolute -top-0 -right-0 w-5 h-5 bg-danger text-white text-[10px] font-bold rounded-full flex items-center justify-center">
              {unreadCount > 9 ? "9+" : unreadCount}
            </span>
          )}
        </Link>

        {/* Profile */}
        <div className="relative">
          <button
            onClick={() => setShowProfile(!showProfile)}
            className="flex items-center gap-2 p-1.5 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white text-sm font-bold">
              A
            </div>
            <div className="text-left hidden sm:block">
              <p className="text-sm font-medium text-gray-700">Admin</p>
              <p className="text-[11px] text-gray-400">Super Admin</p>
            </div>
            <span className="text-gray-400 text-xs">▼</span>
          </button>

          {showProfile && (
            <div className="absolute right-0 top-12 w-48 bg-white border border-gray-200 rounded-lg shadow-lg py-2 z-50">
              <Link
                href="/settings"
                className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50"
              >
                ⚙️ Settings
              </Link>
              <Link
                href="/settings"
                className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50"
              >
                👤 Profile
              </Link>
              <hr className="my-1 border-gray-100" />
              <button className="block w-full text-left px-4 py-2 text-sm text-danger hover:bg-gray-50">
                🚪 Logout
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
