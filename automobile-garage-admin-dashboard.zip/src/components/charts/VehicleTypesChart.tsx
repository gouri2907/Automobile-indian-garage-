"use client";

import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  Legend,
} from "recharts";

const data = [
  { name: "SUV", value: 35 },
  { name: "Hatchback", value: 28 },
  { name: "Sedan", value: 22 },
  { name: "MPV", value: 10 },
  { name: "Others", value: 5 },
];

const COLORS = ["#1e40af", "#f97316", "#16a34a", "#8b5cf6", "#64748b"];

export default function VehicleTypesChart() {
  return (
    <div className="card">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">
        Most Serviced Vehicle Types
      </h3>
      <ResponsiveContainer width="100%" height={300}>
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={100}
            fill="#8884d8"
            paddingAngle={5}
            dataKey="value"
            label={({ name, percent }) =>
              `${name} ${((percent ?? 0) * 100).toFixed(0)}%`
            }
          >
            {data.map((_, index) => (
              <Cell
                key={`cell-${index}`}
                fill={COLORS[index % COLORS.length]}
              />
            ))}
          </Pie>
          <Tooltip contentStyle={{ borderRadius: 8, border: "1px solid #e2e8f0" }} />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}
