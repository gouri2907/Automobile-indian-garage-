"use client";

import {
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  ResponsiveContainer,
  Tooltip,
} from "recharts";

const data = [
  { subject: "Speed", A: 90, fullMark: 100 },
  { subject: "Quality", A: 85, fullMark: 100 },
  { subject: "Reliability", A: 92, fullMark: 100 },
  { subject: "Customer Rating", A: 88, fullMark: 100 },
  { subject: "Availability", A: 75, fullMark: 100 },
  { subject: "Skills", A: 82, fullMark: 100 },
];

export default function MechanicPerformanceChart() {
  return (
    <div className="card">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">
        Mechanic Performance
      </h3>
      <ResponsiveContainer width="100%" height={300}>
        <RadarChart data={data}>
          <PolarGrid stroke="#e2e8f0" />
          <PolarAngleAxis dataKey="subject" tick={{ fontSize: 11 }} />
          <PolarRadiusAxis
            angle={30}
            domain={[0, 100]}
            tick={{ fontSize: 10 }}
          />
          <Tooltip contentStyle={{ borderRadius: 8, border: "1px solid #e2e8f0" }} />
          <Radar
            name="Performance"
            dataKey="A"
            stroke="#1e40af"
            fill="#1e40af"
            fillOpacity={0.3}
          />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}
