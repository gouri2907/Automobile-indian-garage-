"use client";

import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

const data = [
  { month: "Jan", revenue: 125000 },
  { month: "Feb", revenue: 148000 },
  { month: "Mar", revenue: 162000 },
  { month: "Apr", revenue: 139000 },
  { month: "May", revenue: 185000 },
  { month: "Jun", revenue: 198000 },
  { month: "Jul", revenue: 215000 },
  { month: "Aug", revenue: 232000 },
  { month: "Sep", revenue: 208000 },
  { month: "Oct", revenue: 245000 },
  { month: "Nov", revenue: 268000 },
  { month: "Dec", revenue: 295000 },
];

export default function RevenueChart() {
  return (
    <div className="card">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">
        Revenue Overview
      </h3>
      <ResponsiveContainer width="100%" height={300}>
        <AreaChart data={data}>
          <defs>
            <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#1e40af" stopOpacity={0.3} />
              <stop offset="95%" stopColor="#1e40af" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
          <XAxis dataKey="month" tick={{ fontSize: 12 }} stroke="#94a3b8" />
          <YAxis
            tick={{ fontSize: 12 }}
            stroke="#94a3b8"
            tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}K`}
          />
          <Tooltip
            formatter={(value) => [`₹${Number(value).toLocaleString("en-IN")}`, "Revenue"]}
            contentStyle={{ borderRadius: 8, border: "1px solid #e2e8f0" }}
          />
          <Area
            type="monotone"
            dataKey="revenue"
            stroke="#1e40af"
            fill="url(#colorRevenue)"
            strokeWidth={2}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
