"use client";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";

const data = [
  { month: "Jan", completed: 45, pending: 12, cancelled: 3 },
  { month: "Feb", completed: 52, pending: 8, cancelled: 2 },
  { month: "Mar", completed: 61, pending: 15, cancelled: 5 },
  { month: "Apr", completed: 48, pending: 10, cancelled: 4 },
  { month: "May", completed: 58, pending: 7, cancelled: 2 },
  { month: "Jun", completed: 67, pending: 11, cancelled: 3 },
  { month: "Jul", completed: 72, pending: 9, cancelled: 1 },
  { month: "Aug", completed: 78, pending: 14, cancelled: 4 },
  { month: "Sep", completed: 65, pending: 6, cancelled: 2 },
  { month: "Oct", completed: 82, pending: 13, cancelled: 3 },
  { month: "Nov", completed: 88, pending: 10, cancelled: 2 },
  { month: "Dec", completed: 95, pending: 8, cancelled: 1 },
];

export default function ServiceTrendsChart() {
  return (
    <div className="card">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">
        Service Request Trends
      </h3>
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
          <XAxis dataKey="month" tick={{ fontSize: 12 }} stroke="#94a3b8" />
          <YAxis tick={{ fontSize: 12 }} stroke="#94a3b8" />
          <Tooltip
            contentStyle={{ borderRadius: 8, border: "1px solid #e2e8f0" }}
          />
          <Legend />
          <Bar dataKey="completed" fill="#16a34a" radius={[4, 4, 0, 0]} name="Completed" />
          <Bar dataKey="pending" fill="#f97316" radius={[4, 4, 0, 0]} name="Pending" />
          <Bar dataKey="cancelled" fill="#dc2626" radius={[4, 4, 0, 0]} name="Cancelled" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
