"use client";

import { ReactNode } from "react";
import Sidebar from "./Sidebar";
import TopNav from "./TopNav";

export default function DashboardLayout({
  children,
  unreadCount = 0,
}: {
  children: ReactNode;
  unreadCount?: number;
}) {
  return (
    <div className="min-h-screen bg-gray-bg">
      <Sidebar />
      <div className="ml-[260px] transition-all duration-300">
        <TopNav unreadCount={unreadCount} />
        <main className="p-6">{children}</main>
      </div>
    </div>
  );
}
