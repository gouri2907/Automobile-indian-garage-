"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";

const menuItems = [
  { name: "Dashboard", path: "/", icon: "📊" },
  { name: "Customer Management", path: "/customers", icon: "👥" },
  { name: "Mechanic Management", path: "/mechanics", icon: "🔧" },
  { name: "Vehicle Management", path: "/vehicles", icon: "🚗" },
  { name: "Work Assignment", path: "/assignments", icon: "📋" },
  { name: "Service Requests", path: "/services", icon: "🛠️" },
  { name: "Live Tracking", path: "/tracking", icon: "📍" },
  { name: "Negotiations", path: "/negotiations", icon: "🤝" },
  { name: "Payments", path: "/payments", icon: "💳" },
  { name: "Reviews & Ratings", path: "/reviews", icon: "⭐" },
  { name: "Reports & Analytics", path: "/reports", icon: "📈" },
  { name: "Notifications", path: "/notifications", icon: "🔔" },
  { name: "Settings", path: "/settings", icon: "⚙️" },
];

export default function Sidebar() {
  const pathname = usePathname();
  const [collapsed, setCollapsed] = useState(false);

  return (
    <aside
      className={`fixed top-0 left-0 h-screen bg-sidebar text-gray-300 z-50 transition-all duration-300 flex flex-col ${
        collapsed ? "w-[68px]" : "w-[260px]"
      }`}
    >
      {/* Logo */}
      <div className="flex items-center justify-between px-4 py-4 border-b border-gray-700">
        {!collapsed && (
          <div className="flex items-center gap-2">
            <span className="text-2xl">🏭</span>
            <div>
              <h1 className="text-sm font-bold text-white leading-tight">
                Automobile Indian
              </h1>
              <p className="text-[10px] text-gray-400">Garage Management</p>
            </div>
          </div>
        )}
        {collapsed && <span className="text-2xl mx-auto">🏭</span>}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="text-gray-400 hover:text-white p-1 rounded transition-colors"
        >
          {collapsed ? "▶" : "◀"}
        </button>
      </div>

      {/* Menu */}
      <nav className="flex-1 overflow-y-auto py-4 px-2 space-y-1">
        {menuItems.map((item) => {
          const isActive =
            item.path === "/"
              ? pathname === "/"
              : pathname.startsWith(item.path);
          return (
            <Link
              key={item.path}
              href={item.path}
              className={`sidebar-item ${isActive ? "active" : "text-gray-400"}`}
              title={collapsed ? item.name : undefined}
            >
              <span className="text-lg flex-shrink-0">{item.icon}</span>
              {!collapsed && <span>{item.name}</span>}
            </Link>
          );
        })}
      </nav>

      {/* Admin Info */}
      {!collapsed && (
        <div className="p-4 border-t border-gray-700">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-primary flex items-center justify-center text-white text-sm font-bold">
              A
            </div>
            <div>
              <p className="text-sm font-medium text-white">Admin</p>
              <p className="text-[11px] text-gray-400">Super Administrator</p>
            </div>
          </div>
        </div>
      )}
    </aside>
  );
}
