"use client";
import { create } from "zustand";

type Language = "en" | "hi" | "mr";

interface AppState {
  darkMode: boolean;
  language: Language;
  activeNav: string;
  sidebarOpen: boolean;
  toggleDarkMode: () => void;
  setLanguage: (lang: Language) => void;
  setActiveNav: (nav: string) => void;
  setSidebarOpen: (open: boolean) => void;
}

export const useStore = create<AppState>((set) => ({
  darkMode: false,
  language: "en",
  activeNav: "home",
  sidebarOpen: false,
  toggleDarkMode: () =>
    set((state) => {
      const next = !state.darkMode;
      if (typeof document !== "undefined") {
        document.documentElement.classList.toggle("dark", next);
      }
      return { darkMode: next };
    }),
  setLanguage: (lang) => set({ language: lang }),
  setActiveNav: (nav) => set({ activeNav: nav }),
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
}));

export const translations: Record<Language, Record<string, string>> = {
  en: {
    home: "Home",
    myVehicles: "My Vehicles",
    bookService: "Book Service",
    mechanics: "Mechanics",
    aiAssistant: "AI Assistant",
    gpsTracking: "GPS Tracking",
    reviews: "Reviews",
    serviceHistory: "Service History",
    notifications: "Notifications",
    profile: "Profile",
    dashboard: "Dashboard",
    welcome: "Welcome back",
    activeServices: "Active Services",
    nearbyMechanics: "Nearby Mechanics",
    vehicleHealth: "Vehicle Health",
    upcomingReminders: "Upcoming Reminders",
    recentActivity: "Recent Activity",
    emergency: "Emergency Assistance",
    addVehicle: "Add Vehicle",
    bookNow: "Book Now",
    search: "Search services, mechanics...",
    viewAll: "View All",
    settings: "Settings",
    darkMode: "Dark Mode",
    language: "Language",
    logout: "Logout",
    writeReview: "Write a Review",
    overallRating: "Overall Rating",
    serviceQuality: "Service Quality",
    responseTime: "Response Time",
    askAI: "Ask your automotive assistant...",
  },
  hi: {
    home: "होम",
    myVehicles: "मेरे वाहन",
    bookService: "सेवा बुक करें",
    mechanics: "मैकेनिक",
    aiAssistant: "AI सहायक",
    gpsTracking: "GPS ट्रैकिंग",
    reviews: "समीक्षा",
    serviceHistory: "सेवा इतिहास",
    notifications: "सूचनाएं",
    profile: "प्रोफाइल",
    dashboard: "डैशबोर्ड",
    welcome: "वापस स्वागत है",
    activeServices: "सक्रिय सेवाएं",
    nearbyMechanics: "नजदीकी मैकेनिक",
    vehicleHealth: "वाहन स्वास्थ्य",
    upcomingReminders: "आगामी रिमाइंडर",
    recentActivity: "हालिया गतिविधि",
    emergency: "आपातकालीन सहायता",
    addVehicle: "वाहन जोड़ें",
    bookNow: "अभी बुक करें",
    search: "सेवाएं, मैकेनिक खोजें...",
    viewAll: "सभी देखें",
    settings: "सेटिंग्स",
    darkMode: "डार्क मोड",
    language: "भाषा",
    logout: "लॉगआउट",
    writeReview: "समीक्षा लिखें",
    overallRating: "समग्र रेटिंग",
    serviceQuality: "सेवा गुणवत्ता",
    responseTime: "प्रतिक्रिया समय",
    askAI: "अपने ऑटोमोटिव सहायक से पूछें...",
  },
  mr: {
    home: "होम",
    myVehicles: "माझी वाहने",
    bookService: "सेवा बुक करा",
    mechanics: "मेकॅनिक",
    aiAssistant: "AI सहाय्यक",
    gpsTracking: "GPS ट्रॅकिंग",
    reviews: "पुनरावलोकने",
    serviceHistory: "सेवा इतिहास",
    notifications: "सूचना",
    profile: "प्रोफाइल",
    dashboard: "डॅशबोर्ड",
    welcome: "पुन्हा स्वागत आहे",
    activeServices: "सक्रिय सेवा",
    nearbyMechanics: "जवळचे मेकॅनिक",
    vehicleHealth: "वाहन आरोग्य",
    upcomingReminders: "आगामी स्मरणपत्रे",
    recentActivity: "अलीकडील क्रियाकलाप",
    emergency: "आपत्कालीन मदत",
    addVehicle: "वाहन जोडा",
    bookNow: "आत्ता बुक करा",
    search: "सेवा, मेकॅनिक शोधा...",
    viewAll: "सर्व पहा",
    settings: "सेटिंग्ज",
    darkMode: "डार्क मोड",
    language: "भाषा",
    logout: "लॉगआउट",
    writeReview: "पुनरावलोकन लिहा",
    overallRating: "एकूण रेटिंग",
    serviceQuality: "सेवा गुणवत्ता",
    responseTime: "प्रतिसाद वेळ",
    askAI: "तुमच्या ऑटोमोटिव्ह सहाय्यकाला विचारा...",
  },
};
