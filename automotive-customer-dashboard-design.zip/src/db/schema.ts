import { pgTable, serial, text, varchar, integer, boolean, timestamp, decimal, date, jsonb } from "drizzle-orm/pg-core";

export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 20 }).notNull(),
  avatarUrl: text("avatar_url"),
  address: text("address"),
  city: varchar("city", { length: 100 }),
  preferredLanguage: varchar("preferred_language", { length: 10 }).default("en"),
  darkMode: boolean("dark_mode").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const vehicles = pgTable("vehicles", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").notNull(),
  registrationNumber: varchar("registration_number", { length: 20 }).notNull(),
  vehicleType: varchar("vehicle_type", { length: 50 }).notNull(),
  brand: varchar("brand", { length: 100 }).notNull(),
  model: varchar("model", { length: 100 }).notNull(),
  fuelType: varchar("fuel_type", { length: 20 }).notNull(),
  manufacturingYear: integer("manufacturing_year").notNull(),
  color: varchar("color", { length: 50 }),
  imageUrl: text("image_url"),
  insuranceProvider: varchar("insurance_provider", { length: 100 }),
  insuranceExpiry: date("insurance_expiry"),
  serviceDueDate: date("service_due_date"),
  healthScore: integer("health_score").default(85),
  odometerReading: integer("odometer_reading"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const mechanics = pgTable("mechanics", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 20 }).notNull(),
  avatarUrl: text("avatar_url"),
  specialization: varchar("specialization", { length: 255 }).notNull(),
  experience: integer("experience").notNull(),
  rating: decimal("rating", { precision: 2, scale: 1 }).default("4.0"),
  totalReviews: integer("total_reviews").default(0),
  isOnline: boolean("is_online").default(false),
  latitude: decimal("latitude", { precision: 10, scale: 7 }),
  longitude: decimal("longitude", { precision: 10, scale: 7 }),
  distanceKm: decimal("distance_km", { precision: 5, scale: 1 }),
  estimatedArrival: varchar("estimated_arrival", { length: 50 }),
  serviceChargePerHour: integer("service_charge_per_hour").default(500),
  createdAt: timestamp("created_at").defaultNow(),
});

export const serviceRequests = pgTable("service_requests", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").notNull(),
  vehicleId: integer("vehicle_id").notNull(),
  mechanicId: integer("mechanic_id"),
  serviceType: varchar("service_type", { length: 100 }).notNull(),
  description: text("description"),
  status: varchar("status", { length: 30 }).notNull().default("pending"),
  scheduledDate: timestamp("scheduled_date"),
  completedDate: timestamp("completed_date"),
  estimatedCost: integer("estimated_cost"),
  actualCost: integer("actual_cost"),
  partsReplaced: jsonb("parts_replaced"),
  mechanicLatitude: decimal("mechanic_latitude", { precision: 10, scale: 7 }),
  mechanicLongitude: decimal("mechanic_longitude", { precision: 10, scale: 7 }),
  createdAt: timestamp("created_at").defaultNow(),
});

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").notNull(),
  mechanicId: integer("mechanic_id").notNull(),
  serviceRequestId: integer("service_request_id"),
  rating: integer("rating").notNull(),
  serviceQuality: integer("service_quality"),
  responseTime: integer("response_time"),
  comment: text("comment"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  type: varchar("type", { length: 30 }).notNull(),
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const aiChatMessages = pgTable("ai_chat_messages", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").notNull(),
  role: varchar("role", { length: 20 }).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});
