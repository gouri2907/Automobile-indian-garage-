"use client";

import { useStore, translations } from "@/store/useStore";
import { Search, Bell, Moon, Sun, Menu, Globe } from "lucide-react";
import { useState } from "react";

export default function Header() {
  const { darkMode, toggleDarkMode, language, setLanguage, setSidebarOpen } = useStore();
  const t = translations[language];
  const [showLangMenu, setShowLangMenu] = useState(false);

  const langs = [
    { code: "en" as const, label: "English", short: "EN" },
    { code: "hi" as const, label: "हिन्दी", short: "HI" },
    { code: "mr" as const, label: "मराठी", short: "MR" },
  ];

  return (
    <header
      className="sticky top-0 z-30 border-b px-4 lg:px-6 py-3 flex items-center gap-3 lg:gap-4"
      style={{ backgroundColor: "var(--header-bg)", borderColor: "var(--bg-main)" }}
    >
      {/* Mobile menu button */}
      <button
        onClick={() => setSidebarOpen(true)}
        className="lg:hidden p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 transition"
      >
        <Menu className="w-5 h-5" />
      </button>

      {/* Mobile logo */}
      <div className="lg:hidden flex items-center gap-2 mr-auto">
        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-orange-500 flex items-center justify-center">
          <span className="text-white text-[8px] font-bold">AIG</span>
        </div>
        <span className="font-bold text-sm">Automobile Indian Garage</span>
      </div>

      {/* Search bar - hidden on small mobile */}
      <div className="hidden sm:flex flex-1 max-w-xl items-center gap-2 bg-slate-100 dark:bg-slate-700 rounded-xl px-4 py-2.5">
        <Search className="w-4 h-4 text-slate-400 flex-shrink-0" />
        <input
          type="text"
          placeholder={t.search}
          className="flex-1 bg-transparent text-sm outline-none placeholder:text-slate-400"
        />
      </div>

      <div className="flex items-center gap-1 sm:gap-2 ml-auto lg:ml-0">
        {/* Language Switcher */}
        <div className="relative">
          <button
            onClick={() => setShowLangMenu(!showLangMenu)}
            className="flex items-center gap-1.5 px-2.5 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 transition text-sm"
          >
            <Globe className="w-4 h-4" />
            <span className="hidden sm:inline text-xs font-medium">
              {langs.find((l) => l.code === language)?.short}
            </span>
          </button>
          {showLangMenu && (
            <div
              className="absolute right-0 top-full mt-1 rounded-xl shadow-xl border py-1 w-36 z-50"
              style={{ backgroundColor: "var(--bg-card)", borderColor: "var(--bg-main)" }}
            >
              {langs.map((l) => (
                <button
                  key={l.code}
                  onClick={() => {
                    setLanguage(l.code);
                    setShowLangMenu(false);
                  }}
                  className={`w-full text-left px-4 py-2 text-sm hover:bg-slate-100 dark:hover:bg-slate-700 transition
                    ${language === l.code ? "text-blue-600 font-semibold" : ""}
                  `}
                >
                  {l.label}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Dark Mode */}
        <button
          onClick={toggleDarkMode}
          className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 transition"
        >
          {darkMode ? <Sun className="w-4 h-4 text-yellow-400" /> : <Moon className="w-4 h-4" />}
        </button>

        {/* Notifications */}
        <button className="relative p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 transition">
          <Bell className="w-4 h-4" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
        </button>

        {/* Profile */}
        <div className="flex items-center gap-2 ml-1 sm:ml-2 pl-2 sm:pl-3 border-l" style={{ borderColor: "var(--bg-main)" }}>
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center text-white text-xs font-bold">
            RK
          </div>
          <div className="hidden md:block">
            <p className="text-sm font-semibold leading-tight">Rajesh Kumar</p>
            <p className="text-[11px] text-slate-400">Mumbai, MH</p>
          </div>
        </div>
      </div>
    </header>
  );
}
