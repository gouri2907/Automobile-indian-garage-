"use client";

import { useStore, translations } from "@/store/useStore";
import { Home, Car, Calendar, Wrench, Bot } from "lucide-react";

const navItems = [
  { id: "home", icon: Home, label: "home" },
  { id: "vehicles", icon: Car, label: "myVehicles" },
  { id: "booking", icon: Calendar, label: "bookService" },
  { id: "mechanics", icon: Wrench, label: "mechanics" },
  { id: "ai", icon: Bot, label: "aiAssistant" },
];

export default function BottomNav() {
  const { activeNav, setActiveNav, language } = useStore();
  const t = translations[language];

  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-30 lg:hidden border-t flex items-center justify-around px-1 py-1.5 safe-area-inset-bottom"
      style={{ backgroundColor: "var(--header-bg)", borderColor: "var(--bg-main)" }}
    >
      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive = activeNav === item.id;
        return (
          <button
            key={item.id}
            onClick={() => setActiveNav(item.id)}
            className={`flex flex-col items-center gap-0.5 py-1.5 px-3 rounded-xl transition-all
              ${isActive
                ? "text-blue-600"
                : "text-slate-400 hover:text-slate-600"
              }
            `}
          >
            <div className={`p-1 rounded-lg transition-all ${isActive ? "bg-blue-50 dark:bg-blue-900/30" : ""}`}>
              <Icon className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-medium leading-tight">{t[item.label]}</span>
          </button>
        );
      })}
    </nav>
  );
}
