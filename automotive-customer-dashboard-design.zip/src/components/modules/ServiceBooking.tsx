"use client";

import { useStore, translations } from "@/store/useStore";
import { useState } from "react";
import {
  Calendar, Car, Wrench, Clock, IndianRupee, CheckCircle2, ChevronDown,
  ChevronRight, AlertCircle
} from "lucide-react";

interface Vehicle {
  id: number;
  brand: string;
  model: string;
  registrationNumber: string;
}

interface Mechanic {
  id: number;
  name: string;
  specialization: string;
  rating: string | null;
  isOnline: boolean | null;
  serviceChargePerHour: number | null;
}

interface Props {
  vehicles: Vehicle[];
  mechanics: Mechanic[];
  onRefresh: () => void;
}

const serviceTypes = [
  { name: "General Service", price: 3500, duration: "2-3 hrs", icon: "🔧" },
  { name: "Engine Repair", price: 5000, duration: "3-5 hrs", icon: "⚙️" },
  { name: "AC Repair", price: 2500, duration: "1-2 hrs", icon: "❄️" },
  { name: "Brake Service", price: 2800, duration: "1-2 hrs", icon: "🛑" },
  { name: "Battery Replacement", price: 4000, duration: "30 min", icon: "🔋" },
  { name: "Tyre Service", price: 1500, duration: "1 hr", icon: "🔄" },
  { name: "Denting & Painting", price: 6000, duration: "1-2 days", icon: "🎨" },
  { name: "Electrical Repair", price: 3000, duration: "2-3 hrs", icon: "⚡" },
  { name: "Oil Change", price: 1800, duration: "30 min", icon: "🛢️" },
  { name: "Full Body Wash", price: 800, duration: "1 hr", icon: "🚿" },
];

export default function ServiceBooking({ vehicles, mechanics, onRefresh }: Props) {
  const { language, setActiveNav } = useStore();
  const t = translations[language];
  const [step, setStep] = useState(1);
  const [booking, setBooking] = useState({
    vehicleId: 0,
    serviceType: "",
    mechanicId: 0,
    scheduledDate: "",
    scheduledTime: "",
    description: "",
    estimatedCost: 0,
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const selectedService = serviceTypes.find((s) => s.name === booking.serviceType);
  const selectedMechanic = mechanics.find((m) => m.id === booking.mechanicId);
  const selectedVehicle = vehicles.find((v) => v.id === booking.vehicleId);

  const totalCost = (selectedService?.price || 0) + (selectedMechanic?.serviceChargePerHour ? selectedMechanic.serviceChargePerHour * 2 : 0);

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      await fetch("/api/services", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          vehicleId: booking.vehicleId,
          serviceType: booking.serviceType,
          mechanicId: booking.mechanicId || null,
          scheduledDate: booking.scheduledDate
            ? new Date(`${booking.scheduledDate}T${booking.scheduledTime || "10:00"}`).toISOString()
            : null,
          description: booking.description,
          estimatedCost: totalCost,
        }),
      });
      setIsSuccess(true);
      onRefresh();
    } catch (err) {
      console.error(err);
    }
    setIsSubmitting(false);
  };

  if (isSuccess) {
    return (
      <div className="animate-slide-up flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <div className="w-20 h-20 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle2 className="w-10 h-10 text-green-500" />
          </div>
          <h2 className="text-2xl font-bold mb-2">Booking Confirmed! 🎉</h2>
          <p className="text-slate-400 text-sm mb-6 max-w-sm mx-auto">
            Your {booking.serviceType} for {selectedVehicle?.brand} {selectedVehicle?.model} has been scheduled successfully.
          </p>
          <div className="flex gap-3 justify-center">
            <button
              onClick={() => setActiveNav("gps")}
              className="bg-blue-600 text-white px-5 py-2.5 rounded-xl text-sm font-semibold hover:bg-blue-700 transition"
            >
              Track Service
            </button>
            <button
              onClick={() => setActiveNav("home")}
              className="border px-5 py-2.5 rounded-xl text-sm font-medium hover:bg-slate-50 dark:hover:bg-slate-700 transition"
              style={{ borderColor: "var(--bg-main)" }}
            >
              Go Home
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5 animate-slide-up">
      {/* Header */}
      <div>
        <h2 className="text-xl sm:text-2xl font-bold flex items-center gap-2">
          <Calendar className="w-6 h-6 text-blue-500" />
          {t.bookService}
        </h2>
        <p className="text-sm text-slate-400 mt-0.5">Schedule your vehicle service in 4 easy steps</p>
      </div>

      {/* Progress Steps */}
      <div className="flex items-center justify-between max-w-lg">
        {[
          { num: 1, label: "Vehicle" },
          { num: 2, label: "Service" },
          { num: 3, label: "Mechanic" },
          { num: 4, label: "Confirm" },
        ].map((s, i) => (
          <div key={s.num} className="flex items-center">
            <div className="flex flex-col items-center">
              <div
                className={`w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold transition ${
                  step >= s.num
                    ? "bg-blue-600 text-white"
                    : "bg-slate-100 dark:bg-slate-700 text-slate-400"
                }`}
              >
                {step > s.num ? <CheckCircle2 className="w-5 h-5" /> : s.num}
              </div>
              <span className="text-[10px] font-medium mt-1 text-slate-400">{s.label}</span>
            </div>
            {i < 3 && (
              <div className={`w-10 sm:w-16 h-0.5 mx-1 sm:mx-2 mb-4 transition ${
                step > s.num ? "bg-blue-600" : "bg-slate-200 dark:bg-slate-700"
              }`} />
            )}
          </div>
        ))}
      </div>

      {/* Step Content */}
      <div
        className="rounded-2xl border p-5 sm:p-6"
        style={{ backgroundColor: "var(--bg-card)", borderColor: "var(--bg-main)" }}
      >
        {/* Step 1: Select Vehicle */}
        {step === 1 && (
          <div>
            <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
              <Car className="w-5 h-5 text-blue-500" />
              Select Vehicle
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {vehicles.map((v) => (
                <button
                  key={v.id}
                  onClick={() => setBooking({ ...booking, vehicleId: v.id })}
                  className={`p-4 rounded-xl border text-left transition-all ${
                    booking.vehicleId === v.id
                      ? "border-blue-500 bg-blue-50 dark:bg-blue-900/20 ring-2 ring-blue-200 dark:ring-blue-800"
                      : "hover:border-slate-300 dark:hover:border-slate-600"
                  }`}
                  style={booking.vehicleId !== v.id ? { borderColor: "var(--bg-main)" } : {}}
                >
                  <p className="font-semibold text-sm">{v.brand} {v.model}</p>
                  <p className="text-xs text-slate-400 font-mono mt-0.5">{v.registrationNumber}</p>
                </button>
              ))}
            </div>
            {vehicles.length === 0 && (
              <div className="text-center py-8 text-slate-400">
                <AlertCircle className="w-10 h-10 mx-auto mb-2 opacity-50" />
                <p className="text-sm">No vehicles found. Add a vehicle first.</p>
              </div>
            )}
          </div>
        )}

        {/* Step 2: Select Service */}
        {step === 2 && (
          <div>
            <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
              <Wrench className="w-5 h-5 text-blue-500" />
              Select Service Type
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {serviceTypes.map((s) => (
                <button
                  key={s.name}
                  onClick={() => setBooking({ ...booking, serviceType: s.name, estimatedCost: s.price })}
                  className={`p-4 rounded-xl border text-left transition-all flex items-center gap-3 ${
                    booking.serviceType === s.name
                      ? "border-blue-500 bg-blue-50 dark:bg-blue-900/20 ring-2 ring-blue-200 dark:ring-blue-800"
                      : "hover:border-slate-300 dark:hover:border-slate-600"
                  }`}
                  style={booking.serviceType !== s.name ? { borderColor: "var(--bg-main)" } : {}}
                >
                  <span className="text-2xl">{s.icon}</span>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm">{s.name}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-xs text-green-600 font-medium">₹{s.price.toLocaleString("en-IN")}</span>
                      <span className="text-xs text-slate-400">• {s.duration}</span>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Step 3: Choose Mechanic & Time */}
        {step === 3 && (
          <div>
            <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
              <Wrench className="w-5 h-5 text-blue-500" />
              Choose Mechanic & Schedule
            </h3>

            <div className="space-y-4">
              <div>
                <label className="text-xs font-medium text-slate-500 mb-2 block">Select Mechanic</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {mechanics.filter((m) => m.isOnline).map((m) => (
                    <button
                      key={m.id}
                      onClick={() => setBooking({ ...booking, mechanicId: m.id })}
                      className={`p-3 rounded-xl border text-left transition-all flex items-center gap-3 ${
                        booking.mechanicId === m.id
                          ? "border-blue-500 bg-blue-50 dark:bg-blue-900/20 ring-2 ring-blue-200 dark:ring-blue-800"
                          : "hover:border-slate-300 dark:hover:border-slate-600"
                      }`}
                      style={booking.mechanicId !== m.id ? { borderColor: "var(--bg-main)" } : {}}
                    >
                      <div className="w-10 h-10 rounded-lg bg-slate-200 dark:bg-slate-600 flex items-center justify-center text-sm font-bold text-slate-400 flex-shrink-0">
                        {m.name.charAt(0)}
                      </div>
                      <div className="min-w-0">
                        <p className="font-semibold text-sm truncate">{m.name}</p>
                        <p className="text-[11px] text-slate-400 truncate">{m.specialization}</p>
                        <p className="text-[11px] text-green-500">⭐ {m.rating} • ₹{m.serviceChargePerHour}/hr</p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-500 mb-1 block">Date</label>
                  <input
                    type="date"
                    value={booking.scheduledDate}
                    onChange={(e) => setBooking({ ...booking, scheduledDate: e.target.value })}
                    className="w-full border rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-blue-500"
                    style={{ borderColor: "var(--bg-main)", backgroundColor: "var(--bg-main)" }}
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-500 mb-1 block">Time</label>
                  <div className="relative">
                    <select
                      value={booking.scheduledTime}
                      onChange={(e) => setBooking({ ...booking, scheduledTime: e.target.value })}
                      className="w-full border rounded-xl px-3 py-2.5 text-sm outline-none appearance-none focus:ring-2 focus:ring-blue-500"
                      style={{ borderColor: "var(--bg-main)", backgroundColor: "var(--bg-main)" }}
                    >
                      <option value="">Select...</option>
                      {["08:00", "09:00", "10:00", "11:00", "12:00", "14:00", "15:00", "16:00", "17:00"].map((time) => (
                        <option key={time} value={time}>{time}</option>
                      ))}
                    </select>
                    <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                  </div>
                </div>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-500 mb-1 block">Description (Optional)</label>
                <textarea
                  rows={2}
                  placeholder="Describe your vehicle issue..."
                  value={booking.description}
                  onChange={(e) => setBooking({ ...booking, description: e.target.value })}
                  className="w-full border rounded-xl px-3 py-2.5 text-sm outline-none resize-none focus:ring-2 focus:ring-blue-500"
                  style={{ borderColor: "var(--bg-main)", backgroundColor: "var(--bg-main)" }}
                />
              </div>
            </div>
          </div>
        )}

        {/* Step 4: Confirm */}
        {step === 4 && (
          <div>
            <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-green-500" />
              Confirm Booking
            </h3>

            <div className="space-y-4">
              {/* Summary */}
              <div className="rounded-xl border p-4 space-y-3" style={{ borderColor: "var(--bg-main)" }}>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Vehicle</span>
                  <span className="font-medium">{selectedVehicle?.brand} {selectedVehicle?.model}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Registration</span>
                  <span className="font-mono text-xs">{selectedVehicle?.registrationNumber}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Service</span>
                  <span className="font-medium">{booking.serviceType}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Mechanic</span>
                  <span className="font-medium">{selectedMechanic?.name || "Auto-assign"}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Date & Time</span>
                  <span className="font-medium">{booking.scheduledDate} {booking.scheduledTime}</span>
                </div>
                <div className="border-t pt-3" style={{ borderColor: "var(--bg-main)" }}>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-400">Service Cost</span>
                    <span>₹{selectedService?.price.toLocaleString("en-IN")}</span>
                  </div>
                  {selectedMechanic && (
                    <div className="flex justify-between text-sm mt-1">
                      <span className="text-slate-400">Mechanic Charges (est. 2hrs)</span>
                      <span>₹{((selectedMechanic.serviceChargePerHour || 0) * 2).toLocaleString("en-IN")}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-base font-bold mt-2 pt-2 border-t" style={{ borderColor: "var(--bg-main)" }}>
                    <span>Total Estimate</span>
                    <span className="text-green-600">₹{totalCost.toLocaleString("en-IN")}</span>
                  </div>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-blue-50 dark:bg-blue-900/20 text-xs text-blue-700 dark:text-blue-300 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                <span>Final cost may vary based on parts required and actual time spent. You will be notified of any changes.</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Navigation Buttons */}
      <div className="flex justify-between">
        <button
          onClick={() => setStep(Math.max(1, step - 1))}
          className={`border px-5 py-2.5 rounded-xl text-sm font-medium hover:bg-slate-50 dark:hover:bg-slate-700 transition ${
            step === 1 ? "invisible" : ""
          }`}
          style={{ borderColor: "var(--bg-main)" }}
        >
          Back
        </button>
        {step < 4 ? (
          <button
            onClick={() => setStep(step + 1)}
            disabled={(step === 1 && !booking.vehicleId) || (step === 2 && !booking.serviceType)}
            className="bg-blue-600 text-white px-5 py-2.5 rounded-xl text-sm font-semibold hover:bg-blue-700 transition disabled:opacity-50 flex items-center gap-1"
          >
            Next <ChevronRight className="w-4 h-4" />
          </button>
        ) : (
          <button
            onClick={handleSubmit}
            disabled={isSubmitting}
            className="bg-green-600 text-white px-6 py-2.5 rounded-xl text-sm font-semibold hover:bg-green-700 transition disabled:opacity-50 flex items-center gap-2"
          >
            {isSubmitting ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Booking...
              </>
            ) : (
              <>
                <CheckCircle2 className="w-4 h-4" />
                Confirm Booking
              </>
            )}
          </button>
        )}
      </div>
    </div>
  );
}
