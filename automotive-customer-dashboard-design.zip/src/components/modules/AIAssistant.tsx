"use client";

import { useStore, translations } from "@/store/useStore";
import { useState, useRef, useEffect, useCallback } from "react";
import {
  Bot, Send, Mic, MicOff, Sparkles, Wrench, Thermometer, DollarSign,
  AlertTriangle, Zap, Camera, ImagePlus, X, ZoomIn, RotateCcw, Paperclip,
  IndianRupee, Handshake, Tag, BadgePercent, CheckCircle2
} from "lucide-react";

interface Message {
  id: number;
  role: "user" | "assistant";
  content: string;
  imageUrl?: string;
  isNegotiation?: boolean;
}

interface NegotiationState {
  service?: string;
  currentOffer?: number;
  round?: number;
  status?: string;
}

const quickActions = [
  { icon: Wrench, label: "Engine Problem", query: "My engine is making a strange noise", type: "diagnosis" },
  { icon: Thermometer, label: "AC Issue", query: "My car AC is not cooling properly", type: "diagnosis" },
  { icon: AlertTriangle, label: "Brake Issue", query: "My brakes are squeaking", type: "diagnosis" },
  { icon: Zap, label: "Battery Dead", query: "My car battery is dead and won't start", type: "diagnosis" },
  { icon: DollarSign, label: "Service Cost", query: "How much does a regular service cost?", type: "diagnosis" },
  { icon: Camera, label: "📷 Photo", query: "__photo__", type: "photo" },
  { icon: Handshake, label: "💰 Negotiate", query: "__negotiate__", type: "negotiate" },
];

const negotiationQuickOffers = [
  { label: "₹2,000", value: 2000 },
  { label: "₹2,500", value: 2500 },
  { label: "₹3,000", value: 3000 },
  { label: "₹3,500", value: 3500 },
  { label: "₹4,000", value: 4000 },
  { label: "₹5,000", value: 5000 },
];

export default function AIAssistant() {
  const { language } = useStore();
  const t = translations[language];

  const [messages, setMessages] = useState<Message[]>([
    {
      id: 0,
      role: "assistant",
      content:
        "🚗 Namaste! I'm your Automobile Indian Garage AI Assistant. I can help you with:\n\n• **Vehicle Diagnostics** - Describe or 📸 send a photo of your issue\n• **Maintenance Tips** - Service schedules & best practices\n• **Cost Estimates** - Pricing for common repairs\n• **💰 Price Negotiation** - Bargain for the best deal!\n\nTry the **Negotiate** button to get discounts on services!",
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);

  // Photo state
  const [pendingImage, setPendingImage] = useState<string | null>(null);
  const [photoCaption, setPhotoCaption] = useState("");
  const [showPhotoOptions, setShowPhotoOptions] = useState(false);
  const [previewImage, setPreviewImage] = useState<string | null>(null);

  // Negotiation state
  const [isNegotiationMode, setIsNegotiationMode] = useState(false);
  const [negotiationState, setNegotiationState] = useState<NegotiationState | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Handle file selection
  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      alert("Please select an image file.");
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      alert("Image size should be less than 10 MB.");
      return;
    }

    const reader = new FileReader();
    reader.onload = (ev) => {
      const dataUrl = ev.target?.result as string;
      setPendingImage(dataUrl);
      setShowPhotoOptions(false);
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  }, []);

  // Send a text message
  const sendMessage = async (text: string, forceNegotiation = false) => {
    if (!text.trim() || loading) return;

    // Photo quick-action
    if (text === "__photo__") {
      setShowPhotoOptions(true);
      return;
    }

    // Negotiation quick-action
    if (text === "__negotiate__") {
      setIsNegotiationMode(true);
      setNegotiationState(null);
      // Send initial negotiation request
      const userMsg: Message = { id: Date.now(), role: "user", content: "I want to negotiate prices", isNegotiation: true };
      setMessages((prev) => [...prev, userMsg]);
      setLoading(true);

      try {
        const res = await fetch("/api/ai-chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ message: "start negotiation", isNegotiation: true }),
        });
        const data = await res.json();
        const aiMsg: Message = { id: Date.now() + 1, role: "assistant", content: data.response, isNegotiation: true };
        setMessages((prev) => [...prev, aiMsg]);
        if (data.negotiationData) {
          setNegotiationState(data.negotiationData);
        }
      } catch {
        setMessages((prev) => [
          ...prev,
          { id: Date.now() + 1, role: "assistant", content: "Sorry, I encountered an error. Please try again." },
        ]);
      }
      setLoading(false);
      return;
    }

    const isNegotiating = forceNegotiation || isNegotiationMode;
    const userMsg: Message = { id: Date.now(), role: "user", content: text.trim(), isNegotiation: isNegotiating };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/api/ai-chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: text.trim(),
          hasPhoto: false,
          isNegotiation: isNegotiating,
          negotiationState: negotiationState,
        }),
      });
      const data = await res.json();
      const aiMsg: Message = { id: Date.now() + 1, role: "assistant", content: data.response, isNegotiation: isNegotiating };
      setMessages((prev) => [...prev, aiMsg]);

      // Update negotiation state
      if (data.negotiationData) {
        setNegotiationState(data.negotiationData);
        // Exit negotiation mode if deal is confirmed
        if (data.negotiationData.status === "confirmed" || data.negotiationData.status === "accepted") {
          setTimeout(() => setIsNegotiationMode(false), 2000);
        }
      }
    } catch {
      setMessages((prev) => [
        ...prev,
        { id: Date.now() + 1, role: "assistant", content: "Sorry, I encountered an error. Please try again." },
      ]);
    }
    setLoading(false);
  };

  // Send a photo message
  const sendPhotoMessage = async () => {
    if (!pendingImage || loading) return;

    const caption = photoCaption.trim() || "Uploaded a vehicle photo for diagnosis";

    const userMsg: Message = {
      id: Date.now(),
      role: "user",
      content: caption,
      imageUrl: pendingImage,
    };
    setMessages((prev) => [...prev, userMsg]);
    setPendingImage(null);
    setPhotoCaption("");
    setLoading(true);

    try {
      const res = await fetch("/api/ai-chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: caption, hasPhoto: true, photoCaption: caption }),
      });
      const data = await res.json();
      const aiMsg: Message = { id: Date.now() + 1, role: "assistant", content: data.response };
      setMessages((prev) => [...prev, aiMsg]);
    } catch {
      setMessages((prev) => [
        ...prev,
        { id: Date.now() + 1, role: "assistant", content: "Sorry, I couldn't analyze the photo. Please try again." },
      ]);
    }
    setLoading(false);
  };

  // Quick offer for negotiation
  const sendQuickOffer = (amount: number) => {
    sendMessage(`I can pay ₹${amount.toLocaleString("en-IN")}`, true);
  };

  // Accept deal
  const acceptDeal = () => {
    sendMessage("Deal! I accept this price", true);
  };

  // Exit negotiation mode
  const exitNegotiation = () => {
    setIsNegotiationMode(false);
    setNegotiationState(null);
    setMessages((prev) => [
      ...prev,
      { id: Date.now(), role: "assistant", content: "No problem! Let me know if you'd like to negotiate later. How else can I help you today? 🚗" },
    ]);
  };

  const toggleVoice = () => {
    setIsListening(!isListening);
    if (!isListening) {
      setTimeout(() => setIsListening(false), 3000);
    }
  };

  const formatContent = (content: string) => {
    return content.split("\n").map((line, i) => {
      const formatted = line.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
      const withStrike = formatted.replace(/~~(.*?)~~/g, "<s class='text-slate-400'>$1</s>");
      return (
        <span key={i} className="block" dangerouslySetInnerHTML={{ __html: withStrike || "&nbsp;" }} />
      );
    });
  };

  return (
    <div className="animate-slide-up flex flex-col" style={{ height: "calc(100vh - 140px)" }}>
      {/* Header */}
      <div className="flex items-center gap-3 mb-4">
        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
          isNegotiationMode 
            ? "bg-gradient-to-br from-green-500 to-emerald-600" 
            : "bg-gradient-to-br from-purple-500 to-blue-600"
        }`}>
          {isNegotiationMode ? <IndianRupee className="w-6 h-6 text-white" /> : <Bot className="w-6 h-6 text-white" />}
        </div>
        <div className="flex-1">
          <h2 className="text-xl font-bold flex items-center gap-2">
            {isNegotiationMode ? "Price Negotiation" : t.aiAssistant}
            {isNegotiationMode ? <BadgePercent className="w-4 h-4 text-green-500" /> : <Sparkles className="w-4 h-4 text-yellow-400" />}
          </h2>
          <p className={`text-xs flex items-center gap-1 ${isNegotiationMode ? "text-green-500" : "text-green-500"}`}>
            <span className={`w-2 h-2 rounded-full animate-pulse-dot ${isNegotiationMode ? "bg-green-500" : "bg-green-500"}`} />
            {isNegotiationMode ? "Negotiation Mode • Let's make a deal!" : "Online • Text, Voice & Photo"}
          </p>
        </div>
        {isNegotiationMode && (
          <button
            onClick={exitNegotiation}
            className="text-xs text-slate-400 hover:text-red-500 px-2 py-1 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20 transition"
          >
            Exit
          </button>
        )}
      </div>

      {/* Negotiation Status Bar */}
      {isNegotiationMode && negotiationState && (
        <div className="mb-3 p-3 rounded-xl bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border border-green-200 dark:border-green-800">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Tag className="w-4 h-4 text-green-600" />
              <span className="text-xs font-medium text-green-700 dark:text-green-300">
                {negotiationState.service?.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase()) || "Selecting service..."}
              </span>
            </div>
            {negotiationState.currentOffer && (
              <div className="flex items-center gap-1">
                <span className="text-xs text-slate-400">Current:</span>
                <span className="text-sm font-bold text-green-600">
                  ₹{negotiationState.currentOffer.toLocaleString("en-IN")}
                </span>
              </div>
            )}
          </div>
          {negotiationState.status === "accepted" && (
            <div className="mt-2 flex items-center gap-1 text-green-600">
              <CheckCircle2 className="w-4 h-4" />
              <span className="text-xs font-semibold">Deal Accepted! 🎉</span>
            </div>
          )}
        </div>
      )}

      {/* Quick Actions */}
      <div className="mb-3 overflow-x-auto pb-2">
        <div className="flex gap-2 min-w-max">
          {quickActions.map((action) => (
            <button
              key={action.label}
              onClick={() => sendMessage(action.query)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-xs font-medium transition whitespace-nowrap ${
                action.type === "photo"
                  ? "bg-gradient-to-r from-orange-500 to-pink-500 text-white border-orange-400 hover:from-orange-600 hover:to-pink-600"
                  : action.type === "negotiate"
                  ? "bg-gradient-to-r from-green-500 to-emerald-500 text-white border-green-400 hover:from-green-600 hover:to-emerald-600"
                  : "hover:bg-blue-50 hover:border-blue-300 hover:text-blue-600 dark:hover:bg-blue-900/30"
              }`}
              style={action.type === "diagnosis" ? { borderColor: "var(--bg-main)" } : undefined}
            >
              <action.icon className="w-3 h-3" />
              {action.label}
            </button>
          ))}
        </div>
      </div>

      {/* Chat Messages */}
      <div
        className="flex-1 overflow-y-auto rounded-2xl border p-4 space-y-4 mb-3"
        style={{ backgroundColor: "var(--bg-card)", borderColor: "var(--bg-main)" }}
      >
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex gap-2.5 ${msg.role === "user" ? "justify-end" : "justify-start"}`}
          >
            {msg.role === "assistant" && (
              <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                msg.isNegotiation 
                  ? "bg-gradient-to-br from-green-500 to-emerald-600" 
                  : "bg-gradient-to-br from-purple-500 to-blue-600"
              }`}>
                {msg.isNegotiation ? <IndianRupee className="w-4 h-4 text-white" /> : <Bot className="w-4 h-4 text-white" />}
              </div>
            )}
            <div
              className={`max-w-[85%] sm:max-w-[75%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                msg.role === "user"
                  ? msg.isNegotiation
                    ? "bg-green-600 text-white rounded-br-md"
                    : "bg-blue-600 text-white rounded-br-md"
                  : "bg-slate-100 dark:bg-slate-700 rounded-bl-md"
              }`}
            >
              {msg.imageUrl && (
                <div className="mb-2 relative group">
                  <img
                    src={msg.imageUrl}
                    alt="Uploaded vehicle photo"
                    className="rounded-xl max-h-48 w-auto object-cover cursor-pointer border border-white/20"
                    onClick={() => setPreviewImage(msg.imageUrl ?? null)}
                  />
                  <button
                    onClick={() => setPreviewImage(msg.imageUrl ?? null)}
                    className="absolute top-2 right-2 w-7 h-7 bg-black/50 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <ZoomIn className="w-3.5 h-3.5 text-white" />
                  </button>
                </div>
              )}
              {formatContent(msg.content)}
            </div>
            {msg.role === "user" && (
              <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-white text-xs font-bold ${
                msg.isNegotiation 
                  ? "bg-gradient-to-br from-green-500 to-green-700" 
                  : "bg-gradient-to-br from-blue-500 to-blue-700"
              }`}>
                RK
              </div>
            )}
          </div>
        ))}

        {/* Loading indicator */}
        {loading && (
          <div className="flex gap-2.5">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
              isNegotiationMode 
                ? "bg-gradient-to-br from-green-500 to-emerald-600" 
                : "bg-gradient-to-br from-purple-500 to-blue-600"
            }`}>
              {isNegotiationMode ? <IndianRupee className="w-4 h-4 text-white" /> : <Bot className="w-4 h-4 text-white" />}
            </div>
            <div className="bg-slate-100 dark:bg-slate-700 rounded-2xl rounded-bl-md px-4 py-3">
              <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
                {isNegotiationMode ? <IndianRupee className="w-3 h-3 animate-pulse" /> : <Camera className="w-3 h-3 animate-pulse" />}
                <span>{isNegotiationMode ? "Calculating..." : "Analyzing..."}</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Offer Buttons (Negotiation Mode) */}
      {isNegotiationMode && negotiationState?.status !== "confirmed" && negotiationState?.status !== "accepted" && (
        <div className="mb-3 p-3 rounded-xl border" style={{ backgroundColor: "var(--bg-card)", borderColor: "var(--bg-main)" }}>
          <p className="text-[11px] text-slate-400 mb-2 font-medium">Quick Offers:</p>
          <div className="flex flex-wrap gap-2">
            {negotiationQuickOffers.map((offer) => (
              <button
                key={offer.value}
                onClick={() => sendQuickOffer(offer.value)}
                disabled={loading}
                className="px-3 py-1.5 rounded-full bg-green-50 dark:bg-green-900/30 border border-green-200 dark:border-green-800 text-green-700 dark:text-green-300 text-xs font-medium hover:bg-green-100 dark:hover:bg-green-900/50 transition disabled:opacity-50"
              >
                {offer.label}
              </button>
            ))}
            <button
              onClick={acceptDeal}
              disabled={loading || !negotiationState?.currentOffer}
              className="px-3 py-1.5 rounded-full bg-green-600 text-white text-xs font-semibold hover:bg-green-700 transition disabled:opacity-50 flex items-center gap-1"
            >
              <CheckCircle2 className="w-3 h-3" />
              Accept Deal
            </button>
          </div>
        </div>
      )}

      {/* Pending Image Preview */}
      {pendingImage && (
        <div
          className="rounded-2xl border p-3 mb-3 animate-slide-up"
          style={{ backgroundColor: "var(--bg-card)", borderColor: "var(--bg-main)" }}
        >
          <div className="flex items-start gap-3">
            <div className="relative flex-shrink-0">
              <img
                src={pendingImage}
                alt="Preview"
                className="w-20 h-20 sm:w-24 sm:h-24 rounded-xl object-cover border"
                style={{ borderColor: "var(--bg-main)" }}
              />
              <button
                onClick={() => setPreviewImage(pendingImage)}
                className="absolute top-1 right-1 w-6 h-6 bg-black/50 rounded-full flex items-center justify-center"
              >
                <ZoomIn className="w-3 h-3 text-white" />
              </button>
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1.5">
                <p className="text-xs font-semibold flex items-center gap-1 text-green-600">
                  <Camera className="w-3.5 h-3.5" />
                  Photo ready to send
                </p>
                <button
                  onClick={() => { setPendingImage(null); setPhotoCaption(""); }}
                  className="p-1 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 transition"
                >
                  <X className="w-4 h-4 text-slate-400" />
                </button>
              </div>
              <input
                type="text"
                placeholder="Add caption... e.g. 'Tyre has a crack'"
                value={photoCaption}
                onChange={(e) => setPhotoCaption(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && sendPhotoMessage()}
                className="w-full border rounded-lg px-3 py-2 text-xs outline-none focus:ring-2 focus:ring-blue-500 mb-2"
                style={{ borderColor: "var(--bg-main)", backgroundColor: "var(--bg-main)" }}
              />
              <div className="flex gap-2">
                <button
                  onClick={sendPhotoMessage}
                  disabled={loading}
                  className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 text-white py-2 rounded-lg text-xs font-semibold hover:from-blue-700 hover:to-purple-700 transition disabled:opacity-50 flex items-center justify-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  Send for AI Diagnosis
                </button>
                <button
                  onClick={() => { setPendingImage(null); setPhotoCaption(""); }}
                  className="px-3 py-2 border rounded-lg text-xs font-medium hover:bg-slate-50 dark:hover:bg-slate-700 transition"
                  style={{ borderColor: "var(--bg-main)" }}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Photo Options Popup */}
      {showPhotoOptions && (
        <div
          className="rounded-2xl border p-4 mb-3 animate-slide-up"
          style={{ backgroundColor: "var(--bg-card)", borderColor: "var(--bg-main)" }}
        >
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-sm font-bold flex items-center gap-2">
              <Camera className="w-4 h-4 text-orange-500" />
              Upload Vehicle Photo
            </h4>
            <button
              onClick={() => setShowPhotoOptions(false)}
              className="p-1 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 transition"
            >
              <X className="w-4 h-4 text-slate-400" />
            </button>
          </div>
          <p className="text-xs text-slate-400 mb-3">
            Take or upload a photo of your vehicle issue — our AI will analyze it and suggest fixes with cost estimates.
          </p>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => cameraInputRef.current?.click()}
              className="flex flex-col items-center gap-2 p-4 border-2 border-dashed rounded-xl hover:border-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition cursor-pointer"
              style={{ borderColor: "var(--bg-main)" }}
            >
              <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900/40 flex items-center justify-center">
                <Camera className="w-6 h-6 text-blue-600" />
              </div>
              <span className="text-xs font-semibold">Take Photo</span>
              <span className="text-[10px] text-slate-400">Open Camera</span>
            </button>
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex flex-col items-center gap-2 p-4 border-2 border-dashed rounded-xl hover:border-purple-400 hover:bg-purple-50 dark:hover:bg-purple-900/20 transition cursor-pointer"
              style={{ borderColor: "var(--bg-main)" }}
            >
              <div className="w-12 h-12 rounded-full bg-purple-100 dark:bg-purple-900/40 flex items-center justify-center">
                <ImagePlus className="w-6 h-6 text-purple-600" />
              </div>
              <span className="text-xs font-semibold">From Gallery</span>
              <span className="text-[10px] text-slate-400">Choose Photo</span>
            </button>
          </div>
          <div className="mt-3 p-2.5 rounded-lg bg-orange-50 dark:bg-orange-900/20 flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-orange-500 flex-shrink-0 mt-0.5" />
            <p className="text-[11px] text-orange-700 dark:text-orange-300">
              <strong>Tips:</strong> Take clear, well-lit photos. Show the issue close-up for better diagnosis.
            </p>
          </div>
        </div>
      )}

      {/* Hidden file inputs */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleFileSelect}
      />
      <input
        ref={cameraInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        className="hidden"
        onChange={handleFileSelect}
      />

      {/* Input Bar */}
      <div
        className={`flex items-center gap-1.5 sm:gap-2 rounded-2xl border p-2 pl-3 ${
          isNegotiationMode ? "border-green-300 dark:border-green-700" : ""
        }`}
        style={{ backgroundColor: "var(--bg-card)", borderColor: isNegotiationMode ? undefined : "var(--bg-main)" }}
      >
        {/* Attach / Photo button */}
        <button
          onClick={() => setShowPhotoOptions(!showPhotoOptions)}
          className={`p-2 rounded-xl transition flex-shrink-0 ${
            showPhotoOptions
              ? "bg-orange-500 text-white"
              : "hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-400 hover:text-orange-500"
          }`}
          title="Upload Photo"
        >
          <Paperclip className="w-4 h-4" />
        </button>

        <input
          type="text"
          placeholder={isNegotiationMode ? "Enter your offer... e.g. ₹3,000" : t.askAI}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && sendMessage(input)}
          className="flex-1 bg-transparent text-sm outline-none placeholder:text-slate-400 min-w-0"
        />

        {/* Voice button */}
        <button
          onClick={toggleVoice}
          className={`p-2 rounded-xl transition flex-shrink-0 ${
            isListening
              ? "bg-red-500 text-white animate-pulse"
              : "hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-400"
          }`}
        >
          {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
        </button>

        {/* Negotiate toggle */}
        <button
          onClick={() => {
            if (isNegotiationMode) {
              exitNegotiation();
            } else {
              sendMessage("__negotiate__");
            }
          }}
          className={`p-2 rounded-xl transition flex-shrink-0 ${
            isNegotiationMode
              ? "bg-green-500 text-white"
              : "hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-400 hover:text-green-500"
          }`}
          title="Negotiate Prices"
        >
          <Handshake className="w-4 h-4" />
        </button>

        {/* Send button */}
        <button
          onClick={() => sendMessage(input)}
          disabled={!input.trim() || loading}
          className={`p-2.5 text-white rounded-xl transition disabled:opacity-50 flex-shrink-0 ${
            isNegotiationMode
              ? "bg-green-600 hover:bg-green-700"
              : "bg-blue-600 hover:bg-blue-700"
          }`}
        >
          <Send className="w-4 h-4" />
        </button>
      </div>

      {/* Full-screen Image Preview Modal */}
      {previewImage && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 sm:p-8">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setPreviewImage(null)} />
          <div className="relative max-w-3xl w-full max-h-[85vh] animate-fade-in">
            <img
              src={previewImage}
              alt="Full preview"
              className="w-full h-full object-contain rounded-2xl"
            />
            <button
              onClick={() => setPreviewImage(null)}
              className="absolute top-3 right-3 w-10 h-10 bg-black/60 backdrop-blur-sm rounded-full flex items-center justify-center text-white hover:bg-black/80 transition"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="absolute bottom-3 left-3 right-3 flex justify-center gap-2">
              <button
                onClick={() => setPreviewImage(null)}
                className="bg-white/90 backdrop-blur-sm text-slate-800 px-4 py-2 rounded-xl text-sm font-medium hover:bg-white transition flex items-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" /> Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
