"use client";

import { useStore, translations } from "@/store/useStore";
import {
  User, Moon, Sun, Globe, Bell, Shield, CreditCard, HelpCircle, LogOut,
  ChevronRight, Phone, Mail, MapPin, Edit3
} from "lucide-react";

export default function ProfileSettings() {
  const { language, setLanguage, darkMode, toggleDarkMode } = useStore();
  const t = translations[language];

  const settingsGroups = [
    {
      title: "Account",
      items: [
        { icon: User, label: "Edit Profile", desc: "Update your personal info", action: () => {} },
        { icon: CreditCard, label: "Payment Methods", desc: "Manage cards & UPI", action: () => {} },
        { icon: MapPin, label: "Saved Addresses", desc: "Home, Office, Garage", action: () => {} },
      ],
    },
    {
      title: "Preferences",
      items: [
        {
          icon: darkMode ? Sun : Moon,
          label: t.darkMode,
          desc: darkMode ? "Switch to light theme" : "Switch to dark theme",
          action: toggleDarkMode,
          toggle: true,
          isOn: darkMode,
        },
        {
          icon: Globe,
          label: t.language,
          desc: language === "en" ? "English" : language === "hi" ? "हिन्दी" : "मराठी",
          action: () => {
            const langs: Array<"en" | "hi" | "mr"> = ["en", "hi", "mr"];
            const idx = langs.indexOf(language);
            setLanguage(langs[(idx + 1) % 3]);
          },
        },
        { icon: Bell, label: "Push Notifications", desc: "Manage notification preferences", action: () => {}, toggle: true, isOn: true },
      ],
    },
    {
      title: "Support",
      items: [
        { icon: HelpCircle, label: "Help & FAQ", desc: "Common questions answered", action: () => {} },
        { icon: Shield, label: "Privacy & Security", desc: "Data protection settings", action: () => {} },
        { icon: Phone, label: "Contact Support", desc: "24/7 helpline available", action: () => {} },
      ],
    },
  ];

  return (
    <div className="space-y-5 animate-slide-up">
      {/* Profile Card */}
      <div
        className="rounded-2xl border p-5 sm:p-6"
        style={{ backgroundColor: "var(--bg-card)", borderColor: "var(--bg-main)" }}
      >
        <div className="flex flex-col sm:flex-row items-center gap-4">
          <div className="relative">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center text-white text-2xl font-bold">
              RK
            </div>
            <button className="absolute -bottom-1 -right-1 w-7 h-7 bg-blue-600 text-white rounded-full flex items-center justify-center shadow-lg">
              <Edit3 className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="text-center sm:text-left flex-1">
            <h2 className="text-xl font-bold">Rajesh Kumar</h2>
            <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-3 mt-1 text-sm text-slate-400">
              <span className="flex items-center gap-1 justify-center sm:justify-start">
                <Mail className="w-3.5 h-3.5" /> rajesh.kumar@email.com
              </span>
              <span className="flex items-center gap-1 justify-center sm:justify-start">
                <Phone className="w-3.5 h-3.5" /> +91 98765 43210
              </span>
            </div>
            <div className="flex items-center gap-1 justify-center sm:justify-start mt-1 text-sm text-slate-400">
              <MapPin className="w-3.5 h-3.5" /> Mumbai, Maharashtra
            </div>
          </div>
          <div className="text-center">
            <div className="bg-orange-50 dark:bg-orange-900/30 rounded-xl px-4 py-2">
              <p className="text-2xl font-bold text-orange-500">⭐ 4.8</p>
              <p className="text-[10px] text-slate-400">Customer Rating</p>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-4 mt-5 pt-5 border-t" style={{ borderColor: "var(--bg-main)" }}>
          <div className="text-center">
            <p className="text-xl font-bold text-blue-500">2</p>
            <p className="text-xs text-slate-400">Vehicles</p>
          </div>
          <div className="text-center">
            <p className="text-xl font-bold text-green-500">12</p>
            <p className="text-xs text-slate-400">Services</p>
          </div>
          <div className="text-center">
            <p className="text-xl font-bold text-purple-500">₹24K</p>
            <p className="text-xs text-slate-400">Total Spent</p>
          </div>
        </div>
      </div>

      {/* Settings Groups */}
      {settingsGroups.map((group) => (
        <div key={group.title}>
          <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 px-1">{group.title}</h3>
          <div
            className="rounded-xl border overflow-hidden [&>*+*]:border-t"
            style={{ backgroundColor: "var(--bg-card)", borderColor: "var(--bg-main)" }}
          >
            {group.items.map((item) => (
              <button
                key={item.label}
                onClick={item.action}
                className="w-full flex items-center gap-3 p-4 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition text-left"
              >
                <div className="w-9 h-9 rounded-lg bg-slate-100 dark:bg-slate-700 flex items-center justify-center flex-shrink-0">
                  <item.icon className="w-4 h-4 text-slate-500" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium">{item.label}</p>
                  <p className="text-xs text-slate-400 truncate">{item.desc}</p>
                </div>
                {"toggle" in item && item.toggle ? (
                  <div className={`w-11 h-6 rounded-full relative transition-colors ${
                    item.isOn ? "bg-blue-600" : "bg-slate-200 dark:bg-slate-600"
                  }`}>
                    <div className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${
                      item.isOn ? "translate-x-5.5" : "translate-x-0.5"
                    }`} />
                  </div>
                ) : (
                  <ChevronRight className="w-4 h-4 text-slate-400 flex-shrink-0" />
                )}
              </button>
            ))}
          </div>
        </div>
      ))}

      {/* Logout */}
      <button className="w-full flex items-center justify-center gap-2 border border-red-200 dark:border-red-900 text-red-500 py-3 rounded-xl text-sm font-semibold hover:bg-red-50 dark:hover:bg-red-900/20 transition">
        <LogOut className="w-4 h-4" />
        {t.logout}
      </button>
    </div>
  );
}
