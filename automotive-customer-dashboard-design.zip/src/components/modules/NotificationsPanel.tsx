"use client";

import { useStore, translations } from "@/store/useStore";
import {
  Bell, CheckCircle2, Calendar, CreditCard, AlertTriangle, Wrench, Clock,
  CheckCheck
} from "lucide-react";

interface Notification {
  id: number;
  title: string;
  message: string;
  type: string;
  isRead: boolean | null;
  createdAt: string | null;
}

interface Props {
  notifications: Notification[];
  onRefresh: () => void;
}

const typeConfig: Record<string, { icon: typeof Bell; color: string; bg: string }> = {
  service: { icon: Wrench, color: "text-blue-500", bg: "bg-blue-50 dark:bg-blue-900/30" },
  booking: { icon: Calendar, color: "text-green-500", bg: "bg-green-50 dark:bg-green-900/30" },
  completed: { icon: CheckCircle2, color: "text-green-500", bg: "bg-green-50 dark:bg-green-900/30" },
  payment: { icon: CreditCard, color: "text-purple-500", bg: "bg-purple-50 dark:bg-purple-900/30" },
  reminder: { icon: AlertTriangle, color: "text-orange-500", bg: "bg-orange-50 dark:bg-orange-900/30" },
};

export default function NotificationsPanel({ notifications, onRefresh }: Props) {
  const { language } = useStore();
  const t = translations[language];
  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const markRead = async (id: number) => {
    try {
      await fetch(`/api/notifications?id=${id}`, { method: "PATCH" });
      onRefresh();
    } catch (err) {
      console.error(err);
    }
  };

  const markAllRead = async () => {
    const unread = notifications.filter((n) => !n.isRead);
    for (const n of unread) {
      await fetch(`/api/notifications?id=${n.id}`, { method: "PATCH" });
    }
    onRefresh();
  };

  return (
    <div className="space-y-5 animate-slide-up">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold flex items-center gap-2">
            <Bell className="w-6 h-6 text-blue-500" />
            {t.notifications}
          </h2>
          <p className="text-sm text-slate-400 mt-0.5">
            {unreadCount} unread notification{unreadCount !== 1 ? "s" : ""}
          </p>
        </div>
        {unreadCount > 0 && (
          <button
            onClick={markAllRead}
            className="text-blue-500 text-sm font-medium flex items-center gap-1 hover:underline w-fit"
          >
            <CheckCheck className="w-4 h-4" />
            Mark all as read
          </button>
        )}
      </div>

      {/* Notification List */}
      <div className="space-y-3">
        {notifications.map((notif) => {
          const config = typeConfig[notif.type] || typeConfig.service;
          const Icon = config.icon;
          return (
            <div
              key={notif.id}
              onClick={() => !notif.isRead && markRead(notif.id)}
              className={`rounded-xl border p-4 flex items-start gap-3 transition-all cursor-pointer hover:shadow-md ${
                !notif.isRead ? "border-l-4 border-l-blue-500" : ""
              }`}
              style={{ backgroundColor: "var(--bg-card)", borderColor: notif.isRead ? "var(--bg-main)" : undefined }}
            >
              <div className={`w-10 h-10 rounded-lg ${config.bg} flex items-center justify-center flex-shrink-0`}>
                <Icon className={`w-5 h-5 ${config.color}`} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2">
                  <p className={`text-sm font-semibold truncate ${!notif.isRead ? "" : "text-slate-500"}`}>
                    {notif.title}
                  </p>
                  {!notif.isRead && (
                    <span className="w-2.5 h-2.5 bg-blue-500 rounded-full flex-shrink-0 mt-1.5" />
                  )}
                </div>
                <p className="text-xs text-slate-400 mt-0.5 line-clamp-2">{notif.message}</p>
                <p className="text-[10px] text-slate-400 mt-1.5 flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {notif.createdAt
                    ? new Date(notif.createdAt).toLocaleString("en-IN", {
                        day: "numeric", month: "short", hour: "2-digit", minute: "2-digit"
                      })
                    : "Just now"
                  }
                </p>
              </div>
            </div>
          );
        })}
        {notifications.length === 0 && (
          <div className="text-center py-10 text-slate-400">
            <Bell className="w-12 h-12 mx-auto mb-2 opacity-30" />
            <p className="text-sm">No notifications yet</p>
          </div>
        )}
      </div>
    </div>
  );
}
