"use client";

import { useStore, translations } from "@/store/useStore";
import {
  Activity, Wrench, HeartPulse, CalendarClock, Clock, Phone, AlertTriangle,
  ChevronRight, MapPin, Gauge, Fuel, Car, TrendingUp, CheckCircle2, Timer
} from "lucide-react";

interface Vehicle {
  id: number;
  brand: string;
  model: string;
  registrationNumber: string;
  healthScore: number | null;
  fuelType: string;
  odometerReading: number | null;
  serviceDueDate: string | null;
  imageUrl: string | null;
}

interface Mechanic {
  id: number;
  name: string;
  specialization: string;
  rating: string | null;
  isOnline: boolean | null;
  distanceKm: string | null;
  estimatedArrival: string | null;
  avatarUrl: string | null;
}

interface ServiceRequest {
  id: number;
  serviceType: string;
  status: string;
  scheduledDate: string | null;
  estimatedCost: number | null;
  vehicleId: number;
  mechanicId: number | null;
}

interface Props {
  vehicles: Vehicle[];
  mechanics: Mechanic[];
  services: ServiceRequest[];
}

export default function HomeDashboard({ vehicles, mechanics, services }: Props) {
  const { language, setActiveNav } = useStore();
  const t = translations[language];

  const activeServices = services.filter((s) => s.status === "in_progress" || s.status === "pending");
  const onlineMechanics = mechanics.filter((m) => m.isOnline);

  const getHealthColor = (score: number) => {
    if (score >= 80) return "text-green-500";
    if (score >= 60) return "text-yellow-500";
    return "text-red-500";
  };

  const getHealthBg = (score: number) => {
    if (score >= 80) return "bg-green-500";
    if (score >= 60) return "bg-yellow-500";
    return "bg-red-500";
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "in_progress": return { label: "In Progress", bg: "bg-blue-100 text-blue-700 dark:bg-blue-900/50 dark:text-blue-300" };
      case "pending": return { label: "Pending", bg: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/50 dark:text-yellow-300" };
      case "completed": return { label: "Completed", bg: "bg-green-100 text-green-700 dark:bg-green-900/50 dark:text-green-300" };
      default: return { label: status, bg: "bg-slate-100 text-slate-700" };
    }
  };

  return (
    <div className="space-y-6 animate-slide-up">
      {/* Welcome Banner */}
      <div className="rounded-2xl bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 p-5 sm:p-6 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-40 h-40 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2" />
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/5 rounded-full translate-y-1/2 -translate-x-1/2" />
        <div className="relative">
          <p className="text-blue-200 text-sm">{t.welcome},</p>
          <h2 className="text-2xl sm:text-3xl font-bold mt-1">Rajesh Kumar 👋</h2>
          <p className="text-blue-200 text-sm mt-2">
            You have {activeServices.length} active service request{activeServices.length !== 1 ? "s" : ""}
          </p>
          <div className="flex flex-wrap gap-3 mt-4">
            <button
              onClick={() => setActiveNav("booking")}
              className="bg-white text-blue-700 px-4 py-2 rounded-xl text-sm font-semibold hover:bg-blue-50 transition flex items-center gap-1.5"
            >
              <CalendarClock className="w-4 h-4" />
              {t.bookService}
            </button>
            <button className="bg-red-500/90 text-white px-4 py-2 rounded-xl text-sm font-semibold hover:bg-red-600 transition flex items-center gap-1.5">
              <Phone className="w-4 h-4" />
              {t.emergency}
            </button>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {[
          { icon: Activity, label: t.activeServices, value: activeServices.length.toString(), color: "text-blue-500", bg: "bg-blue-50 dark:bg-blue-900/30" },
          { icon: Wrench, label: t.nearbyMechanics, value: onlineMechanics.length.toString(), color: "text-green-500", bg: "bg-green-50 dark:bg-green-900/30" },
          { icon: Car, label: t.myVehicles, value: vehicles.length.toString(), color: "text-purple-500", bg: "bg-purple-50 dark:bg-purple-900/30" },
          { icon: TrendingUp, label: t.upcomingReminders, value: "2", color: "text-orange-500", bg: "bg-orange-50 dark:bg-orange-900/30" },
        ].map((stat) => (
          <div
            key={stat.label}
            className="rounded-xl p-4 border transition-shadow hover:shadow-md cursor-pointer"
            style={{ backgroundColor: "var(--bg-card)", borderColor: "var(--bg-main)" }}
          >
            <div className={`w-10 h-10 ${stat.bg} rounded-lg flex items-center justify-center mb-3`}>
              <stat.icon className={`w-5 h-5 ${stat.color}`} />
            </div>
            <p className="text-2xl font-bold">{stat.value}</p>
            <p className="text-xs text-slate-400 mt-0.5">{stat.label}</p>
          </div>
        ))}
      </div>

      {/* Active Service Requests */}
      {activeServices.length > 0 && (
        <div
          className="rounded-xl border p-4 sm:p-5"
          style={{ backgroundColor: "var(--bg-card)", borderColor: "var(--bg-main)" }}
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-base flex items-center gap-2">
              <Activity className="w-5 h-5 text-blue-500" />
              {t.activeServices}
            </h3>
            <button
              onClick={() => setActiveNav("history")}
              className="text-blue-500 text-sm flex items-center gap-0.5 hover:underline"
            >
              {t.viewAll} <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="space-y-3">
            {activeServices.map((service) => {
              const vehicle = vehicles.find((v) => v.id === service.vehicleId);
              const mechanic = mechanics.find((m) => m.id === service.mechanicId);
              const badge = getStatusBadge(service.status);
              return (
                <div
                  key={service.id}
                  className="flex flex-col sm:flex-row sm:items-center gap-3 p-4 rounded-xl border hover:shadow-md transition-shadow cursor-pointer"
                  style={{ borderColor: "var(--bg-main)" }}
                >
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    <div className="w-10 h-10 bg-blue-50 dark:bg-blue-900/30 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Wrench className="w-5 h-5 text-blue-500" />
                    </div>
                    <div className="min-w-0">
                      <p className="font-semibold text-sm truncate">{service.serviceType}</p>
                      <p className="text-xs text-slate-400 truncate">
                        {vehicle ? `${vehicle.brand} ${vehicle.model}` : "Vehicle"} • {mechanic?.name || "Assigning..."}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 sm:gap-3 sm:ml-auto">
                    <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${badge.bg}`}>
                      {badge.label}
                    </span>
                    {service.estimatedCost && (
                      <span className="text-sm font-semibold text-green-600">
                        ₹{service.estimatedCost.toLocaleString("en-IN")}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Vehicle Health + Nearby Mechanics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-5">
        {/* Vehicle Health */}
        <div
          className="rounded-xl border p-4 sm:p-5"
          style={{ backgroundColor: "var(--bg-card)", borderColor: "var(--bg-main)" }}
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-base flex items-center gap-2">
              <HeartPulse className="w-5 h-5 text-red-500" />
              {t.vehicleHealth}
            </h3>
            <button
              onClick={() => setActiveNav("vehicles")}
              className="text-blue-500 text-sm flex items-center gap-0.5 hover:underline"
            >
              {t.viewAll} <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="space-y-4">
            {vehicles.map((v) => {
              const score = v.healthScore || 0;
              return (
                <div key={v.id} className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-lg bg-slate-100 dark:bg-slate-700 overflow-hidden flex-shrink-0">
                    {v.imageUrl ? (
                      <img src={v.imageUrl} alt={v.model} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Car className="w-6 h-6 text-slate-400" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm truncate">{v.brand} {v.model}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <div className="flex-1 h-2 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${getHealthBg(score)}`}
                          style={{ width: `${score}%` }}
                        />
                      </div>
                      <span className={`text-xs font-bold ${getHealthColor(score)}`}>
                        {score}%
                      </span>
                    </div>
                    <div className="flex items-center gap-3 mt-1">
                      <span className="text-[10px] text-slate-400 flex items-center gap-0.5">
                        <Gauge className="w-3 h-3" /> {v.odometerReading?.toLocaleString("en-IN")} km
                      </span>
                      <span className="text-[10px] text-slate-400 flex items-center gap-0.5">
                        <Fuel className="w-3 h-3" /> {v.fuelType}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Nearby Mechanics */}
        <div
          className="rounded-xl border p-4 sm:p-5"
          style={{ backgroundColor: "var(--bg-card)", borderColor: "var(--bg-main)" }}
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-base flex items-center gap-2">
              <MapPin className="w-5 h-5 text-green-500" />
              {t.nearbyMechanics}
            </h3>
            <button
              onClick={() => setActiveNav("mechanics")}
              className="text-blue-500 text-sm flex items-center gap-0.5 hover:underline"
            >
              {t.viewAll} <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="space-y-3">
            {onlineMechanics.slice(0, 3).map((m) => (
              <div key={m.id} className="flex items-center gap-3 p-3 rounded-xl border hover:shadow-sm transition" style={{ borderColor: "var(--bg-main)" }}>
                <div className="relative flex-shrink-0">
                  <div className="w-10 h-10 rounded-full bg-slate-200 dark:bg-slate-600 overflow-hidden">
                    {m.avatarUrl ? (
                      <img src={m.avatarUrl} alt={m.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-sm font-bold text-slate-400">
                        {m.name.charAt(0)}
                      </div>
                    )}
                  </div>
                  <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-green-500 border-2 rounded-full" style={{ borderColor: "var(--bg-card)" }} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm truncate">{m.name}</p>
                  <p className="text-[11px] text-slate-400 truncate">{m.specialization}</p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-xs text-slate-400 flex items-center gap-0.5 justify-end">
                    <MapPin className="w-3 h-3" /> {m.distanceKm} km
                  </p>
                  <p className="text-[11px] text-green-500 flex items-center gap-0.5 justify-end">
                    <Timer className="w-3 h-3" /> {m.estimatedArrival}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Upcoming Reminders + Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-5">
        {/* Upcoming Reminders */}
        <div
          className="rounded-xl border p-4 sm:p-5"
          style={{ backgroundColor: "var(--bg-card)", borderColor: "var(--bg-main)" }}
        >
          <h3 className="font-semibold text-base flex items-center gap-2 mb-4">
            <CalendarClock className="w-5 h-5 text-orange-500" />
            {t.upcomingReminders}
          </h3>
          <div className="space-y-3">
            {[
              { title: "Ciaz Regular Service Due", date: "Jan 15, 2025", priority: "high", icon: AlertTriangle },
              { title: "XUV700 Insurance Renewal", date: "Dec 15, 2025", priority: "medium", icon: CalendarClock },
            ].map((rem, i) => (
              <div key={i} className="flex items-center gap-3 p-3 rounded-xl border" style={{ borderColor: "var(--bg-main)" }}>
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
                  rem.priority === "high" ? "bg-red-50 dark:bg-red-900/30" : "bg-orange-50 dark:bg-orange-900/30"
                }`}>
                  <rem.icon className={`w-5 h-5 ${
                    rem.priority === "high" ? "text-red-500" : "text-orange-500"
                  }`} />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium">{rem.title}</p>
                  <p className="text-xs text-slate-400">{rem.date}</p>
                </div>
                <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full ${
                  rem.priority === "high" ? "bg-red-100 text-red-700 dark:bg-red-900/50 dark:text-red-300" : "bg-orange-100 text-orange-700 dark:bg-orange-900/50 dark:text-orange-300"
                }`}>
                  {rem.priority === "high" ? "Urgent" : "Upcoming"}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Activity */}
        <div
          className="rounded-xl border p-4 sm:p-5"
          style={{ backgroundColor: "var(--bg-card)", borderColor: "var(--bg-main)" }}
        >
          <h3 className="font-semibold text-base flex items-center gap-2 mb-4">
            <Clock className="w-5 h-5 text-purple-500" />
            {t.recentActivity}
          </h3>
          <div className="space-y-3">
            {[
              { title: "Brake pad replacement completed", time: "2 hours ago", icon: CheckCircle2, color: "text-green-500" },
              { title: "General service booked for XUV700", time: "1 day ago", icon: CalendarClock, color: "text-blue-500" },
              { title: "Payment of ₹3,100 processed", time: "2 days ago", icon: CheckCircle2, color: "text-green-500" },
              { title: "AC Repair request submitted", time: "3 days ago", icon: Activity, color: "text-orange-500" },
            ].map((act, i) => (
              <div key={i} className="flex items-start gap-3">
                <div className="relative flex-shrink-0 mt-0.5">
                  <act.icon className={`w-4 h-4 ${act.color}`} />
                </div>
                <div className="flex-1">
                  <p className="text-sm">{act.title}</p>
                  <p className="text-xs text-slate-400">{act.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
