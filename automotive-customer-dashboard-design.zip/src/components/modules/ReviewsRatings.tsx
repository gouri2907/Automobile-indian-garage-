"use client";

import { useStore, translations } from "@/store/useStore";
import { useState } from "react";
import { Star, MessageSquare, ThumbsUp, Filter, Plus, X, Send } from "lucide-react";

interface Review {
  id: number;
  mechanicId: number;
  rating: number;
  serviceQuality: number | null;
  responseTime: number | null;
  comment: string | null;
  createdAt: string | null;
}

interface Mechanic {
  id: number;
  name: string;
  avatarUrl: string | null;
}

interface Props {
  reviews: Review[];
  mechanics: Mechanic[];
  onRefresh: () => void;
}

export default function ReviewsRatings({ reviews, mechanics, onRefresh }: Props) {
  const { language } = useStore();
  const t = translations[language];
  const [showForm, setShowForm] = useState(false);
  const [filterRating, setFilterRating] = useState(0);
  const [newReview, setNewReview] = useState({
    mechanicId: 0,
    rating: 0,
    serviceQuality: 0,
    responseTime: 0,
    comment: "",
  });

  const filteredReviews = filterRating > 0
    ? reviews.filter((r) => r.rating === filterRating)
    : reviews;

  const avgRating = reviews.length > 0
    ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)
    : "0.0";

  const avgServiceQuality = reviews.length > 0
    ? (reviews.reduce((sum, r) => sum + (r.serviceQuality || 0), 0) / reviews.length).toFixed(1)
    : "0.0";

  const avgResponseTime = reviews.length > 0
    ? (reviews.reduce((sum, r) => sum + (r.responseTime || 0), 0) / reviews.length).toFixed(1)
    : "0.0";

  const handleSubmit = async () => {
    if (!newReview.mechanicId || !newReview.rating) return;
    try {
      await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newReview),
      });
      setShowForm(false);
      setNewReview({ mechanicId: 0, rating: 0, serviceQuality: 0, responseTime: 0, comment: "" });
      onRefresh();
    } catch (err) {
      console.error(err);
    }
  };

  const RatingStars = ({ rating, size = 4, interactive = false, onChange }: {
    rating: number;
    size?: number;
    interactive?: boolean;
    onChange?: (r: number) => void;
  }) => (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map((s) => (
        <Star
          key={s}
          className={`w-${size} h-${size} transition-colors ${
            s <= rating ? "text-yellow-400 fill-yellow-400" : "text-slate-300 dark:text-slate-600"
          } ${interactive ? "cursor-pointer hover:text-yellow-300" : ""}`}
          style={{ width: `${size * 4}px`, height: `${size * 4}px` }}
          onClick={() => interactive && onChange?.(s)}
        />
      ))}
    </div>
  );

  return (
    <div className="space-y-5 animate-slide-up">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold flex items-center gap-2">
            <Star className="w-6 h-6 text-yellow-400 fill-yellow-400" />
            {t.reviews}
          </h2>
          <p className="text-sm text-slate-400 mt-0.5">{reviews.length} reviews</p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="bg-blue-600 text-white px-4 py-2.5 rounded-xl text-sm font-semibold hover:bg-blue-700 transition flex items-center gap-2 w-fit"
        >
          <Plus className="w-4 h-4" />
          {t.writeReview}
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {[
          { label: t.overallRating, value: avgRating, sub: `${reviews.length} reviews` },
          { label: t.serviceQuality, value: avgServiceQuality, sub: "Average" },
          { label: t.responseTime, value: avgResponseTime, sub: "Average" },
        ].map((stat) => (
          <div
            key={stat.label}
            className="rounded-xl border p-4 text-center"
            style={{ backgroundColor: "var(--bg-card)", borderColor: "var(--bg-main)" }}
          >
            <p className="text-3xl font-bold text-yellow-500">{stat.value}</p>
            <RatingStars rating={Math.round(parseFloat(stat.value))} size={4} />
            <p className="text-xs text-slate-400 mt-1">{stat.label}</p>
            <p className="text-[10px] text-slate-400">{stat.sub}</p>
          </div>
        ))}
      </div>

      {/* Filter */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        <Filter className="w-4 h-4 text-slate-400 flex-shrink-0" />
        {[0, 5, 4, 3, 2, 1].map((r) => (
          <button
            key={r}
            onClick={() => setFilterRating(r)}
            className={`px-3 py-1.5 rounded-full text-xs font-medium border whitespace-nowrap transition ${
              filterRating === r
                ? "bg-blue-600 text-white border-blue-600"
                : "hover:bg-slate-100 dark:hover:bg-slate-700"
            }`}
            style={filterRating !== r ? { borderColor: "var(--bg-main)" } : {}}
          >
            {r === 0 ? "All" : `${r} ★`}
          </button>
        ))}
      </div>

      {/* Review Cards */}
      <div className="space-y-4">
        {filteredReviews.map((review) => {
          const mechanic = mechanics.find((m) => m.id === review.mechanicId);
          return (
            <div
              key={review.id}
              className="rounded-xl border p-4 sm:p-5"
              style={{ backgroundColor: "var(--bg-card)", borderColor: "var(--bg-main)" }}
            >
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center text-white text-sm font-bold flex-shrink-0">
                  RK
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1">
                    <div>
                      <p className="font-semibold text-sm">Rajesh Kumar</p>
                      <p className="text-xs text-slate-400">
                        for {mechanic?.name || "Mechanic"} • {review.createdAt ? new Date(review.createdAt).toLocaleDateString("en-IN") : "Recent"}
                      </p>
                    </div>
                    <RatingStars rating={review.rating} size={4} />
                  </div>
                  {review.comment && (
                    <p className="text-sm text-slate-500 dark:text-slate-300 mt-2 leading-relaxed">
                      {review.comment}
                    </p>
                  )}
                  <div className="flex items-center gap-4 mt-3">
                    {review.serviceQuality && (
                      <span className="text-xs text-slate-400">
                        Service Quality: <span className="font-semibold text-yellow-500">{review.serviceQuality}/5</span>
                      </span>
                    )}
                    {review.responseTime && (
                      <span className="text-xs text-slate-400">
                        Response Time: <span className="font-semibold text-yellow-500">{review.responseTime}/5</span>
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-3 mt-3">
                    <button className="flex items-center gap-1 text-xs text-slate-400 hover:text-blue-500 transition">
                      <ThumbsUp className="w-3.5 h-3.5" /> Helpful
                    </button>
                    <button className="flex items-center gap-1 text-xs text-slate-400 hover:text-blue-500 transition">
                      <MessageSquare className="w-3.5 h-3.5" /> Reply
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
        {filteredReviews.length === 0 && (
          <div className="text-center py-10 text-slate-400">
            <Star className="w-12 h-12 mx-auto mb-2 opacity-30" />
            <p className="text-sm">No reviews found</p>
          </div>
        )}
      </div>

      {/* Write Review Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setShowForm(false)} />
          <div
            className="relative w-full sm:max-w-md rounded-t-2xl sm:rounded-2xl p-5 sm:p-6"
            style={{ backgroundColor: "var(--bg-card)" }}
          >
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-lg font-bold">{t.writeReview}</h3>
              <button onClick={() => setShowForm(false)} className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-xs font-medium text-slate-500 mb-2 block">Select Mechanic</label>
                <select
                  value={newReview.mechanicId}
                  onChange={(e) => setNewReview({ ...newReview, mechanicId: parseInt(e.target.value) })}
                  className="w-full border rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-blue-500"
                  style={{ borderColor: "var(--bg-main)", backgroundColor: "var(--bg-main)" }}
                >
                  <option value={0}>Choose mechanic...</option>
                  {mechanics.map((m) => (
                    <option key={m.id} value={m.id}>{m.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-500 mb-2 block">{t.overallRating}</label>
                <RatingStars rating={newReview.rating} size={6} interactive onChange={(r) => setNewReview({ ...newReview, rating: r })} />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-medium text-slate-500 mb-2 block">{t.serviceQuality}</label>
                  <RatingStars rating={newReview.serviceQuality} size={4} interactive onChange={(r) => setNewReview({ ...newReview, serviceQuality: r })} />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-500 mb-2 block">{t.responseTime}</label>
                  <RatingStars rating={newReview.responseTime} size={4} interactive onChange={(r) => setNewReview({ ...newReview, responseTime: r })} />
                </div>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-500 mb-2 block">Comment</label>
                <textarea
                  rows={3}
                  placeholder="Share your experience..."
                  value={newReview.comment}
                  onChange={(e) => setNewReview({ ...newReview, comment: e.target.value })}
                  className="w-full border rounded-xl px-3 py-2.5 text-sm outline-none resize-none focus:ring-2 focus:ring-blue-500"
                  style={{ borderColor: "var(--bg-main)", backgroundColor: "var(--bg-main)" }}
                />
              </div>
            </div>

            <button
              onClick={handleSubmit}
              disabled={!newReview.mechanicId || !newReview.rating}
              className="w-full mt-5 bg-blue-600 text-white py-2.5 rounded-xl text-sm font-semibold hover:bg-blue-700 transition disabled:opacity-50 flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4" />
              Submit Review
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
