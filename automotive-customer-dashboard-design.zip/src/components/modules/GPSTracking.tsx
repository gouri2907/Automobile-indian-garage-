"use client";

import { useStore, translations } from "@/store/useStore";
import { useState, useEffect } from "react";
import {
  MapPin, Navigation, Clock, CheckCircle2, Circle, Timer, Phone, MessageSquare,
  Car, Wrench, ChevronRight
} from "lucide-react";

interface ServiceRequest {
  id: number;
  serviceType: string;
  status: string;
  vehicleId: number;
  mechanicId: number | null;
  mechanicLatitude: string | null;
  mechanicLongitude: string | null;
}

interface Mechanic {
  id: number;
  name: string;
  phone: string;
  avatarUrl: string | null;
  specialization: string;
}

interface Vehicle {
  id: number;
  brand: string;
  model: string;
  registrationNumber: string;
}

interface Props {
  services: ServiceRequest[];
  mechanics: Mechanic[];
  vehicles: Vehicle[];
}

export default function GPSTracking({ services, mechanics, vehicles }: Props) {
  const { language } = useStore();
  const t = translations[language];
  const [selectedService, setSelectedService] = useState<ServiceRequest | null>(null);
  const [mechanicProgress, setMechanicProgress] = useState(65);

  const activeServices = services.filter((s) => s.status === "in_progress");

  useEffect(() => {
    if (activeServices.length > 0 && !selectedService) {
      setSelectedService(activeServices[0]);
    }
  }, [activeServices, selectedService]);

  // Simulate mechanic movement
  useEffect(() => {
    const interval = setInterval(() => {
      setMechanicProgress((p) => Math.min(p + Math.random() * 2, 100));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const currentMechanic = selectedService
    ? mechanics.find((m) => m.id === selectedService.mechanicId)
    : null;

  const currentVehicle = selectedService
    ? vehicles.find((v) => v.id === selectedService.vehicleId)
    : null;

  const timelineSteps = [
    { label: "Service Requested", time: "10:00 AM", status: "completed" },
    { label: "Mechanic Assigned", time: "10:05 AM", status: "completed" },
    { label: "Mechanic En Route", time: "10:08 AM", status: "completed" },
    { label: "Arrived at Location", time: "10:22 AM", status: "current" },
    { label: "Service In Progress", time: "~10:30 AM", status: "pending" },
    { label: "Service Completed", time: "~11:30 AM", status: "pending" },
  ];

  return (
    <div className="space-y-5 animate-slide-up">
      {/* Header */}
      <div>
        <h2 className="text-xl sm:text-2xl font-bold flex items-center gap-2">
          <MapPin className="w-6 h-6 text-blue-500" />
          {t.gpsTracking}
        </h2>
        <p className="text-sm text-slate-400 mt-0.5">Track your service in real-time</p>
      </div>

      {/* Service Selector */}
      {activeServices.length > 1 && (
        <div className="flex gap-2 overflow-x-auto pb-1">
          {activeServices.map((s) => {
            const v = vehicles.find((veh) => veh.id === s.vehicleId);
            return (
              <button
                key={s.id}
                onClick={() => setSelectedService(s)}
                className={`px-4 py-2 rounded-xl text-xs font-medium border whitespace-nowrap transition ${
                  selectedService?.id === s.id
                    ? "bg-blue-600 text-white border-blue-600"
                    : "hover:bg-slate-100 dark:hover:bg-slate-700"
                }`}
                style={selectedService?.id !== s.id ? { borderColor: "var(--bg-main)" } : {}}
              >
                {v?.brand} {v?.model} - {s.serviceType}
              </button>
            );
          })}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Map Area */}
        <div className="lg:col-span-2">
          <div
            className="rounded-2xl border overflow-hidden relative"
            style={{ backgroundColor: "var(--bg-card)", borderColor: "var(--bg-main)" }}
          >
            {/* Simulated Map */}
            <div className="h-[350px] sm:h-[450px] bg-gradient-to-br from-blue-50 via-green-50 to-blue-50 dark:from-slate-800 dark:via-slate-700 dark:to-slate-800 relative overflow-hidden">
              {/* Road grid */}
              <svg className="absolute inset-0 w-full h-full opacity-20" xmlns="http://www.w3.org/2000/svg">
                <defs>
                  <pattern id="grid" width="60" height="60" patternUnits="userSpaceOnUse">
                    <path d="M 60 0 L 0 0 0 60" fill="none" stroke="currentColor" strokeWidth="0.5" className="text-slate-400" />
                  </pattern>
                </defs>
                <rect width="100%" height="100%" fill="url(#grid)" />
              </svg>

              {/* Roads */}
              <svg className="absolute inset-0 w-full h-full" xmlns="http://www.w3.org/2000/svg">
                <line x1="0" y1="50%" x2="100%" y2="50%" stroke="#94a3b8" strokeWidth="3" strokeDasharray="8,4" opacity="0.4" />
                <line x1="50%" y1="0" x2="50%" y2="100%" stroke="#94a3b8" strokeWidth="3" strokeDasharray="8,4" opacity="0.4" />
                <line x1="20%" y1="0" x2="80%" y2="100%" stroke="#94a3b8" strokeWidth="2" strokeDasharray="6,4" opacity="0.3" />
                {/* Route line */}
                <line x1="30%" y1="65%" x2="65%" y2="40%" stroke="#3b82f6" strokeWidth="3" strokeDasharray="8,4" opacity="0.8" />
              </svg>

              {/* Customer Location */}
              <div className="absolute" style={{ left: "28%", top: "62%" }}>
                <div className="relative">
                  <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center shadow-lg shadow-blue-500/40 animate-pulse">
                    <Car className="w-6 h-6 text-white" />
                  </div>
                  <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 bg-blue-600 text-white text-[10px] px-2 py-0.5 rounded-full whitespace-nowrap font-medium">
                    Your Location
                  </div>
                </div>
              </div>

              {/* Mechanic Location */}
              <div className="absolute" style={{ left: `${30 + mechanicProgress * 0.35}%`, top: `${65 - mechanicProgress * 0.25}%` }}>
                <div className="relative">
                  <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center shadow-lg shadow-green-500/40 animate-bounce-gentle">
                    <Wrench className="w-5 h-5 text-white" />
                  </div>
                  <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 bg-green-600 text-white text-[10px] px-2 py-0.5 rounded-full whitespace-nowrap font-medium">
                    {currentMechanic?.name || "Mechanic"}
                  </div>
                </div>
              </div>

              {/* Destination */}
              <div className="absolute" style={{ left: "63%", top: "38%" }}>
                <div className="relative">
                  <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center shadow-lg shadow-orange-500/30">
                    <MapPin className="w-4 h-4 text-white" />
                  </div>
                  <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 bg-orange-600 text-white text-[10px] px-2 py-0.5 rounded-full whitespace-nowrap font-medium">
                    Garage
                  </div>
                </div>
              </div>

              {/* ETA Banner */}
              <div className="absolute top-4 left-4 right-4">
                <div className="bg-white/90 dark:bg-slate-800/90 backdrop-blur-sm rounded-xl p-3 shadow-lg flex items-center gap-3">
                  <div className="w-10 h-10 bg-green-100 dark:bg-green-900/40 rounded-lg flex items-center justify-center">
                    <Timer className="w-5 h-5 text-green-600" />
                  </div>
                  <div className="flex-1">
                    <p className="text-xs text-slate-400">Estimated Arrival</p>
                    <p className="font-bold text-base">8 minutes</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-slate-400">Distance</p>
                    <p className="font-semibold text-sm">2.3 km</p>
                  </div>
                </div>
              </div>

              {/* Legend */}
              <div className="absolute bottom-4 left-4 bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm rounded-lg px-3 py-2 text-[10px] space-y-1">
                <div className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 bg-blue-500 rounded-full" /> You</div>
                <div className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 bg-green-500 rounded-full" /> Mechanic</div>
                <div className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 bg-orange-500 rounded-full" /> Garage</div>
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar Info */}
        <div className="space-y-4">
          {/* Mechanic Card */}
          {currentMechanic && (
            <div
              className="rounded-2xl border p-4"
              style={{ backgroundColor: "var(--bg-card)", borderColor: "var(--bg-main)" }}
            >
              <div className="flex items-center gap-3 mb-3">
                <div className="relative">
                  <div className="w-12 h-12 rounded-xl bg-slate-200 dark:bg-slate-600 overflow-hidden">
                    {currentMechanic.avatarUrl ? (
                      <img src={currentMechanic.avatarUrl} alt={currentMechanic.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center font-bold text-slate-400">
                        {currentMechanic.name.charAt(0)}
                      </div>
                    )}
                  </div>
                  <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-green-500 border-2 rounded-full" style={{ borderColor: "var(--bg-card)" }} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-sm truncate">{currentMechanic.name}</p>
                  <p className="text-xs text-slate-400 truncate">{currentMechanic.specialization}</p>
                </div>
              </div>
              <div className="flex gap-2">
                <button className="flex-1 flex items-center justify-center gap-1.5 border rounded-lg py-2 text-xs font-medium text-green-600 hover:bg-green-50 dark:hover:bg-green-900/30 transition" style={{ borderColor: "var(--bg-main)" }}>
                  <Phone className="w-3.5 h-3.5" /> Call
                </button>
                <button className="flex-1 flex items-center justify-center gap-1.5 border rounded-lg py-2 text-xs font-medium text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/30 transition" style={{ borderColor: "var(--bg-main)" }}>
                  <MessageSquare className="w-3.5 h-3.5" /> Chat
                </button>
              </div>
            </div>
          )}

          {/* Service Info */}
          {currentVehicle && (
            <div
              className="rounded-2xl border p-4"
              style={{ backgroundColor: "var(--bg-card)", borderColor: "var(--bg-main)" }}
            >
              <h4 className="text-xs font-semibold text-slate-400 mb-2 uppercase tracking-wide">Service Details</h4>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Vehicle</span>
                  <span className="font-medium">{currentVehicle.brand} {currentVehicle.model}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Service</span>
                  <span className="font-medium">{selectedService?.serviceType}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Status</span>
                  <span className="text-blue-500 font-medium">In Progress</span>
                </div>
              </div>
            </div>
          )}

          {/* Timeline */}
          <div
            className="rounded-2xl border p-4"
            style={{ backgroundColor: "var(--bg-card)", borderColor: "var(--bg-main)" }}
          >
            <h4 className="text-xs font-semibold text-slate-400 mb-3 uppercase tracking-wide">Live Timeline</h4>
            <div className="space-y-0">
              {timelineSteps.map((step, i) => (
                <div key={i} className="flex gap-3 relative">
                  {/* Line */}
                  {i < timelineSteps.length - 1 && (
                    <div
                      className={`absolute left-[9px] top-5 w-0.5 h-full ${
                        step.status === "completed" ? "bg-green-500" : "bg-slate-200 dark:bg-slate-700"
                      }`}
                    />
                  )}
                  {/* Dot */}
                  <div className="flex-shrink-0 mt-0.5 z-10">
                    {step.status === "completed" ? (
                      <CheckCircle2 className="w-5 h-5 text-green-500" />
                    ) : step.status === "current" ? (
                      <div className="w-5 h-5 rounded-full border-2 border-blue-500 bg-blue-100 dark:bg-blue-900/50 flex items-center justify-center">
                        <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" />
                      </div>
                    ) : (
                      <Circle className="w-5 h-5 text-slate-300 dark:text-slate-600" />
                    )}
                  </div>
                  {/* Content */}
                  <div className="pb-4">
                    <p className={`text-sm font-medium ${step.status === "pending" ? "text-slate-400" : ""}`}>
                      {step.label}
                    </p>
                    <p className="text-[11px] text-slate-400">{step.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {activeServices.length === 0 && (
        <div
          className="rounded-2xl border p-10 text-center"
          style={{ backgroundColor: "var(--bg-card)", borderColor: "var(--bg-main)" }}
        >
          <Navigation className="w-16 h-16 mx-auto mb-3 text-slate-300 dark:text-slate-600" />
          <h3 className="font-semibold text-lg mb-1">No Active Tracking</h3>
          <p className="text-sm text-slate-400 mb-4">Book a service to start tracking your mechanic in real-time</p>
          <button className="bg-blue-600 text-white px-6 py-2.5 rounded-xl text-sm font-semibold hover:bg-blue-700 transition">
            {t.bookService}
          </button>
        </div>
      )}
    </div>
  );
}
