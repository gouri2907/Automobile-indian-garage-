"use client";

import { useStore, translations } from "@/store/useStore";
import { useState } from "react";
import {
  Car, Plus, Edit3, Trash2, Fuel, Gauge, Calendar, Shield, X, ChevronDown,
  ImageIcon
} from "lucide-react";

interface Vehicle {
  id: number;
  registrationNumber: string;
  vehicleType: string;
  brand: string;
  model: string;
  fuelType: string;
  manufacturingYear: number;
  color: string | null;
  imageUrl: string | null;
  insuranceProvider: string | null;
  insuranceExpiry: string | null;
  serviceDueDate: string | null;
  healthScore: number | null;
  odometerReading: number | null;
}

interface Props {
  vehicles: Vehicle[];
  onRefresh: () => void;
}

export default function MyVehicles({ vehicles, onRefresh }: Props) {
  const { language } = useStore();
  const t = translations[language];
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    registrationNumber: "",
    vehicleType: "Sedan",
    brand: "",
    model: "",
    fuelType: "Petrol",
    manufacturingYear: 2024,
    color: "",
    insuranceProvider: "",
    insuranceExpiry: "",
    serviceDueDate: "",
  });

  const handleSubmit = async () => {
    if (!formData.registrationNumber || !formData.brand || !formData.model) return;
    try {
      await fetch("/api/vehicles", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });
      setShowForm(false);
      setFormData({
        registrationNumber: "", vehicleType: "Sedan", brand: "", model: "",
        fuelType: "Petrol", manufacturingYear: 2024, color: "",
        insuranceProvider: "", insuranceExpiry: "", serviceDueDate: "",
      });
      onRefresh();
    } catch (err) {
      console.error(err);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Are you sure you want to remove this vehicle?")) return;
    try {
      await fetch(`/api/vehicles?id=${id}`, { method: "DELETE" });
      onRefresh();
    } catch (err) {
      console.error(err);
    }
  };

  const getHealthColor = (score: number) => {
    if (score >= 80) return "text-green-500";
    if (score >= 60) return "text-yellow-500";
    return "text-red-500";
  };

  const getHealthBg = (score: number) => {
    if (score >= 80) return "bg-green-500";
    if (score >= 60) return "bg-yellow-500";
    return "bg-red-500";
  };

  return (
    <div className="space-y-5 animate-slide-up">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold flex items-center gap-2">
            <Car className="w-6 h-6 text-blue-500" />
            {t.myVehicles}
          </h2>
          <p className="text-sm text-slate-400 mt-0.5">{vehicles.length} vehicle{vehicles.length !== 1 ? "s" : ""} registered</p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="bg-blue-600 text-white px-4 py-2.5 rounded-xl text-sm font-semibold hover:bg-blue-700 transition flex items-center gap-2 w-fit"
        >
          <Plus className="w-4 h-4" />
          {t.addVehicle}
        </button>
      </div>

      {/* Vehicle Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {vehicles.map((v) => (
          <div
            key={v.id}
            className="rounded-2xl border overflow-hidden hover:shadow-lg transition-shadow"
            style={{ backgroundColor: "var(--bg-card)", borderColor: "var(--bg-main)" }}
          >
            {/* Vehicle Image */}
            <div className="h-44 sm:h-48 bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-700 dark:to-slate-800 relative overflow-hidden">
              {v.imageUrl ? (
                <img src={v.imageUrl} alt={`${v.brand} ${v.model}`} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Car className="w-16 h-16 text-slate-300 dark:text-slate-600" />
                </div>
              )}
              <div className="absolute top-3 left-3 bg-white/90 dark:bg-slate-800/90 backdrop-blur-sm rounded-lg px-2.5 py-1 text-xs font-bold">
                {v.vehicleType}
              </div>
              <div className="absolute top-3 right-3 flex gap-1.5">
                <button className="w-8 h-8 bg-white/90 dark:bg-slate-800/90 backdrop-blur-sm rounded-lg flex items-center justify-center hover:bg-white transition">
                  <Edit3 className="w-3.5 h-3.5 text-blue-600" />
                </button>
                <button
                  onClick={() => handleDelete(v.id)}
                  className="w-8 h-8 bg-white/90 dark:bg-slate-800/90 backdrop-blur-sm rounded-lg flex items-center justify-center hover:bg-white transition"
                >
                  <Trash2 className="w-3.5 h-3.5 text-red-500" />
                </button>
              </div>
            </div>

            <div className="p-4">
              {/* Name & Reg */}
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-bold text-lg">{v.brand} {v.model}</h3>
                  <p className="text-sm text-slate-400 font-mono">{v.registrationNumber}</p>
                </div>
                <div className={`text-right`}>
                  <p className={`text-2xl font-bold ${getHealthColor(v.healthScore || 0)}`}>
                    {v.healthScore}%
                  </p>
                  <p className="text-[10px] text-slate-400">Health</p>
                </div>
              </div>

              {/* Health Bar */}
              <div className="mt-3 h-2 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all ${getHealthBg(v.healthScore || 0)}`}
                  style={{ width: `${v.healthScore || 0}%` }}
                />
              </div>

              {/* Details Grid */}
              <div className="grid grid-cols-2 gap-3 mt-4">
                <div className="flex items-center gap-2 text-sm">
                  <Fuel className="w-4 h-4 text-slate-400 flex-shrink-0" />
                  <span className="text-slate-500 truncate">{v.fuelType}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Gauge className="w-4 h-4 text-slate-400 flex-shrink-0" />
                  <span className="text-slate-500 truncate">{v.odometerReading?.toLocaleString("en-IN")} km</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="w-4 h-4 text-slate-400 flex-shrink-0" />
                  <span className="text-slate-500 truncate">{v.manufacturingYear}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Shield className="w-4 h-4 text-slate-400 flex-shrink-0" />
                  <span className="text-slate-500 truncate">{v.insuranceProvider || "N/A"}</span>
                </div>
              </div>

              {/* Service Due */}
              {v.serviceDueDate && (
                <div className="mt-3 p-2.5 rounded-lg bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-800/50 flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-orange-500 flex-shrink-0" />
                  <span className="text-xs text-orange-700 dark:text-orange-300 font-medium">
                    Service Due: {new Date(v.serviceDueDate).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
                  </span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Add Vehicle Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setShowForm(false)} />
          <div
            className="relative w-full sm:max-w-lg max-h-[90vh] overflow-y-auto rounded-t-2xl sm:rounded-2xl p-5 sm:p-6"
            style={{ backgroundColor: "var(--bg-card)" }}
          >
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-lg font-bold flex items-center gap-2">
                <Plus className="w-5 h-5 text-blue-500" />
                {t.addVehicle}
              </h3>
              <button onClick={() => setShowForm(false)} className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Upload Image */}
            <div className="mb-4">
              <div className="h-32 border-2 border-dashed rounded-xl flex flex-col items-center justify-center text-slate-400 hover:text-blue-500 hover:border-blue-400 transition cursor-pointer" style={{ borderColor: "var(--bg-main)" }}>
                <ImageIcon className="w-8 h-8 mb-1" />
                <span className="text-xs">Upload Vehicle Image</span>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-medium text-slate-500 mb-1 block">Registration Number *</label>
                <input
                  type="text"
                  placeholder="MH 02 XX 1234"
                  value={formData.registrationNumber}
                  onChange={(e) => setFormData({ ...formData, registrationNumber: e.target.value })}
                  className="w-full border rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-blue-500"
                  style={{ borderColor: "var(--bg-main)", backgroundColor: "var(--bg-main)" }}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-500 mb-1 block">Vehicle Type</label>
                  <div className="relative">
                    <select
                      value={formData.vehicleType}
                      onChange={(e) => setFormData({ ...formData, vehicleType: e.target.value })}
                      className="w-full border rounded-xl px-3 py-2.5 text-sm outline-none appearance-none focus:ring-2 focus:ring-blue-500"
                      style={{ borderColor: "var(--bg-main)", backgroundColor: "var(--bg-main)" }}
                    >
                      <option>Sedan</option>
                      <option>SUV</option>
                      <option>Hatchback</option>
                      <option>Bike</option>
                      <option>Auto Rickshaw</option>
                      <option>Truck</option>
                      <option>Bus</option>
                    </select>
                    <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                  </div>
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-500 mb-1 block">Fuel Type</label>
                  <div className="relative">
                    <select
                      value={formData.fuelType}
                      onChange={(e) => setFormData({ ...formData, fuelType: e.target.value })}
                      className="w-full border rounded-xl px-3 py-2.5 text-sm outline-none appearance-none focus:ring-2 focus:ring-blue-500"
                      style={{ borderColor: "var(--bg-main)", backgroundColor: "var(--bg-main)" }}
                    >
                      <option>Petrol</option>
                      <option>Diesel</option>
                      <option>CNG</option>
                      <option>Electric</option>
                      <option>Hybrid</option>
                    </select>
                    <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-500 mb-1 block">Brand *</label>
                  <input
                    type="text"
                    placeholder="Maruti Suzuki"
                    value={formData.brand}
                    onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                    className="w-full border rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-blue-500"
                    style={{ borderColor: "var(--bg-main)", backgroundColor: "var(--bg-main)" }}
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-500 mb-1 block">Model *</label>
                  <input
                    type="text"
                    placeholder="Swift"
                    value={formData.model}
                    onChange={(e) => setFormData({ ...formData, model: e.target.value })}
                    className="w-full border rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-blue-500"
                    style={{ borderColor: "var(--bg-main)", backgroundColor: "var(--bg-main)" }}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-500 mb-1 block">Manufacturing Year</label>
                  <input
                    type="number"
                    min={2000}
                    max={2025}
                    value={formData.manufacturingYear}
                    onChange={(e) => setFormData({ ...formData, manufacturingYear: parseInt(e.target.value) || 2024 })}
                    className="w-full border rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-blue-500"
                    style={{ borderColor: "var(--bg-main)", backgroundColor: "var(--bg-main)" }}
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-500 mb-1 block">Color</label>
                  <input
                    type="text"
                    placeholder="White"
                    value={formData.color}
                    onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                    className="w-full border rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-blue-500"
                    style={{ borderColor: "var(--bg-main)", backgroundColor: "var(--bg-main)" }}
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-500 mb-1 block">Insurance Provider</label>
                <input
                  type="text"
                  placeholder="ICICI Lombard"
                  value={formData.insuranceProvider}
                  onChange={(e) => setFormData({ ...formData, insuranceProvider: e.target.value })}
                  className="w-full border rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-blue-500"
                  style={{ borderColor: "var(--bg-main)", backgroundColor: "var(--bg-main)" }}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-500 mb-1 block">Insurance Expiry</label>
                  <input
                    type="date"
                    value={formData.insuranceExpiry}
                    onChange={(e) => setFormData({ ...formData, insuranceExpiry: e.target.value })}
                    className="w-full border rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-blue-500"
                    style={{ borderColor: "var(--bg-main)", backgroundColor: "var(--bg-main)" }}
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-500 mb-1 block">Service Due Date</label>
                  <input
                    type="date"
                    value={formData.serviceDueDate}
                    onChange={(e) => setFormData({ ...formData, serviceDueDate: e.target.value })}
                    className="w-full border rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-blue-500"
                    style={{ borderColor: "var(--bg-main)", backgroundColor: "var(--bg-main)" }}
                  />
                </div>
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setShowForm(false)}
                className="flex-1 border rounded-xl py-2.5 text-sm font-medium hover:bg-slate-50 dark:hover:bg-slate-700 transition"
                style={{ borderColor: "var(--bg-main)" }}
              >
                Cancel
              </button>
              <button
                onClick={handleSubmit}
                className="flex-1 bg-blue-600 text-white rounded-xl py-2.5 text-sm font-semibold hover:bg-blue-700 transition"
              >
                {t.addVehicle}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
