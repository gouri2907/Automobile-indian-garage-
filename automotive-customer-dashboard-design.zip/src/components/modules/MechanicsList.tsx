"use client";

import { useStore, translations } from "@/store/useStore";
import { useState } from "react";
import { Wrench, MapPin, Star, Clock, IndianRupee, Phone, Filter, LayoutGrid, List, Timer } from "lucide-react";

interface Mechanic {
  id: number;
  name: string;
  phone: string;
  avatarUrl: string | null;
  specialization: string;
  experience: number;
  rating: string | null;
  totalReviews: number | null;
  isOnline: boolean | null;
  distanceKm: string | null;
  estimatedArrival: string | null;
  serviceChargePerHour: number | null;
}

interface Props {
  mechanics: Mechanic[];
}

export default function MechanicsList({ mechanics }: Props) {
  const { language, setActiveNav } = useStore();
  const t = translations[language];
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [filter, setFilter] = useState<"all" | "online" | "offline">("all");

  const filtered = mechanics.filter((m) => {
    if (filter === "online") return m.isOnline;
    if (filter === "offline") return !m.isOnline;
    return true;
  });

  return (
    <div className="space-y-5 animate-slide-up">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold flex items-center gap-2">
            <Wrench className="w-6 h-6 text-blue-500" />
            {t.mechanics}
          </h2>
          <p className="text-sm text-slate-400 mt-0.5">{mechanics.filter((m) => m.isOnline).length} online nearby</p>
        </div>
        <div className="flex items-center gap-2">
          {/* Filter */}
          <div className="flex rounded-lg border overflow-hidden text-xs" style={{ borderColor: "var(--bg-main)" }}>
            {(["all", "online", "offline"] as const).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-3 py-1.5 capitalize font-medium transition ${
                  filter === f
                    ? "bg-blue-600 text-white"
                    : "hover:bg-slate-100 dark:hover:bg-slate-700"
                }`}
              >
                {f}
              </button>
            ))}
          </div>
          {/* View toggle */}
          <div className="flex rounded-lg border overflow-hidden" style={{ borderColor: "var(--bg-main)" }}>
            <button
              onClick={() => setViewMode("grid")}
              className={`p-1.5 transition ${viewMode === "grid" ? "bg-blue-600 text-white" : "hover:bg-slate-100 dark:hover:bg-slate-700"}`}
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode("list")}
              className={`p-1.5 transition ${viewMode === "list" ? "bg-blue-600 text-white" : "hover:bg-slate-100 dark:hover:bg-slate-700"}`}
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Grid View */}
      {viewMode === "grid" ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map((m) => (
            <div
              key={m.id}
              className="rounded-2xl border p-5 hover:shadow-lg transition-shadow"
              style={{ backgroundColor: "var(--bg-card)", borderColor: "var(--bg-main)" }}
            >
              {/* Avatar & Status */}
              <div className="flex items-start gap-3 mb-4">
                <div className="relative flex-shrink-0">
                  <div className="w-14 h-14 rounded-xl bg-slate-200 dark:bg-slate-600 overflow-hidden">
                    {m.avatarUrl ? (
                      <img src={m.avatarUrl} alt={m.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-lg font-bold text-slate-400">
                        {m.name.charAt(0)}
                      </div>
                    )}
                  </div>
                  <span className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 ${m.isOnline ? "bg-green-500" : "bg-slate-400"}`} style={{ borderColor: "var(--bg-card)" }} />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-base truncate">{m.name}</h3>
                  <p className="text-xs text-slate-400 truncate">{m.specialization}</p>
                  <div className="flex items-center gap-1 mt-1">
                    <Star className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" />
                    <span className="text-sm font-semibold">{m.rating}</span>
                    <span className="text-xs text-slate-400">({m.totalReviews})</span>
                  </div>
                </div>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 gap-2 mb-4">
                <div className="flex items-center gap-1.5 text-xs text-slate-500">
                  <Clock className="w-3.5 h-3.5 flex-shrink-0" />
                  {m.experience} yrs exp
                </div>
                <div className="flex items-center gap-1.5 text-xs text-slate-500">
                  <MapPin className="w-3.5 h-3.5 flex-shrink-0" />
                  {m.distanceKm} km away
                </div>
                <div className="flex items-center gap-1.5 text-xs text-green-500">
                  <Timer className="w-3.5 h-3.5 flex-shrink-0" />
                  {m.estimatedArrival}
                </div>
                <div className="flex items-center gap-1.5 text-xs text-slate-500">
                  <IndianRupee className="w-3.5 h-3.5 flex-shrink-0" />
                  ₹{m.serviceChargePerHour}/hr
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-2">
                <button
                  onClick={() => setActiveNav("booking")}
                  className={`flex-1 py-2.5 rounded-xl text-sm font-semibold transition flex items-center justify-center gap-1.5 ${
                    m.isOnline
                      ? "bg-blue-600 text-white hover:bg-blue-700"
                      : "bg-slate-100 text-slate-400 dark:bg-slate-700 cursor-not-allowed"
                  }`}
                  disabled={!m.isOnline}
                >
                  <Wrench className="w-3.5 h-3.5" />
                  {t.bookNow}
                </button>
                <button className="w-10 border rounded-xl flex items-center justify-center hover:bg-green-50 hover:border-green-300 dark:hover:bg-green-900/30 transition" style={{ borderColor: "var(--bg-main)" }}>
                  <Phone className="w-4 h-4 text-green-500" />
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* List View */
        <div className="space-y-3">
          {filtered.map((m) => (
            <div
              key={m.id}
              className="rounded-xl border p-4 flex flex-col sm:flex-row sm:items-center gap-3 hover:shadow-md transition-shadow"
              style={{ backgroundColor: "var(--bg-card)", borderColor: "var(--bg-main)" }}
            >
              <div className="flex items-center gap-3 flex-1 min-w-0">
                <div className="relative flex-shrink-0">
                  <div className="w-12 h-12 rounded-xl bg-slate-200 dark:bg-slate-600 overflow-hidden">
                    {m.avatarUrl ? (
                      <img src={m.avatarUrl} alt={m.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center font-bold text-slate-400">
                        {m.name.charAt(0)}
                      </div>
                    )}
                  </div>
                  <span className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 ${m.isOnline ? "bg-green-500" : "bg-slate-400"}`} style={{ borderColor: "var(--bg-card)" }} />
                </div>
                <div className="min-w-0">
                  <h3 className="font-semibold text-sm truncate">{m.name}</h3>
                  <p className="text-xs text-slate-400 truncate">{m.specialization}</p>
                </div>
              </div>
              <div className="flex items-center gap-4 flex-wrap sm:flex-nowrap">
                <div className="flex items-center gap-1">
                  <Star className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" />
                  <span className="text-sm font-semibold">{m.rating}</span>
                </div>
                <span className="text-xs text-slate-400">{m.distanceKm} km</span>
                <span className="text-xs text-green-500">{m.estimatedArrival}</span>
                <span className="text-xs font-medium">₹{m.serviceChargePerHour}/hr</span>
                <button
                  onClick={() => setActiveNav("booking")}
                  className="bg-blue-600 text-white px-4 py-2 rounded-lg text-xs font-semibold hover:bg-blue-700 transition"
                  disabled={!m.isOnline}
                >
                  {t.bookNow}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
