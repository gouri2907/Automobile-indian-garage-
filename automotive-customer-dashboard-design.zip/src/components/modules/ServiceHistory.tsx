"use client";

import { useStore, translations } from "@/store/useStore";
import {
  ClipboardList, Download, ChevronDown, CheckCircle2, Clock, Wrench,
  IndianRupee, Calendar, FileText
} from "lucide-react";
import { useState } from "react";

interface ServiceRequest {
  id: number;
  serviceType: string;
  description: string | null;
  status: string;
  scheduledDate: string | null;
  completedDate: string | null;
  estimatedCost: number | null;
  actualCost: number | null;
  partsReplaced: unknown;
  vehicleId: number;
  mechanicId: number | null;
}

interface Vehicle {
  id: number;
  brand: string;
  model: string;
  registrationNumber: string;
}

interface Mechanic {
  id: number;
  name: string;
  specialization: string;
}

interface Props {
  services: ServiceRequest[];
  vehicles: Vehicle[];
  mechanics: Mechanic[];
}

export default function ServiceHistory({ services, vehicles, mechanics }: Props) {
  const { language } = useStore();
  const t = translations[language];
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>("all");

  const filteredServices = filterStatus === "all"
    ? services
    : services.filter((s) => s.status === filterStatus);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "in_progress": return { label: "In Progress", style: "bg-blue-100 text-blue-700 dark:bg-blue-900/50 dark:text-blue-300" };
      case "pending": return { label: "Pending", style: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/50 dark:text-yellow-300" };
      case "completed": return { label: "Completed", style: "bg-green-100 text-green-700 dark:bg-green-900/50 dark:text-green-300" };
      default: return { label: status, style: "bg-slate-100 text-slate-700" };
    }
  };

  const parseParts = (parts: unknown): string[] => {
    if (!parts) return [];
    try {
      if (typeof parts === "string") return JSON.parse(parts);
      if (Array.isArray(parts)) return parts as string[];
      return [];
    } catch {
      return [];
    }
  };

  return (
    <div className="space-y-5 animate-slide-up">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold flex items-center gap-2">
            <ClipboardList className="w-6 h-6 text-blue-500" />
            {t.serviceHistory}
          </h2>
          <p className="text-sm text-slate-400 mt-0.5">{services.length} total services</p>
        </div>
      </div>

      {/* Filter */}
      <div className="flex gap-2 overflow-x-auto pb-1">
        {[
          { value: "all", label: "All" },
          { value: "completed", label: "Completed" },
          { value: "in_progress", label: "In Progress" },
          { value: "pending", label: "Pending" },
        ].map((f) => (
          <button
            key={f.value}
            onClick={() => setFilterStatus(f.value)}
            className={`px-4 py-1.5 rounded-full text-xs font-medium border whitespace-nowrap transition ${
              filterStatus === f.value
                ? "bg-blue-600 text-white border-blue-600"
                : "hover:bg-slate-100 dark:hover:bg-slate-700"
            }`}
            style={filterStatus !== f.value ? { borderColor: "var(--bg-main)" } : {}}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Service Cards */}
      <div className="space-y-3">
        {filteredServices.map((service) => {
          const vehicle = vehicles.find((v) => v.id === service.vehicleId);
          const mechanic = mechanics.find((m) => m.id === service.mechanicId);
          const badge = getStatusBadge(service.status);
          const isExpanded = expandedId === service.id;
          const parts = parseParts(service.partsReplaced);

          return (
            <div
              key={service.id}
              className="rounded-xl border overflow-hidden transition-shadow hover:shadow-md"
              style={{ backgroundColor: "var(--bg-card)", borderColor: "var(--bg-main)" }}
            >
              {/* Main Row */}
              <button
                onClick={() => setExpandedId(isExpanded ? null : service.id)}
                className="w-full p-4 flex items-center gap-3 text-left"
              >
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
                  service.status === "completed" ? "bg-green-50 dark:bg-green-900/30" : "bg-blue-50 dark:bg-blue-900/30"
                }`}>
                  {service.status === "completed" ? (
                    <CheckCircle2 className="w-5 h-5 text-green-500" />
                  ) : (
                    <Wrench className="w-5 h-5 text-blue-500" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="font-semibold text-sm">{service.serviceType}</p>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${badge.style}`}>
                      {badge.label}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5 truncate">
                    {vehicle?.brand} {vehicle?.model} • {mechanic?.name || "Pending"}
                  </p>
                </div>
                <div className="text-right flex-shrink-0">
                  {(service.actualCost || service.estimatedCost) && (
                    <p className="text-sm font-bold text-green-600">
                      ₹{(service.actualCost || service.estimatedCost || 0).toLocaleString("en-IN")}
                    </p>
                  )}
                  <p className="text-[10px] text-slate-400">
                    {service.scheduledDate
                      ? new Date(service.scheduledDate).toLocaleDateString("en-IN", { day: "numeric", month: "short" })
                      : "N/A"
                    }
                  </p>
                </div>
                <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform flex-shrink-0 ${isExpanded ? "rotate-180" : ""}`} />
              </button>

              {/* Expanded Details */}
              {isExpanded && (
                <div className="px-4 pb-4 border-t animate-fade-in" style={{ borderColor: "var(--bg-main)" }}>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
                    <div className="space-y-2.5">
                      <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wide">Service Details</h4>
                      <div className="flex items-center gap-2 text-sm">
                        <Wrench className="w-4 h-4 text-slate-400" />
                        <span className="text-slate-500">Type:</span>
                        <span className="font-medium">{service.serviceType}</span>
                      </div>
                      {service.description && (
                        <div className="flex items-start gap-2 text-sm">
                          <FileText className="w-4 h-4 text-slate-400 mt-0.5" />
                          <span className="text-slate-500">{service.description}</span>
                        </div>
                      )}
                      <div className="flex items-center gap-2 text-sm">
                        <Calendar className="w-4 h-4 text-slate-400" />
                        <span className="text-slate-500">Scheduled:</span>
                        <span className="font-medium">
                          {service.scheduledDate
                            ? new Date(service.scheduledDate).toLocaleString("en-IN")
                            : "N/A"
                          }
                        </span>
                      </div>
                      {service.completedDate && (
                        <div className="flex items-center gap-2 text-sm">
                          <CheckCircle2 className="w-4 h-4 text-green-500" />
                          <span className="text-slate-500">Completed:</span>
                          <span className="font-medium">
                            {new Date(service.completedDate).toLocaleString("en-IN")}
                          </span>
                        </div>
                      )}
                    </div>
                    <div className="space-y-2.5">
                      <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wide">Cost Breakdown</h4>
                      {service.estimatedCost && (
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-500">Estimated Cost</span>
                          <span>₹{service.estimatedCost.toLocaleString("en-IN")}</span>
                        </div>
                      )}
                      {service.actualCost && (
                        <div className="flex justify-between text-sm font-semibold">
                          <span>Final Cost</span>
                          <span className="text-green-600">₹{service.actualCost.toLocaleString("en-IN")}</span>
                        </div>
                      )}
                      {parts.length > 0 && (
                        <div>
                          <h5 className="text-xs font-semibold text-slate-400 mt-2 mb-1">Parts Replaced</h5>
                          <div className="flex flex-wrap gap-1.5">
                            {parts.map((part, i) => (
                              <span key={i} className="text-[11px] bg-slate-100 dark:bg-slate-700 px-2 py-0.5 rounded-full">
                                {part}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Actions */}
                  {service.status === "completed" && (
                    <div className="flex gap-2 mt-4 pt-3 border-t" style={{ borderColor: "var(--bg-main)" }}>
                      <button className="flex items-center gap-1.5 px-4 py-2 rounded-lg border text-xs font-medium hover:bg-slate-50 dark:hover:bg-slate-700 transition" style={{ borderColor: "var(--bg-main)" }}>
                        <Download className="w-3.5 h-3.5" /> Download Invoice
                      </button>
                      <button className="flex items-center gap-1.5 px-4 py-2 rounded-lg border text-xs font-medium hover:bg-slate-50 dark:hover:bg-slate-700 transition" style={{ borderColor: "var(--bg-main)" }}>
                        <FileText className="w-3.5 h-3.5" /> Service Report
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}

        {filteredServices.length === 0 && (
          <div className="text-center py-10 text-slate-400">
            <ClipboardList className="w-12 h-12 mx-auto mb-2 opacity-30" />
            <p className="text-sm">No services found</p>
          </div>
        )}
      </div>
    </div>
  );
}
