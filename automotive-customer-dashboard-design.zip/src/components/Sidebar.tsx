"use client";

import { useStore, translations } from "@/store/useStore";
import {
  Home, Car, Calendar, Wrench, Bot, MapPin, Star,
  ClipboardList, Bell, User, X, Shield, Phone
} from "lucide-react";

const navItems = [
  { id: "home", icon: Home, label: "home" },
  { id: "vehicles", icon: Car, label: "myVehicles" },
  { id: "booking", icon: Calendar, label: "bookService" },
  { id: "mechanics", icon: Wrench, label: "mechanics" },
  { id: "ai", icon: Bot, label: "aiAssistant" },
  { id: "gps", icon: MapPin, label: "gpsTracking" },
  { id: "reviews", icon: Star, label: "reviews" },
  { id: "history", icon: ClipboardList, label: "serviceHistory" },
  { id: "notifications", icon: Bell, label: "notifications" },
  { id: "profile", icon: User, label: "profile" },
];

export default function Sidebar() {
  const { activeNav, setActiveNav, sidebarOpen, setSidebarOpen, language } = useStore();
  const t = translations[language];

  return (
    <>
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <aside
        className={`fixed top-0 left-0 h-full z-50 w-[270px] transition-transform duration-300 flex flex-col
          lg:translate-x-0 ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}
        `}
        style={{ backgroundColor: "var(--sidebar-bg)" }}
      >
        {/* Logo */}
        <div className="flex items-center justify-between px-5 py-5 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-orange-500 flex items-center justify-center">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-white font-bold text-lg leading-tight">Automobile Indian Garage</h1>
              <p className="text-blue-300 text-xs">India • Customer</p>
            </div>
          </div>
          <button
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden text-white/60 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Nav Items */}
        <nav className="flex-1 overflow-y-auto py-4 px-3">
          <div className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeNav === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveNav(item.id);
                    setSidebarOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all
                    ${isActive
                      ? "bg-blue-600 text-white shadow-lg shadow-blue-600/30"
                      : "text-slate-300 hover:bg-white/10 hover:text-white"
                    }
                  `}
                >
                  <Icon className="w-[18px] h-[18px] flex-shrink-0" />
                  <span>{t[item.label] || item.label}</span>
                  {item.id === "notifications" && (
                    <span className="ml-auto bg-red-500 text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center">
                      3
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </nav>

        {/* Emergency Button */}
        <div className="p-4 border-t border-white/10">
          <button
            onClick={() => setActiveNav("home")}
            className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-red-600 to-red-500 text-white py-3 rounded-xl font-semibold text-sm hover:from-red-700 hover:to-red-600 transition-all shadow-lg shadow-red-600/30"
          >
            <Phone className="w-4 h-4" />
            <span>{t.emergency}</span>
          </button>
        </div>
      </aside>
    </>
  );
}
