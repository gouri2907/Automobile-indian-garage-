import { NextResponse } from "next/server";
import { db } from "@/db";
import { customers, vehicles, mechanics, serviceRequests, reviews, notifications } from "@/db/schema";
import { sql } from "drizzle-orm";

export async function POST() {
  try {
    // Check if data exists
    const existing = await db.select({ count: sql<number>`count(*)` }).from(customers);
    if (Number(existing[0].count) > 0) {
      return NextResponse.json({ message: "Already seeded" });
    }

    // Seed customer
    await db.insert(customers).values({
      name: "Rajesh Kumar",
      email: "rajesh.kumar@email.com",
      phone: "+91 98765 43210",
      avatarUrl: "/images/mechanic-avatar-1.jpg",
      address: "45, MG Road, Andheri West",
      city: "Mumbai",
      preferredLanguage: "en",
      darkMode: false,
    });

    // Seed vehicles
    await db.insert(vehicles).values([
      {
        customerId: 1,
        registrationNumber: "MH 02 AB 1234",
        vehicleType: "SUV",
        brand: "Mahindra",
        model: "XUV700",
        fuelType: "Diesel",
        manufacturingYear: 2023,
        color: "White",
        imageUrl: "/images/car-suv.jpg",
        insuranceProvider: "ICICI Lombard",
        insuranceExpiry: "2025-12-15",
        serviceDueDate: "2025-02-20",
        healthScore: 87,
        odometerReading: 25400,
      },
      {
        customerId: 1,
        registrationNumber: "MH 02 CD 5678",
        vehicleType: "Sedan",
        brand: "Maruti Suzuki",
        model: "Ciaz",
        fuelType: "Petrol",
        manufacturingYear: 2021,
        color: "Silver",
        imageUrl: "/images/car-sedan.jpg",
        insuranceProvider: "Bajaj Allianz",
        insuranceExpiry: "2025-08-30",
        serviceDueDate: "2025-01-15",
        healthScore: 72,
        odometerReading: 45200,
      },
    ]);

    // Seed mechanics
    await db.insert(mechanics).values([
      {
        name: "Suresh Patil",
        phone: "+91 98765 11111",
        avatarUrl: "/images/mechanic-avatar-1.jpg",
        specialization: "Engine Specialist, AC Repair",
        experience: 12,
        rating: "4.8",
        totalReviews: 234,
        isOnline: true,
        latitude: "19.0760",
        longitude: "72.8777",
        distanceKm: "2.3",
        estimatedArrival: "15 min",
        serviceChargePerHour: 600,
      },
      {
        name: "Amit Sharma",
        phone: "+91 98765 22222",
        avatarUrl: "/images/mechanic-avatar-1.jpg",
        specialization: "Electrical Systems, Battery",
        experience: 8,
        rating: "4.5",
        totalReviews: 156,
        isOnline: true,
        latitude: "19.0830",
        longitude: "72.8900",
        distanceKm: "3.7",
        estimatedArrival: "22 min",
        serviceChargePerHour: 500,
      },
      {
        name: "Vikram Singh",
        phone: "+91 98765 33333",
        avatarUrl: "/images/mechanic-avatar-1.jpg",
        specialization: "Brake & Suspension, Clutch",
        experience: 15,
        rating: "4.9",
        totalReviews: 312,
        isOnline: false,
        latitude: "19.0700",
        longitude: "72.8650",
        distanceKm: "5.1",
        estimatedArrival: "30 min",
        serviceChargePerHour: 750,
      },
      {
        name: "Ravi Deshmukh",
        phone: "+91 98765 44444",
        avatarUrl: "/images/mechanic-avatar-1.jpg",
        specialization: "Denting, Painting, Body Work",
        experience: 10,
        rating: "4.3",
        totalReviews: 89,
        isOnline: true,
        latitude: "19.0850",
        longitude: "72.8800",
        distanceKm: "1.8",
        estimatedArrival: "12 min",
        serviceChargePerHour: 550,
      },
      {
        name: "Manoj Kulkarni",
        phone: "+91 98765 55555",
        avatarUrl: "/images/mechanic-avatar-1.jpg",
        specialization: "Tyre, Wheel Alignment, Balancing",
        experience: 6,
        rating: "4.6",
        totalReviews: 143,
        isOnline: true,
        latitude: "19.0720",
        longitude: "72.8750",
        distanceKm: "4.2",
        estimatedArrival: "25 min",
        serviceChargePerHour: 450,
      },
    ]);

    // Seed service requests
    await db.insert(serviceRequests).values([
      {
        customerId: 1,
        vehicleId: 1,
        mechanicId: 1,
        serviceType: "General Service",
        description: "Regular maintenance and oil change for XUV700",
        status: "in_progress",
        scheduledDate: new Date("2025-01-28T10:00:00"),
        estimatedCost: 4500,
        mechanicLatitude: "19.0780",
        mechanicLongitude: "72.8800",
      },
      {
        customerId: 1,
        vehicleId: 2,
        mechanicId: 2,
        serviceType: "AC Repair",
        description: "AC not cooling properly in Ciaz",
        status: "pending",
        scheduledDate: new Date("2025-02-01T14:00:00"),
        estimatedCost: 3200,
      },
      {
        customerId: 1,
        vehicleId: 1,
        mechanicId: 3,
        serviceType: "Brake Pad Replacement",
        description: "Front brake pads worn out",
        status: "completed",
        scheduledDate: new Date("2025-01-15T09:00:00"),
        completedDate: new Date("2025-01-15T12:30:00"),
        estimatedCost: 2800,
        actualCost: 3100,
        partsReplaced: JSON.stringify(["Front Brake Pads", "Brake Fluid"]),
      },
    ]);

    // Seed reviews
    await db.insert(reviews).values([
      {
        customerId: 1,
        mechanicId: 3,
        serviceRequestId: 3,
        rating: 5,
        serviceQuality: 5,
        responseTime: 4,
        comment: "Excellent brake pad replacement! Vikram ji was very professional and explained everything clearly. Highly recommended!",
      },
      {
        customerId: 1,
        mechanicId: 1,
        rating: 4,
        serviceQuality: 5,
        responseTime: 4,
        comment: "Good service by Suresh. Arrived on time and fixed the issue quickly. Fair pricing.",
      },
    ]);

    // Seed notifications
    await db.insert(notifications).values([
      {
        customerId: 1,
        title: "Service In Progress",
        message: "Your XUV700 general service is underway. Mechanic Suresh Patil is working on it.",
        type: "service",
        isRead: false,
      },
      {
        customerId: 1,
        title: "Booking Confirmed",
        message: "AC Repair for your Ciaz has been scheduled for Feb 1, 2025 at 2:00 PM.",
        type: "booking",
        isRead: false,
      },
      {
        customerId: 1,
        title: "Service Completed",
        message: "Brake pad replacement for your XUV700 has been completed successfully.",
        type: "completed",
        isRead: true,
      },
      {
        customerId: 1,
        title: "Payment Received",
        message: "₹3,100 payment received for brake pad replacement service.",
        type: "payment",
        isRead: true,
      },
      {
        customerId: 1,
        title: "Service Reminder",
        message: "Your Ciaz is due for regular service on Jan 15, 2025.",
        type: "reminder",
        isRead: false,
      },
    ]);

    return NextResponse.json({ message: "Seeded successfully" });
  } catch (error) {
    console.error("Seed error:", error);
    return NextResponse.json({ error: "Seed failed" }, { status: 500 });
  }
}
