import { NextResponse } from "next/server";
import { db } from "@/db";
import { mechanics } from "@/db/schema";

export async function GET() {
  try {
    const result = await db.select().from(mechanics);
    return NextResponse.json(result);
  } catch {
    return NextResponse.json([], { status: 200 });
  }
}
