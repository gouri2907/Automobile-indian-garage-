import { NextRequest, NextResponse } from "next/server";

const aiResponses: Record<string, string> = {
  engine: "🔧 Based on your description, this could be related to:\n\n1. **Spark plug issues** - Misfiring or worn plugs (₹200-₹800 per plug)\n2. **Air filter blockage** - Restricted airflow (₹300-₹600)\n3. **Fuel injector problems** - Clogged or faulty injectors (₹1,500-₹3,000)\n\n**Recommendation:** Get a diagnostic scan done. I can book a nearby mechanic for you who specializes in engine issues.",
  ac: "❄️ Common AC issues in Indian conditions:\n\n1. **Low refrigerant** - Needs gas refill (₹1,500-₹2,500)\n2. **Compressor issue** - May need repair/replacement (₹5,000-₹15,000)\n3. **Condenser blockage** - Cleaning required (₹800-₹1,500)\n4. **Cabin air filter** - Replacement needed (₹400-₹800)\n\n**Tip:** In Indian summers, get AC serviced before April. Regular maintenance saves 30% on repair costs.",
  brake: "🛑 Brake issues should be addressed immediately!\n\n1. **Worn brake pads** - Replace urgently (₹1,200-₹3,500)\n2. **Brake fluid low** - Top up or flush (₹400-₹800)\n3. **Disc warping** - Resurfacing or replacement (₹2,000-₹5,000)\n4. **ABS sensor** - Check and replace if faulty (₹1,500-₹4,000)\n\n⚠️ **Safety Alert:** Do not drive with compromised brakes. I recommend immediate mechanic assistance.",
  service: "📋 Regular Service Checklist for Indian Roads:\n\n1. **Engine oil change** every 10,000 km (₹1,500-₹3,500)\n2. **Air filter** every 15,000 km (₹300-₹600)\n3. **Coolant top-up** check every 6 months\n4. **Tyre rotation** every 10,000 km\n5. **Battery check** every 12 months\n6. **Suspension check** every 20,000 km (crucial for Indian roads)\n\n**Estimated total service cost:** ₹3,500-₹8,000 depending on vehicle.",
  tyre: "🔄 Tyre Care for Indian Roads:\n\n1. **Tyre pressure** - Check weekly (important in Indian heat)\n2. **Tread depth** - Replace below 1.6mm (₹3,000-₹8,000 per tyre)\n3. **Wheel alignment** - Every 10,000 km (₹500-₹1,000)\n4. **Balancing** - With every alignment (₹200-₹400)\n5. **Rotation** - Every 10,000 km for even wear\n\n**Tip:** Keep 2-3 PSI extra in summers for Indian highways. Avoid potholes to extend tyre life.",
  battery: "🔋 Battery Issues:\n\n1. **Battery age** - Replace every 3-4 years (₹3,500-₹8,000)\n2. **Terminals corroded** - Clean with baking soda\n3. **Alternator issue** - Check charging system (₹2,000-₹5,000)\n4. **Parasitic drain** - Get electrical check\n\n**Emergency Tip:** If stranded, call our emergency assistance. A mechanic can reach you in 15-30 minutes.",
};

const photoResponses: Record<string, string> = {
  tyre: "📸 **Photo Analysis — Tyre Damage Detected**\n\nBased on the image you shared, I can observe potential issues:\n\n1. **Tread wear** — Uneven wear pattern visible (₹3,000-₹8,000 per tyre)\n2. **Sidewall damage** — Possible bulge or cut (Immediate replacement needed)\n3. **Low tyre pressure** — May cause further damage\n\n⚠️ **Safety Warning:** Do not drive at high speed with damaged tyres.\n\n**Recommendation:** Visit a nearby tyre shop or I can send a mechanic to your location within 15 minutes.",
  dent: "📸 **Photo Analysis — Body Damage Detected**\n\nFrom the image you've shared, I can identify:\n\n1. **Dent/Scratch** — Panel denting required (₹2,000-₹5,000)\n2. **Paint damage** — Touch-up or repaint needed (₹3,000-₹8,000)\n3. **Clear coat peeling** — Full panel repaint recommended\n\n**Cost Estimate:**\n• Minor scratch: ₹500-₹1,500\n• Medium dent with paint: ₹3,000-₹6,000\n• Full panel repaint: ₹5,000-₹12,000\n\n**Recommendation:** I can connect you with our denting & painting specialist **Ravi Deshmukh** who is 1.8 km away.",
  engine: "📸 **Photo Analysis — Engine Area Issue**\n\nAnalyzing the image you shared:\n\n1. **Oil leak spotted** — Gasket may need replacement (₹1,500-₹4,000)\n2. **Coolant discoloration** — Flush and refill recommended (₹800-₹1,500)\n3. **Belt wear** — Serpentine/timing belt may need replacement (₹2,000-₹6,000)\n\n**Severity:** 🟡 Moderate — Schedule service within this week.\n\n**Recommendation:** Our engine specialist **Suresh Patil** (⭐ 4.8) can diagnose this accurately. Book a visit?",
  dashboard: "📸 **Photo Analysis — Dashboard Warning Light**\n\nI can see a warning indicator in your image:\n\n1. **Check Engine Light** — OBD scan needed (₹200-₹500 for scan)\n2. **Oil Pressure Warning** — Check oil level immediately\n3. **Battery Warning** — Alternator or battery issue\n4. **ABS Warning** — Brake system check needed\n\n**Immediate Steps:**\n• Stop driving if engine temperature is high 🔴\n• Check oil level on dipstick\n• Don't ignore battery light — could leave you stranded\n\n**Recommendation:** Get an OBD-II diagnostic scan. Nearest mechanic **Amit Sharma** can do this for ₹300.",
  general: "📸 **Photo Received — Analyzing Your Vehicle Issue**\n\nThank you for sharing the photo! Here's my initial assessment:\n\n1. **Visual inspection** — I've analyzed the image for common issues\n2. **Wear & tear signs** — Some components may need attention\n3. **Safety check** — No critical safety hazards detected\n\n**For a more accurate diagnosis, please tell me:**\n• What specific issue are you experiencing?\n• Any unusual sounds, smells, or vibrations?\n• When did you first notice this problem?\n\n**Recommendation:** For a detailed hands-on inspection, I can book a mechanic who'll arrive in ~15 minutes.",
};

// Negotiation service catalog with base prices and minimum acceptable prices
const servicePrices: Record<string, { name: string; basePrice: number; minPrice: number; laborHours: number }> = {
  general_service: { name: "General Service", basePrice: 4500, minPrice: 3200, laborHours: 2 },
  engine_repair: { name: "Engine Repair", basePrice: 6000, minPrice: 4500, laborHours: 4 },
  ac_repair: { name: "AC Repair", basePrice: 3500, minPrice: 2500, laborHours: 2 },
  ac_gas_refill: { name: "AC Gas Refill", basePrice: 2500, minPrice: 1800, laborHours: 1 },
  brake_service: { name: "Brake Pad Replacement", basePrice: 3500, minPrice: 2500, laborHours: 1.5 },
  battery_replacement: { name: "Battery Replacement", basePrice: 5500, minPrice: 4500, laborHours: 0.5 },
  tyre_replacement: { name: "Tyre Replacement (per tyre)", basePrice: 6000, minPrice: 4500, laborHours: 0.5 },
  wheel_alignment: { name: "Wheel Alignment", basePrice: 1200, minPrice: 800, laborHours: 1 },
  oil_change: { name: "Oil Change", basePrice: 2500, minPrice: 1800, laborHours: 0.5 },
  denting_painting: { name: "Denting & Painting", basePrice: 8000, minPrice: 5500, laborHours: 8 },
  full_body_wash: { name: "Full Body Wash & Polish", basePrice: 1500, minPrice: 1000, laborHours: 2 },
  clutch_repair: { name: "Clutch Repair", basePrice: 7000, minPrice: 5000, laborHours: 4 },
};

function getNegotiationResponse(message: string, negotiationState?: { service?: string; currentOffer?: number; round?: number }): { response: string; negotiationData?: { service: string; currentOffer: number; round: number; status: string } } {
  const lower = message.toLowerCase();
  
  // Extract price from message (e.g., "2000", "₹2000", "2,500", "Rs 3000")
  const priceMatch = message.match(/₹?\s*[rR][sS]\.?\s*(\d[\d,]*)|₹\s*(\d[\d,]*)|(\d[\d,]*)\s*(?:rupees?|rs\.?|₹)?/i);
  const offeredPrice = priceMatch 
    ? parseInt((priceMatch[1] || priceMatch[2] || priceMatch[3]).replace(/,/g, "")) 
    : null;

  // Detect which service user wants to negotiate
  let detectedService: string | null = null;
  if (lower.includes("general service") || lower.includes("full service") || lower.includes("regular service")) detectedService = "general_service";
  else if (lower.includes("engine")) detectedService = "engine_repair";
  else if (lower.includes("ac") && (lower.includes("gas") || lower.includes("refill"))) detectedService = "ac_gas_refill";
  else if (lower.includes("ac") || lower.includes("air condition")) detectedService = "ac_repair";
  else if (lower.includes("brake")) detectedService = "brake_service";
  else if (lower.includes("battery")) detectedService = "battery_replacement";
  else if (lower.includes("tyre") || lower.includes("tire")) detectedService = "tyre_replacement";
  else if (lower.includes("alignment") || lower.includes("wheel align")) detectedService = "wheel_alignment";
  else if (lower.includes("oil change") || lower.includes("engine oil")) detectedService = "oil_change";
  else if (lower.includes("dent") || lower.includes("paint") || lower.includes("body")) detectedService = "denting_painting";
  else if (lower.includes("wash") || lower.includes("polish") || lower.includes("clean")) detectedService = "full_body_wash";
  else if (lower.includes("clutch")) detectedService = "clutch_repair";

  // Use existing negotiation state or start fresh
  const service = negotiationState?.service || detectedService;
  const round = (negotiationState?.round || 0) + 1;

  if (!service) {
    // Start negotiation - ask what service they want
    return {
      response: "💰 **Let's Negotiate! — Price Discussion**\n\nI can help you get the best price for your service. Which service would you like to discuss?\n\n**Available Services:**\n• General Service — ₹4,500\n• Engine Repair — ₹6,000\n• AC Repair — ₹3,500\n• AC Gas Refill — ₹2,500\n• Brake Pad Replacement — ₹3,500\n• Battery Replacement — ₹5,500\n• Tyre Replacement — ₹6,000/tyre\n• Wheel Alignment — ₹1,200\n• Oil Change — ₹2,500\n• Denting & Painting — ₹8,000\n• Full Body Wash — ₹1,500\n• Clutch Repair — ₹7,000\n\n**Just tell me the service and your budget**, e.g., *\"I want AC repair for ₹2,500\"*",
    };
  }

  const serviceInfo = servicePrices[service];
  if (!serviceInfo) {
    return { response: "I couldn't identify the service. Please specify which service you'd like to negotiate for." };
  }

  // If no price offered, prompt for their offer
  if (!offeredPrice && round === 1) {
    return {
      response: `💰 **Negotiation — ${serviceInfo.name}**\n\n**Current Price:** ₹${serviceInfo.basePrice.toLocaleString("en-IN")}\n\nThis includes:\n• ${serviceInfo.laborHours} hours of labor\n• Quality parts & materials\n• 30-day service warranty\n• Free pickup & drop (within 5 km)\n\n**What's your budget?** Tell me your offer and I'll see what I can do! 🤝\n\n*Example: "I can pay ₹3,000" or "My budget is ₹2,500"*`,
      negotiationData: { service, currentOffer: serviceInfo.basePrice, round, status: "awaiting_offer" },
    };
  }

  // Process the offered price
  if (offeredPrice) {
    const basePrice = serviceInfo.basePrice;
    const minPrice = serviceInfo.minPrice;
    const percentOff = Math.round(((basePrice - offeredPrice) / basePrice) * 100);

    // Too low - below minimum
    if (offeredPrice < minPrice * 0.8) {
      return {
        response: `😅 **₹${offeredPrice.toLocaleString("en-IN")}? That's quite low!**\n\nI understand everyone wants a good deal, but at that price, I won't even cover the parts cost for ${serviceInfo.name}.\n\n**My best offer:** ₹${minPrice.toLocaleString("en-IN")} (${Math.round(((basePrice - minPrice) / basePrice) * 100)}% off!)\n\nThis is the lowest I can go while maintaining quality. What do you say? 🤔\n\n*Reply with "Deal" to accept, or make a counter-offer.*`,
        negotiationData: { service, currentOffer: minPrice, round, status: "counter_offer" },
      };
    }

    // Near minimum - final offer territory
    if (offeredPrice < minPrice) {
      const counterOffer = minPrice;
      return {
        response: `🤔 **₹${offeredPrice.toLocaleString("en-IN")}? Hmm, let me check...**\n\nThat's ${percentOff}% below our standard rate. I really want to help you out!\n\n**Final Offer:** ₹${counterOffer.toLocaleString("en-IN")} ✨\n\nThis is my absolute best price for ${serviceInfo.name}. Any lower and I'd be losing money!\n\n✅ Includes:\n• Premium quality parts\n• Experienced mechanic\n• 30-day warranty\n• Free vehicle inspection\n\n*Type "Done" or "OK" to lock this price!*`,
        negotiationData: { service, currentOffer: counterOffer, round, status: "final_offer" },
      };
    }

    // Between min and base - negotiate
    if (offeredPrice < basePrice) {
      const discount = Math.min(percentOff + 5, Math.round(((basePrice - minPrice) / basePrice) * 100));
      const counterOffer = Math.max(Math.round(basePrice * (1 - discount / 100)), minPrice);
      
      if (round >= 3 || offeredPrice >= counterOffer) {
        // Accept after enough rounds or if offer is good
        const finalPrice = Math.max(offeredPrice, minPrice);
        return {
          response: `🎉 **DEAL! ₹${finalPrice.toLocaleString("en-IN")} Accepted!**\n\n**${serviceInfo.name}**\n~~₹${basePrice.toLocaleString("en-IN")}~~ → **₹${finalPrice.toLocaleString("en-IN")}**\n\n🏷️ You saved: ₹${(basePrice - finalPrice).toLocaleString("en-IN")} (${Math.round(((basePrice - finalPrice) / basePrice) * 100)}% off!)\n\n**What's included:**\n✅ ${serviceInfo.laborHours} hours expert labor\n✅ Quality OEM/OES parts\n✅ 30-day service warranty\n✅ Free pickup & drop\n✅ Complimentary car wash\n\n**Ready to book?** Tap the "Book Service" button to schedule with this negotiated price! 🚗`,
          negotiationData: { service, currentOffer: finalPrice, round, status: "accepted" },
        };
      }

      return {
        response: `🤝 **Good offer! Let's meet in the middle.**\n\nYou offered: ₹${offeredPrice.toLocaleString("en-IN")}\nMy counter: **₹${counterOffer.toLocaleString("en-IN")}** (${discount}% off!)\n\nI've already given you a great discount on ${serviceInfo.name}! This price includes top-quality service.\n\n**Sweeten the deal?** Accept my offer and I'll add:\n🎁 Free exterior wash\n🎁 Free 10-point inspection\n\n*Accept, or make your final offer!*`,
        negotiationData: { service, currentOffer: counterOffer, round, status: "negotiating" },
      };
    }

    // At or above base price - instant accept
    return {
      response: `🎉 **Excellent! Deal Confirmed at ₹${offeredPrice.toLocaleString("en-IN")}!**\n\n**${serviceInfo.name}** booked at your price.\n\n**Bonus:** Since you're being generous, I'll throw in:\n🎁 Premium car wash (₹500 value)\n🎁 Interior vacuuming\n🎁 Dashboard polish\n🎁 Priority scheduling\n\n**Total Value:** ₹${(offeredPrice + 800).toLocaleString("en-IN")}\n**You Pay:** ₹${offeredPrice.toLocaleString("en-IN")}\n\nTap "Book Service" to confirm your appointment! 🚗✨`,
      negotiationData: { service, currentOffer: offeredPrice, round, status: "accepted" },
    };
  }

  // Accept keywords
  if (lower.includes("deal") || lower.includes("ok") || lower.includes("done") || lower.includes("accept") || lower.includes("yes") || lower.includes("book") || lower.includes("confirm")) {
    const finalPrice = negotiationState?.currentOffer || serviceInfo.minPrice;
    return {
      response: `🎉 **Congratulations! Deal Locked!**\n\n**${serviceInfo.name}**\n**Final Price:** ₹${finalPrice.toLocaleString("en-IN")}\n\n~~Original: ₹${serviceInfo.basePrice.toLocaleString("en-IN")}~~\n💰 **You saved: ₹${(serviceInfo.basePrice - finalPrice).toLocaleString("en-IN")}**\n\n**Next Steps:**\n1. Tap "Book Service" in the menu\n2. Select your vehicle\n3. Choose ${serviceInfo.name}\n4. Your negotiated price will be applied!\n\nThank you for choosing Automobile Indian Garage! 🙏`,
      negotiationData: { service, currentOffer: finalPrice, round, status: "confirmed" },
    };
  }

  // Default continuation
  return {
    response: `💬 I'm ready to negotiate on **${serviceInfo.name}**!\n\n**Current offer:** ₹${(negotiationState?.currentOffer || serviceInfo.basePrice).toLocaleString("en-IN")}\n\nTell me your budget and let's make a deal! 🤝`,
    negotiationData: { service, currentOffer: negotiationState?.currentOffer || serviceInfo.basePrice, round, status: "negotiating" },
  };
}

function getAIResponse(message: string): string {
  const lower = message.toLowerCase();
  if (lower.includes("engine") || lower.includes("start") || lower.includes("noise") || lower.includes("vibrat")) return aiResponses.engine;
  if (lower.includes("ac") || lower.includes("cool") || lower.includes("air condition") || lower.includes("heat")) return aiResponses.ac;
  if (lower.includes("brake") || lower.includes("stop") || lower.includes("squeak")) return aiResponses.brake;
  if (lower.includes("service") || lower.includes("maintenance") || lower.includes("regular")) return aiResponses.service;
  if (lower.includes("tyre") || lower.includes("tire") || lower.includes("wheel") || lower.includes("puncture")) return aiResponses.tyre;
  if (lower.includes("battery") || lower.includes("charge") || lower.includes("electric")) return aiResponses.battery;

  return "🚗 I'm your Automobile Indian Garage AI Assistant! I can help you with:\n\n• **Vehicle Diagnostics** - Describe your car's issue\n• **Maintenance Tips** - Ask about service schedules\n• **Cost Estimates** - Get pricing for common repairs\n• **Emergency Help** - Quick troubleshooting steps\n\nTry asking about: engine problems, AC issues, brakes, tyres, battery, or general service needs.";
}

function getPhotoAIResponse(caption: string): string {
  const lower = caption.toLowerCase();
  if (lower.includes("tyre") || lower.includes("tire") || lower.includes("wheel") || lower.includes("puncture") || lower.includes("flat")) return photoResponses.tyre;
  if (lower.includes("dent") || lower.includes("scratch") || lower.includes("paint") || lower.includes("body") || lower.includes("bumper")) return photoResponses.dent;
  if (lower.includes("engine") || lower.includes("oil") || lower.includes("leak") || lower.includes("hood") || lower.includes("bonnet")) return photoResponses.engine;
  if (lower.includes("dashboard") || lower.includes("warning") || lower.includes("light") || lower.includes("indicator") || lower.includes("meter")) return photoResponses.dashboard;
  return photoResponses.general;
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { message, hasPhoto, photoCaption, isNegotiation, negotiationState } = body;

    let response: string;
    let negotiationData = undefined;

    if (isNegotiation) {
      const result = getNegotiationResponse(message, negotiationState);
      response = result.response;
      negotiationData = result.negotiationData;
    } else if (hasPhoto) {
      response = getPhotoAIResponse(photoCaption || message || "general");
    } else {
      response = getAIResponse(message);
    }

    // Simulate AI thinking delay
    await new Promise((resolve) => setTimeout(resolve, isNegotiation ? 1000 : hasPhoto ? 1200 : 800));

    return NextResponse.json({ response, negotiationData });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "AI service error" }, { status: 500 });
  }
}
