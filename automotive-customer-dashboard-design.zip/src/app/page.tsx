"use client";

import { useEffect, useState, useCallback } from "react";
import { useStore } from "@/store/useStore";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import BottomNav from "@/components/BottomNav";
import HomeDashboard from "@/components/modules/HomeDashboard";
import MyVehicles from "@/components/modules/MyVehicles";
import ServiceBooking from "@/components/modules/ServiceBooking";
import MechanicsList from "@/components/modules/MechanicsList";
import AIAssistant from "@/components/modules/AIAssistant";
import GPSTracking from "@/components/modules/GPSTracking";
import ReviewsRatings from "@/components/modules/ReviewsRatings";
import ServiceHistory from "@/components/modules/ServiceHistory";
import NotificationsPanel from "@/components/modules/NotificationsPanel";
import ProfileSettings from "@/components/modules/ProfileSettings";

interface VehicleData {
  id: number;
  registrationNumber: string;
  vehicleType: string;
  brand: string;
  model: string;
  fuelType: string;
  manufacturingYear: number;
  color: string | null;
  imageUrl: string | null;
  insuranceProvider: string | null;
  insuranceExpiry: string | null;
  serviceDueDate: string | null;
  healthScore: number | null;
  odometerReading: number | null;
}

interface MechanicData {
  id: number;
  name: string;
  phone: string;
  avatarUrl: string | null;
  specialization: string;
  experience: number;
  rating: string | null;
  totalReviews: number | null;
  isOnline: boolean | null;
  distanceKm: string | null;
  estimatedArrival: string | null;
  serviceChargePerHour: number | null;
}

interface ServiceData {
  id: number;
  serviceType: string;
  description: string | null;
  status: string;
  scheduledDate: string | null;
  completedDate: string | null;
  estimatedCost: number | null;
  actualCost: number | null;
  partsReplaced: unknown;
  vehicleId: number;
  mechanicId: number | null;
  mechanicLatitude: string | null;
  mechanicLongitude: string | null;
}

interface ReviewData {
  id: number;
  mechanicId: number;
  rating: number;
  serviceQuality: number | null;
  responseTime: number | null;
  comment: string | null;
  createdAt: string | null;
}

interface NotificationData {
  id: number;
  title: string;
  message: string;
  type: string;
  isRead: boolean | null;
  createdAt: string | null;
}

export default function Dashboard() {
  const { activeNav } = useStore();
  const [vehicles, setVehicles] = useState<VehicleData[]>([]);
  const [mechanics, setMechanics] = useState<MechanicData[]>([]);
  const [services, setServices] = useState<ServiceData[]>([]);
  const [reviews, setReviews] = useState<ReviewData[]>([]);
  const [notifications, setNotifications] = useState<NotificationData[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = useCallback(async () => {
    try {
      // Seed first
      await fetch("/api/seed", { method: "POST" });

      const [vRes, mRes, sRes, rRes, nRes] = await Promise.all([
        fetch("/api/vehicles"),
        fetch("/api/mechanics"),
        fetch("/api/services"),
        fetch("/api/reviews"),
        fetch("/api/notifications"),
      ]);
      const [v, m, s, r, n] = await Promise.all([
        vRes.json(),
        mRes.json(),
        sRes.json(),
        rRes.json(),
        nRes.json(),
      ]);
      setVehicles(v);
      setMechanics(m);
      setServices(s);
      setReviews(r);
      setNotifications(n);
    } catch (err) {
      console.error("Failed to load data:", err);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const renderContent = () => {
    if (loading) {
      return (
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="text-center">
            <div className="w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mx-auto mb-4" />
            <p className="text-slate-400 text-sm">Loading dashboard...</p>
          </div>
        </div>
      );
    }

    switch (activeNav) {
      case "home":
        return <HomeDashboard vehicles={vehicles} mechanics={mechanics} services={services} />;
      case "vehicles":
        return <MyVehicles vehicles={vehicles} onRefresh={fetchData} />;
      case "booking":
        return <ServiceBooking vehicles={vehicles} mechanics={mechanics} onRefresh={fetchData} />;
      case "mechanics":
        return <MechanicsList mechanics={mechanics} />;
      case "ai":
        return <AIAssistant />;
      case "gps":
        return <GPSTracking services={services} mechanics={mechanics} vehicles={vehicles} />;
      case "reviews":
        return <ReviewsRatings reviews={reviews} mechanics={mechanics} onRefresh={fetchData} />;
      case "history":
        return <ServiceHistory services={services} vehicles={vehicles} mechanics={mechanics} />;
      case "notifications":
        return <NotificationsPanel notifications={notifications} onRefresh={fetchData} />;
      case "profile":
        return <ProfileSettings />;
      default:
        return <HomeDashboard vehicles={vehicles} mechanics={mechanics} services={services} />;
    }
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: "var(--bg-main)" }}>
      <Sidebar />
      <div className="lg:ml-[270px]">
        <Header />
        <main className="p-4 sm:p-5 lg:p-6 pb-24 lg:pb-6">
          {renderContent()}
        </main>
      </div>
      <BottomNav />
    </div>
  );
}
